open Parameters;;
open Log;;

let null =
        if Sys.os_type = "Win32" then
                "nul"
        else
                "/dev/null";;

(**This class renders the .png image by calling povray*)

(**Definition of class povray_renderer*)
class povray_renderer_class =
object (self)

	(**Returns exit code (int)*)
	method render povFile =
		let n = ref 0 in
			
			if log#getLogFile = true then
                        begin
                                if Sys.os_type = "Win32" then
                                begin
                                        n := Sys.command (Printf.sprintf "pvengine +I%s +O%s +W%d +H%d +Q2 +SC%f +EC%f +S%f +E%f -D /EXIT +FN 2> log/povray.log" povFile parameters#getOutputPngFile parameters#getWidthResolution parameters#getHeightResolution parameters#getHStart parameters#getHEnd parameters#getVStart parameters#getVEnd)
                                end
                                else
                                begin
                                        n := Sys.command (Printf.sprintf "povray +I%s +O%s +W%d +H%d +Q2 +SC%f +EC%f +S%f +E%f -D +FN 2> log/povray.log" povFile parameters#getOutputPngFile parameters#getWidthResolution parameters#getHeightResolution parameters#getHStart parameters#getHEnd parameters#getVStart parameters#getVEnd)
                                end;
		        end
                        else
                        begin
			         			if Sys.os_type = "Win32" then
                                begin
                                	n := Sys.command (Printf.sprintf "pvengine +I%s +O%s +W%d +H%d +Q2 +SC%f +EC%f +S%f +E%f -D +FN /EXIT 2> %s" povFile parameters#getOutputPngFile parameters#getWidthResolution parameters#getHeightResolution parameters#getHStart parameters#getHEnd parameters#getVStart parameters#getVEnd null);
                                end
                                else
                                begin
                                        n := Sys.command (Printf.sprintf "povray +I%s +O%s +W%d +H%d +Q2 +SC%f +EC%f +S%f +E%f -D +FN 2> %s" povFile parameters#getOutputPngFile parameters#getWidthResolution parameters#getHeightResolution parameters#getHStart parameters#getHEnd parameters#getVStart parameters#getVEnd null);
                                end;
                        end;
                        if !n != 0 then
			begin
				Printf.printf "ERROR: Error rendering image. Verify povray is installed in your system and the bin directory of the povray installation path is in the PATH environment variable.\n";
				exit 1;
			end;
			
			if (parameters#getShow = "java") then
			begin
				n := Sys.command (Printf.sprintf "java -jar visualizer.jar %s 2> %s"
                                parameters#getOutputPngFile null);
				if !n != 0 then
				begin
					Printf.printf "ERROR: Error displaying image. Verify java is installed in your system.\n";
					exit 1;
				end
			end
end;;

let povray_renderer = new povray_renderer_class;;
