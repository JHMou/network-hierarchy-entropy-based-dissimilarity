(**This module reads a file with edges and adds them to an empty graph*)

open Files;;

class type graph = object method addEdge: int -> int -> float -> unit method addVertexNumber: int -> unit method setVertexName: int -> string -> unit end;;

(**Definition of class graph_builder G=(V,E)*)
class graph_builder_class  =
object
	(**Reads an input file with format:
		file :=  [ set of {line}
				EOF
			line := [ { vertex1 vertex 2 EOL}
				vertex1: int
				vertex2: int
			]
		]
		and builds the graph. Receives the name of the file and the graph*)
	method read_file : 'a 'b. (#graph as 'a) -> string -> unit =
		fun graph filename ->
			let f_input = Unix.openfile filename (Unix.O_RDWR :: []) 511 in
		  
		Gc.set {(Gc.get()) with Gc.space_overhead = 50};
		let vertex1 = ref 0
		and text = ref ""
		and vertex2 = ref 0
		and vertex4 = ref 0.0
		and n = ref 1 in
		while !n > 0 do
        	let line = ref "" in
				n := readLine f_input line;		
                (try 

			Scanf.sscanf !line " %d %d %f" (fun a b c -> vertex1 := a; vertex2 := b; vertex4 := c);
			(**Printf.printf "Edge: %d %d\n" !vertex1 !vertex2;*)
			graph#addEdge !vertex1 !vertex2 !vertex4;
		with
			_ -> 
				(try
					Scanf.sscanf !line " %d %d" (fun a b -> vertex1 := a; vertex2 := b);
					(**Printf.printf "Edge: %d %d\n" !vertex1 !vertex2;*)
					graph#addEdge !vertex1 !vertex2 1.0;
				with
					End_of_file -> ()
					| Scanf.Scan_failure a -> ()
				)
		);
		done
end;;
