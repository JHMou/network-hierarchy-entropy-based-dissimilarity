open Parameters;;
open Log;;

let null =
        if Sys.os_type = "Win32" then
                "nul"
        else
                "/dev/null";;

(**This class renders the .svg image by calling the svg renderer*)

(**Definition of class svg_renderer*)
class svg_renderer_class =
object (self)

	(**Returns exit code (int)*)
	method render svgFile =
		let n = ref 0 in
			
			if log#getLogFile = true then
                        begin
                                if Sys.os_type = "Win32" then
                                begin
                                end
                                else
                                begin
                                        n := Sys.command (Printf.sprintf "rsvg -w %d -h %d %s %s 2> log/povray.log" parameters#getWidthResolution parameters#getHeightResolution svgFile parameters#getOutputPngFile)
                                end;
		        end
                        else
                        begin
			         if Sys.os_type = "Win32" then
                                begin
                                end
                                else
                                begin
                                        n := Sys.command (Printf.sprintf "rsvg -w %d -h %d %s %s 2> %s" parameters#getWidthResolution parameters#getHeightResolution svgFile parameters#getOutputPngFile null)
                                end;
                        end;
                        if !n != 0 then
			begin
				Printf.printf "ERROR: Error rendering image. Verify rsvg is installed in your system.\n";
				exit 1;
			end;
			
			if (parameters#getShow = "java") then
			begin
				n := Sys.command (Printf.sprintf "java -jar visualizer.jar %s 2> %s"
                                parameters#getOutputPngFile null);
				if !n != 0 then
				begin
					Printf.printf "ERROR: Error displaying image. Verify java is installed in your system.\n";
					exit 1;
				end
			end
end;;

let svg_renderer = new svg_renderer_class;;
