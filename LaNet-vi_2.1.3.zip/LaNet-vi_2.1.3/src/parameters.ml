(**This class validates input parameters and offers help*)

open Log;;
open Files;;
class parameters_class =
object(self)

	val mutable bckGnd = "white";
	
	method getBckGnd = bckGnd;

	val mutable color = "col";
	
	method getColor = color;

	val mutable percentOfEdges = 0.0;
	
	method getPercentOfEdges = percentOfEdges;

	val mutable minEdges = 0;
	
	method getMinEdges = minEdges;

	val mutable widthResolution = 800;
	
	method getWidthResolution = widthResolution;

	val mutable heightResolution = 600;
	
	method getHeightResolution = heightResolution;

	val mutable epsilon : float = 0.0;
	
	method getEpsilon = epsilon;

	val mutable delta : float = 1.0;
	
	method getDelta = delta;
	
	val mutable gamma : float = 1.3;
	
	method getGamma = gamma;

	val mutable hstart : float = 0.0;
	
	method getHStart = hstart;

	val mutable hend : float = 1.0;
	
	method getHEnd = hend;
	
	val mutable vstart : float = 0.0;
	
	method getVStart = vstart;

	val mutable vend : float = 1.0;
	
	method getVEnd = vend;

	val mutable u : float = 1.0;
	
	method getU = u;

	(**Options: "lanet" or "nwb"*)
	val mutable format = "lanet";
	
	method getFormat = format;
	
	(**Options: "" or "java"*)
	val mutable show = "";
	
	method getShow = show;
		
	val mutable outputFile = "";
	
	val mutable outputRendFile = "";
	
	method getOutputFile = outputRendFile;
	
	val mutable outputPngFile = "";
	
	method getOutputPngFile = outputPngFile;
	
	val mutable inputFile = "";
	
	method getInputFile = inputFile;
	
	val mutable inputNodeNamesFile = "";
	
	method getInputNodeNamesFile = inputNodeNamesFile;
	
	val mutable coresFile = "";
	
	method getCoresFile = coresFile;
	
	val mutable multigraph = false;
	
	method getMultigraph = multigraph;

	val mutable weighted = false;
	
	method getWeighted = weighted;

	(**For weighted graphs*)
	val mutable granularity = -1;
	
	method getGranularity = granularity;

	val mutable renderer = "povray";
		
	method getRenderer = renderer;

	val mutable strengthsIntervals = "equalIntervalSize";
		
	method getStrengthsIntervals = strengthsIntervals;

	val mutable noCliques = false;
	
	method getNoCliques = noCliques;

	val mutable kConn = false;
	
	method getKConn = kConn;

	val mutable onlyGraphic = false;
	
	method getOnlyGraphic = onlyGraphic;

	val mutable noGraphic = false;
	
	method getNoGraphic = noGraphic;

	val mutable opacity = 0.2;
	
	method getOpacity = opacity;

	val mutable isLogFile = false;
			
	method printHeader =
	Printf.printf "\nLaNet-vi 2.1.3\n";
	Printf.printf "--------------\n\n";
	Printf.printf "Large scale networks visualization tool using k-core decomposition.
Software license: Academic Free License (AFL)
Images license: Creative Commons License ";
	Printf.printf "\nhttp://xavier.informatics.indiana.edu/lanet-vi/\n\n";
	
	method private printHelp =
	Printf.printf "Parameters:\n";
	Printf.printf "-input <file>: Name of input file containing the network edges. Required.\n";
	Printf.printf "-names <file>: Name of input file containing the nodes' names. A name \"0\" indicates LaNet to show the nodes' numbers. Optional.\n";
	Printf.printf "-output <file>: Name of output .pov and .png files. Optional. Default: <inputFileName>.pov and <inputFileName>.png\n";
	Printf.printf "-coresfile <file>: Generates a k-core decomposition file with (node number, shell-index). Optional. Default: no file\n";
	Printf.printf "-logfile: Generate log files in log directory. Optional.\n";
	Printf.printf "-logstdout: Generate log information on stdout. Optional.\n";
	Printf.printf "-multigraph: Allows repeated edges.  Combined with 'weighted' allows to specify repeated edges as weight. Optional.\n";
	Printf.printf "-weighted: Allows weights on edges (for weighted graphs). Combined with 'multigraph' allows to specify repeated edges as weight (in this case weight must be integer). Optional.\n";
	Printf.printf "-strengthsIntervals: How to build p-function intervals on weighted graphs. Possible values: 'equalNodesPerInterval' or 'equalIntervalSize'. Optional. Default: equalIntervalSize\n";
	Printf.printf "-granularity: Amount of groups in weighted graphs. Optional. Default: maximum degree\n";
	Printf.printf "-bckgnd <value>: Background color. Possible values: 'white' and 'black'. Optional. Default: white\n";
	Printf.printf "-color <value>: Graph color. Possible values: 'col', 'bw' (black and white, one scale) and 'bwi' (black and white, interlaced scale). Optional. Default: col\n";
	Printf.printf "-eps <value>: Epsilon. Controls the possibility of rings overlapping. Used to tune image's rendering. Optional. Default: 0\n";
	Printf.printf "-delta <value>: Delta. Controls distance between components in graphical visualization. Optional. Default: 1\n";
	Printf.printf "-gamma <value>: Gamma. Controls the component's diameter. Optional. Default: 1\n";
	Printf.printf "-edges <value>: Percent of visible edges. Value: 0.0 - 1.0. Optional. Default: 0.0\n";
	Printf.printf "-minedges <value>: Minimum number of visible edges. Value: Integer. Optional. Default: 0\n";
	Printf.printf "-W <value>: Image width in pixels. Optional. Default: 800\n";
	Printf.printf "-H <value>: Image height in pixels. Optional. Default: 600\n";
	Printf.printf "-window <hstart> <hend> <vstart> <vend>: Defines a window for rendering. hstart and hend are values between 0.0 and 1.0 defining a percentage of width. The same for vstart and vend respecting height. Default: 0.0 1.0 0.0 1.0 (hole picture)\n";
	Printf.printf "-u <value>: Unit length. Optional. Default: 1.0\n";
	Printf.printf "-net: Only for use with Network Workbench (http://nwb.slis.indiana.edu).\n";
	Printf.printf "-java: Shows the visualization in a window (Requires java).\n";
	Printf.printf "-render <renderer>: Selects the render engine. Possible values: 'povray' and 'svg'. Default: povray\n";
	Printf.printf "-opacity <value>: Selects the edges opacity. Only for SVG graphics. Range: 0.0-1.0. Optional. Default: 0.2\n";
	Printf.printf "-nocliques: Omits cliques in central core.\n";
	Printf.printf "-kconn: Computes k-connectivity.\n";
	Printf.printf "-onlygraphic: Generates the .png from an existing povray or svg file. In this case -input contains the .pov or .svg file. Default: false. Valid parameters in this case are: render, java\n";
	Printf.printf "-nographic: Omits generating the .png file.\n";
	Printf.printf "These parameters can also be set in file lanet.cfg.\n";
	Printf.printf "\n";
	
	method validateParameters =
		let isInputFilePresent = ref false in
		let isOutputFilePresent = ref false in
		let actualPar = ref 1 in
		
		(**Config file parameters*)
		let f_input = Unix.openfile "lanet.cfg" (Unix.O_RDWR :: []) 511 in
		
		(**Read first line*)
		let line = ref "" in
		let n = ref (readLine f_input line) in
		while !n > 0 do
			(try
				if (String.get !line 0 <> '#') then
				begin
					
					let name = Scanf.sscanf !line "%s =" (fun a -> a) in
					match name with
						"bckgnd" -> 
							let bckGndValue = Scanf.sscanf !line "%s = %s" (fun a b -> b) in
							if bckGndValue = "white" then
								bckGnd <- "white"
							else 
								if bckGndValue = "black" then
									bckGnd <- "black";
						| "color" -> 
							let colorValue = Scanf.sscanf !line "%s = %s" (fun a b -> b) in
							if colorValue = "col" then
								color <- "col"
							else 
								if colorValue = "bw" then
									color <- "bw"
								else
									if colorValue = "bwi" then
										color <- "bwi";
						| "eps" -> 
							epsilon <- Scanf.sscanf !line "%s = %f" (fun a b -> b);
						| "delta" -> 
							delta <- Scanf.sscanf !line "%s = %f" (fun a b -> b);
						| "gamma" -> 
							gamma <- Scanf.sscanf !line "%s = %f" (fun a b -> b);
						| "edges" -> 
							percentOfEdges <- Scanf.sscanf !line "%s = %f" (fun a b -> b);
						| "minedges" -> 
							minEdges <- Scanf.sscanf !line "%s = %d" (fun a b -> b);
						| "granularity" -> 
							granularity <- Scanf.sscanf !line "%s = %d" (fun a b -> b);
						| "width" -> 
							widthResolution <- Scanf.sscanf !line "%s = %d" (fun a b -> b);
						| "height" -> 
							heightResolution <- Scanf.sscanf !line "%s = %d" (fun a b -> b);
						| "u" -> 
							u <- Scanf.sscanf !line "%s = %f" (fun a b -> b);
						| "render" -> 
							let rendererValue = Scanf.sscanf !line "%s = %s" (fun a b -> b) in
							if rendererValue = "povray" then
								renderer <- "povray"
							else 
								if rendererValue = "svg" then
									renderer <- "svg"
						| "opacity" -> 
							opacity <- Scanf.sscanf !line "%s = %f" (fun a b -> b);
						| "strengthsIntervals" -> 
							strengthsIntervals <- Scanf.sscanf !line "%s = %s" (fun a b -> b);
						| _ -> ();
				end;
			with
			Invalid_argument s -> ();
			| End_of_file -> ());
			
			(**Read next line*)
			line := "";
			n := readLine f_input line;
		done;
		
						
		(**Command line parameters*)
		while !actualPar < Array.length Sys.argv do
			let parameterName = Sys.argv.(!actualPar) in
			match parameterName with
			"-input" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-input' parameter must be followed by input file name\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					inputFile <- Sys.argv.(!actualPar + 1);
					isInputFilePresent := true;
				end;
				actualPar := !actualPar + 2;
			| "-names" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					inputNodeNamesFile <- "0";
					actualPar := !actualPar + 1;
				end
				else
					if Sys.argv.(!actualPar + 1).[0] <> '-' then
					begin
						inputNodeNamesFile <- Sys.argv.(!actualPar + 1);
						actualPar := !actualPar + 2;
					end
					else
					begin
						inputNodeNamesFile <- "0";
						actualPar := !actualPar + 1;
					end;
			| "-output" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-output' parameter must be followed by output file name\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					outputFile <- Sys.argv.(!actualPar + 1);
					outputFile <- String.concat "" (outputFile :: ".pov" :: []);
					outputPngFile <- String.concat "" (outputFile :: ".png" :: []);
					isOutputFilePresent := true;
				end;
				actualPar := !actualPar + 2;
			| "-coresfile" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-coresfile' parameter must be followed by cores file name\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					coresFile <- Sys.argv.(!actualPar + 1);
				end;
				actualPar := !actualPar + 2;
			| "-logfile" ->
				actualPar :=  !actualPar + 1;
				isLogFile <- true;
			| "-logstdout" ->
				actualPar := !actualPar + 1;
				log#setLogStdout;
			| "-multigraph" ->
				actualPar := !actualPar + 1;
				multigraph <- true;
			| "-weighted" ->
				actualPar := !actualPar + 1;
				weighted <- true;
			| "-granularity" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-granularity' parameter must be followed by granularity (integer)\n\n";
					self#printHelp;
					exit 1;
				end
				else
					granularity <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%d" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-bckgnd" -> 
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-bckgnd' parameter must be followed by background color value\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					let bckGndValue = Scanf.sscanf Sys.argv.(!actualPar + 1) "%s" (fun a -> a) in
					actualPar := !actualPar + 2;
					if bckGndValue = "white" then
						bckGnd <- "white"
					else 
						if bckGndValue = "black" then
							bckGnd <- "black"
						else
						begin
							Printf.printf "ERROR: '%s' is not a possible value for bckgnd. Possible values are 'white' and 'black'.\n\n" bckGndValue;
							self#printHelp;
							exit 1;
						end;
				end;
			| "-color" -> 
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-color' parameter must be followed by graph color value\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					let colorValue = Scanf.sscanf Sys.argv.(!actualPar + 1) "%s" (fun a -> a) in
					actualPar := !actualPar + 2;
					if colorValue = "col" then
						color <- "col"
					else 
						if colorValue = "bw" then
							color <- "bw"
						else
							if colorValue = "bwi" then
								color <- "bwi"
							else
							begin
								Printf.printf "ERROR: '%s' is not a possible value for color. Possible values are 'col', 'bw' and 'bwi'.\n\n" colorValue;
								self#printHelp;
								exit 1;
							end;
				end;
			| "-eps" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-eps' parameter must be followed by epsilon value\n\n";
					self#printHelp;
					exit 1;
				end
				else
					epsilon <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-delta" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-delta' parameter must be followed by delta value\n\n";
					self#printHelp;
					exit 1;
				end
				else
					delta <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-gamma" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-gamma' parameter must be followed by gamma value\n\n";
					self#printHelp;
					exit 1;
				end
				else
					gamma <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-edges" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-edges' parameter must be followed by percent of visible edges (0.0 - 1.0)\n\n";
					self#printHelp;
					exit 1;
				end
				else
					percentOfEdges <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-minedges" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-minedges' parameter must be followed by minimum number of visible edges (integer)\n\n";
					self#printHelp;
					exit 1;
				end
				else
					minEdges <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%d" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-W" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-W' parameter must be followed by width value\n\n";
					self#printHelp;
					exit 1;
				end
				else
					widthResolution <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%d" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-H" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-H' parameter must be followed by height value\n\n";
					self#printHelp;
					exit 1;
				end
				else
					heightResolution <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%d" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-window" ->
				if Array.length Sys.argv < !actualPar + 5 then
				begin
					Printf.printf "ERROR: '-H' parameter must be followed by four values: hstart hend vstart vend\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					hstart <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
					hend <- Scanf.sscanf Sys.argv.(!actualPar + 2) "%f" (fun a -> a);
					vstart <- Scanf.sscanf Sys.argv.(!actualPar + 3) "%f" (fun a -> a);
					vend <- Scanf.sscanf Sys.argv.(!actualPar + 4) "%f" (fun a -> a);
				end;
				actualPar := !actualPar + 5;
			| "-u" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-u' parameter must be followed by unit length value\n\n";
					self#printHelp;
					exit 1;
				end
				else
					u <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-net" ->
				format <- "net";
				actualPar := !actualPar + 1;
			| "-java" ->
				show <- "java";
				actualPar := !actualPar + 1;
			| "-render" -> 
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-render' parameter must be followed by renderer name\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					let rendererValue = Scanf.sscanf Sys.argv.(!actualPar + 1) "%s" (fun a -> a) in
					actualPar := !actualPar + 2;
					if rendererValue = "povray" then
						renderer <- "povray"
					else 
						if rendererValue = "svg" then
							renderer <- "svg"
						else
						begin
							Printf.printf "ERROR: '%s' is not a possible value for render. Possible values are 'povray' and 'svg'.\n\n" rendererValue;
							self#printHelp;
							exit 1;
						end;
				end;
			| "-nocliques" ->
				noCliques <- true;
				actualPar := !actualPar + 1;
			| "-opacity" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-opacity' parameter must be followed by value.\n\n";
					self#printHelp;
					exit 1;
				end
				else
					opacity <- Scanf.sscanf Sys.argv.(!actualPar + 1) "%f" (fun a -> a);
				actualPar := !actualPar + 2;
			| "-kconn" ->
				kConn <- true;
				actualPar := !actualPar + 1;
			| "-onlygraphic" ->
				onlyGraphic <- true;
				actualPar := !actualPar + 1;
			| "-nographic" ->
				noGraphic <- true;
				actualPar := !actualPar + 1;
			| "-strengthsIntervals" ->
				if Array.length Sys.argv < !actualPar + 2 then
				begin
					Printf.printf "ERROR: '-strengthsIntervals' parameter must be followed by 'equalNodesPerInterval' or 'equalIntervalSize'.\n\n";
					self#printHelp;
					exit 1;
				end
				else
				begin
					strengthsIntervals <- Sys.argv.(!actualPar + 1);
				end;
				actualPar := !actualPar + 2;
			| _ -> 
				Printf.printf "ERROR: '%s' is not a valid parameter\n\n" Sys.argv.(!actualPar);
				self#printHelp;
				exit 1;
		done;

		if (kConn = true) & (multigraph = true) then
		begin
			Printf.printf "ERROR: k-connectivity analysis for multigraphs is not implemented yet.\n\n";
			self#printHelp;
			exit 1;
		end;

		(**if (multigraph = true) & (weighted = true) then
		begin
			Printf.printf "ERROR: weighted graphs and multigraphs are incompatible. Use 'multigraph' if you have repeated edges, or 'weighted' if you have weights (real numbers) on edges.\n\n";
			self#printHelp;
			exit 1;
		end;*)

		if !isInputFilePresent = false then
		begin
			Printf.printf "ERROR: '-input' parameter is required\n\n";
			self#printHelp;
			exit 1;
		end;

		(**Default output file name*)
		if !isOutputFilePresent = false then
		begin
			(**This code will convert, e.g. "samples/netSample/net1.dat" in "net1.pov" and "net1.png"*)
			outputFile <- inputFile;
			(try
				outputFile <- String.sub inputFile 0 (String.rindex inputFile '.');
			with
				Not_found -> ();
			);
			(try
				outputFile <- String.sub outputFile ((String.rindex outputFile '/') + 1) ((String.length outputFile) - (String.rindex outputFile '/') - 1);
			with
				Not_found -> ();
			);
			(try
				outputFile <- String.sub outputFile ((String.rindex outputFile '\\') + 1) ((String.length outputFile) - (String.rindex outputFile '\\') - 1);
			with
				Not_found -> ();
			);
			let bck =
				if bckGnd = "black" then
					"b"
				else
					"w"
			in
			
			outputRendFile <- String.concat "" (outputFile :: "_" :: color :: "_" :: bck :: "_" :: (string_of_int widthResolution) :: "x" :: (string_of_int heightResolution) :: []);
			if renderer = "povray" then
			begin
				if (kConn = true) then
					outputRendFile <- String.concat "" (outputRendFile :: "_kconn" :: []);
				if (inputNodeNamesFile <> "") then
					outputRendFile <- String.concat "" (outputRendFile :: "_names" :: []);
				outputRendFile <- String.concat "" (outputRendFile :: ".pov" :: []);
				
			end
			else
			begin
				if (kConn = true) then
					outputRendFile <- String.concat "" (outputRendFile :: "_kconn" :: []);
				if (inputNodeNamesFile <> "") then
					outputRendFile <- String.concat "" (outputRendFile :: "_names" :: []);
				outputRendFile <- String.concat "" (outputRendFile :: ".svg" :: []);
			end;

			if (onlyGraphic = false) then
			begin
				if renderer = "povray" then
				begin
					outputPngFile <- String.concat "" (outputFile :: "_" :: color :: "_" :: bck :: "_" :: (string_of_int widthResolution) :: "x" :: (string_of_int heightResolution) :: []);
					if (kConn = true) then
						outputPngFile <- String.concat "" (outputPngFile :: "_kconn" :: []);
					if (inputNodeNamesFile <> "") then
						outputPngFile <- String.concat "" (outputPngFile :: "_names" :: []);
					outputPngFile <- String.concat "" (outputPngFile :: "POV" :: ".png" :: []);
				end
				else
				begin
					outputPngFile <- String.concat "" (outputFile :: "_" :: color :: "_" :: bck :: "_" :: (string_of_int widthResolution) :: "x" :: (string_of_int heightResolution) :: []);
					if (kConn = true) then
						outputPngFile <- String.concat "" (outputPngFile :: "_kconn" :: []);
					if (inputNodeNamesFile <> "") then
						outputPngFile <- String.concat "" (outputPngFile :: "_names" :: []);
					outputPngFile <- String.concat "" (outputPngFile :: "SVG" :: ".png" :: []);
				end;
			end
	
			
			else
			begin
				if renderer = "povray" then
					outputPngFile <- String.concat "" (outputFile :: "POV" :: ".png" :: [])
				else
					outputPngFile <- String.concat "" (outputFile :: "SVG" :: ".png" :: []);
			end;

		end;
		
		if isLogFile then
			log#setLogFile inputFile;
		
end;;

(**The parameters object*)
let parameters = new parameters_class;;
