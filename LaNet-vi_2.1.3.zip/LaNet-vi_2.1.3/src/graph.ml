(**This module defines a graph as a set of vertices and edges G=(V,E) and allows to add vertices and edges*)

open Log;;

module TOraculo = Map.Make(struct
type t = int
let compare = compare
end);;

(**Definition of class graph G=(V,E)*)
class ['a] graph_class (v:'a) =
let arraySize' = 10000 in

object (self)
	 
	val arraySize = arraySize'
	val mutable maxVertex = -1
	
	(**A tree used to map the nodes numers in the file to the numbers used in the graph structure*)
	val mutable oraculo = TOraculo.empty;

	method getMaxVertex = maxVertex
		
	(**A prototype used to construct vertices*)
	val vertexPrototype = v
	
	(**Maximum degree of a vertex. Initially set to -1 (unknown)*)
	val mutable maxDegree = -1

	(**Returns maximum degree*)
	method getMaxDegree = maxDegree;
		
	(**Maximum pValue. (For weighted graphs)*)
	val mutable maxPValue = -1
	
	(**Returns maximum pValue*)
	method getMaxPValue = maxPValue;
	
	val mutable strengths = []

	val mutable maxStrength = 0.0

	method getMaxStrength = maxStrength;

	(**Table containing the p-function. 'p(n) = h' iff 'n is between the (h-1) and the h element in this list'*)
	val mutable pFunction = [];
	
	method getPFunction = pFunction;

	val mutable amountOfEdges = 0;
	
	method getAmountOfEdges = amountOfEdges;
	
	method setVertexName i n = 
		(self#getVertex i)#setName n;

	(**Set of vertices. This corresponds to V. E is given by vertices' neighbours. For efficiency, V was implemented as a list of preallocated arrays. Each array has a fixed size, when more vertices are needed, a new array is created and appended at the end of the list.*)
	val mutable vertices = let f = fun i -> Oo.copy v in Array.init arraySize' f :: []
 	
	method addVertexNumber v_file : unit = 
	
	let v =
	(**Verifies if the vertex exists with the oraculo*)
	if TOraculo.mem v_file oraculo then
		(**If it exists, I get its number in the graph*)
		TOraculo.find v_file oraculo
	else
	begin
		(**Otherway, I assign a new number to it*)
		maxVertex <- maxVertex + 1;		
		maxVertex
	end in

	let v_new = Oo.copy vertexPrototype in
		(**v_new#setNumber v;*)
		v_new#setNumberInFile v_file;
		(**Updates the oraculo*)
		oraculo <- TOraculo.add v_new#getNumberInFile v oraculo;

		(**Computes which array this vertex belongs to*)
		let posList = v / arraySize in
			let posArray = v mod arraySize in
			if List.length vertices <= posList then
			begin
				for i = List.length vertices to posList do
					(**Testing*)
					log#print (Printf.sprintf "Building vector %d in list\n" i) "algorithm";
					vertices <- vertices @ let f = fun i -> Oo.copy vertexPrototype in Array.init arraySize' f :: []
				done
			end;
	
		(List.nth vertices posList).(posArray) <- v_new;


	(**Adds the graph a new vertex. Receives the vertex. Only the neighbours in the graph are left as vertex neighbours*)
	method addVertex vertex : unit = 
	let v =
	(**Verifies if the vertex exists with the oraculo*)
	if TOraculo.mem vertex#getNumberInFile oraculo then
		(**If it exists, I get its number in the graph*)
		TOraculo.find v#getNumberInFile oraculo
	else
	begin
		(**Otherway, I assign a new number to it*)
		maxVertex <- maxVertex + 1;		
		maxVertex
	end in
	let v_new = Oo.copy vertex in
		(**v_new#setNumber v;*)
		
		(**Updates the oraculo*)
		oraculo <- TOraculo.add v_new#getNumberInFile v oraculo;
		
		(**Computes which array this vertex belongs to*)
		let posList = v / arraySize in
			let posArray = v mod arraySize in
			if List.length vertices <= posList then
			begin
				for i = List.length vertices to posList do
					(**Testing*)
					log#print (Printf.sprintf "Building vector %d in list\n" i) "algorithm";
					vertices <- vertices @ let f = fun i -> Oo.copy vertexPrototype in Array.init arraySize' f :: []
				done
			end;

		(List.nth vertices posList).(posArray) <- v_new;
		
		let rec navigateNeighbours nl i =
		match nl with
				[] -> ()
				| n :: l ->
					match n with (a1,a2) ->
					(**Analyzing if the vertex may exist*)

					if TOraculo.mem a1#getNumberInFile oraculo then
					begin
						v_new#removeNeighbour n;
					
						let number = TOraculo.find a1#getNumberInFile oraculo in
						let posList = number / arraySize in

						v_new#addNeighbour ((List.nth vertices posList).(number mod arraySize)) (vertex#getWeight i);
						((List.nth vertices posList).(number mod arraySize))#addNeighbour v_new (vertex#getWeight i);
						amountOfEdges <- amountOfEdges + 1;

										
						if ((List.nth vertices posList).(number mod arraySize))#getDegree > maxDegree then
							maxDegree <- ((List.nth vertices posList).(number mod arraySize))#getDegree;
					end
					else
						v_new#removeNeighbour n;

					navigateNeighbours l (i+1)
		in
		navigateNeighbours vertex#getNeighbours 0;		
		
		if v_new#getDegree > maxDegree then
			maxDegree <- v_new#getDegree;
		(**if v_new#getNumberInFile > maxVertex then
			maxVertex <- v_new#getNumberInFile;*)


	(**Returns a vertex given its number in the file*)
	method getVertex numberInFile =
		let n = (TOraculo.find numberInFile oraculo) in
		let posList = n / arraySize in
		(List.nth vertices posList).(n mod arraySize)

	method getVertexInList i =
		let posList = i / arraySize in
		(List.nth vertices posList).(i mod arraySize)

	(**Adds the graph a new edge. If any or both of the extreme vertices don't exist, they're created.
	Receives both vertices' numbers*)
	method addEdge vertex1InFile vertex2InFile weight: unit =
		log#print (Printf.sprintf "Inserting edge %d-%d\n" vertex1InFile vertex2InFile) "vertexInsertion";

		(**If vertex1 doesn't exist, it's created*)
		if (TOraculo.mem vertex1InFile oraculo = false) then 
		begin
			maxVertex <- maxVertex + 1;		
			let v1 = maxVertex in

			oraculo <- TOraculo.add vertex1InFile v1 oraculo;

			let v_new = Oo.copy vertexPrototype in
			v_new#setNumberInFile vertex1InFile;

			(**Computes which array this vertex belongs to*)
			let posList1 = v1 / arraySize in
			let posArray1 = v1 mod arraySize in
			if List.length vertices <= posList1 then
			begin
				for i = List.length vertices to posList1 do
					(**Testing*)
					log#print (Printf.sprintf "Building vector %d in list\n" i) "algorithm";
					vertices <- vertices @ let f = fun i -> Oo.copy vertexPrototype in Array.init arraySize' f :: []
				done
			end;
	
			(List.nth vertices posList1).(posArray1) <- v_new;
		end;
		
		(**If vertex2 doesn't exist, it's created*)
		if (TOraculo.mem vertex2InFile oraculo = false) then 
		begin
			maxVertex <- maxVertex + 1;		
			let v2 = maxVertex in

			oraculo <- TOraculo.add vertex2InFile v2 oraculo;

			let v_new = Oo.copy vertexPrototype in
			v_new#setNumberInFile vertex2InFile;

			(**Computes which array this vertex belongs to*)
			let posList2 = v2 / arraySize in
			let posArray2 = v2 mod arraySize in
			if List.length vertices <= posList2 then
			begin
				for i = List.length vertices to posList2 do
					(**Testing*)
					log#print (Printf.sprintf "Building vector %d in list\n" i) "algorithm";
					vertices <- vertices @ let f = fun i -> Oo.copy vertexPrototype in Array.init arraySize' f :: []
				done
			end;
	
			(List.nth vertices posList2).(posArray2) <- v_new;
		end;
		(**Neighbours are assigned*)
		let v1 = TOraculo.find vertex1InFile oraculo in
		let v2 = TOraculo.find vertex2InFile oraculo in
		let v_obj_1 = (List.nth vertices (v1 / arraySize)).(v1 mod arraySize) in
		let v_obj_2 = (List.nth vertices (v2 / arraySize)).(v2 mod arraySize) in
		
		(**MULTIGRAPH*)
		if (Parameters.parameters#getMultigraph = false) & (List.exists (fun (a,b) -> a=v_obj_1) (v_obj_2#getNeighbours)) then
			log#print (Printf.sprintf "	Edge existed\n") "vertexInsertion"
		else
		begin
			v_obj_1#addNeighbour v_obj_2 weight;
			v_obj_2#addNeighbour v_obj_1 weight;
			amountOfEdges <- amountOfEdges + 1;
			if	v_obj_1#getDegree > maxDegree then
				maxDegree <- v_obj_1#getDegree;
			if	v_obj_2#getDegree > maxDegree then
				maxDegree <- v_obj_2#getDegree;

		end;


	method addName vertex name =
			if TOraculo.mem vertex oraculo then
			begin
				let n = TOraculo.find vertex oraculo in
				let posList = n / arraySize in
				(List.nth vertices posList).(n mod arraySize)#setName name;
			end;

	(**This is a test function. It prints the complete graph*)
	method printGraph =
		log#print (Printf.sprintf "Graph BEGIN\n") "graph";
		for i= 0 to (List.length vertices * arraySize -1) do
			let posList = i / arraySize in
			if (List.nth vertices posList).(i mod arraySize)#isVertex then
			begin
				(List.nth vertices posList).(i mod arraySize)#printVertex "graph";
			end
		done;
		log#print (Printf.sprintf "Graph END\n") "graph";
		
	method buildPFunction =
		let g = ref Parameters.parameters#getGranularity in
		if (!g = -1) then
			g := maxDegree;
		pFunction <- List.append pFunction (0.0::[]);

		if Parameters.parameters#getStrengthsIntervals = "equalNodesPerInterval" then
		begin
			let n = ref (int_of_float (Pervasives.ceil(float (maxVertex + 1) /. float !g))) in
			if (!n = 0) then
			n := 1;
			let i = ref 0 in
			while !i < maxVertex + 1 do
				i := !i + !n;
				if !i >= maxVertex + 1 then
					pFunction <- List.append pFunction ((List.nth strengths (maxVertex))::[])
				else
					pFunction <- List.append pFunction ((List.nth strengths (!i-1))::[]);
			done;
		end
		else (**equalIntervalSize*)
		begin
			let n = (List.nth strengths (maxVertex) /. float !g) in
			let i = 0 in
			for i = 1 to !g do
				if (i <> !g) then
					pFunction <- List.append pFunction (((float i) *. n)::[])
				else
					pFunction <- List.append pFunction ((List.nth strengths (maxVertex))::[])
			done
		end;
	
	method computeDiameter2 = 

		let ov = int_of_float (2.00 ** 32.0 -. 1.0) in

		(**Constructing vectors*)
		let v = ref (Array.init (maxVertex/32 + 1) (fun a -> 0)) in
		if ((maxVertex+1) mod 32 <> 0) then
			(!v).(maxVertex/32) <- ov - int_of_float (2.0 ** float_of_int((maxVertex+1) mod 32) -. 1.0);
		let f = fun i -> Array.copy !v in
		let vl = ref (Array.init (maxVertex+1) f) in
		let vl2 = ref (Array.init (maxVertex+1) f) in

		for i = 0 to maxVertex do
			let posArray = i/ 32 in
			(!vl).(i).(posArray) <- (!vl).(i).(posArray) lor int_of_float (2.0 ** float_of_int (i mod 32));
			let n = self#getVertexInList i in
			let rec neighbours nl =
			match nl with
			[] -> ()
			| n :: l ->
				match n with (n1, n2) ->
				let number = TOraculo.find n1#getNumberInFile oraculo in
				let posArray = number/ 32 in
				(!vl).(i).(posArray) <- (!vl).(i).(posArray) lor int_of_float (2.0 ** float_of_int (number mod 32));
				neighbours l;
			in
			neighbours n#getNeighbours;
		done;

		(**ORs*)
		for i = 0 to maxVertex do
			let n = self#getVertexInList i in
			for j = 0 to (maxVertex/32) do
				(!vl2).(i).(j) <- (!vl).(i).(j);
			done;
			let rec neighbours nl =
			match nl with
			[] -> ()
			| n :: l ->
				match n with (n1, n2) ->
				let number = TOraculo.find n1#getNumberInFile oraculo in
				for j = 0 to (maxVertex/32) do
					(!vl2).(i).(j) <- (!vl2).(i).(j) lor (!vl).(number).(j)
				done;
				neighbours l
			in
			neighbours n#getNeighbours;		
			(**Printf.printf "Vector %d: %x\n" n#getNumberInFile (!vl2).(i).(0);*)
		done;

		(**Verifying*)
		let result = ref 2 in
		for i = 0 to maxVertex do
			for j = 0 to (maxVertex/32) do
				if (!vl2).(i).(j) <> ov then
				begin
					result := 3;
				end
			done;
		done;
		!result;

	
	method endGraph =
		(**Sorting of strengths list, if it's a weighted graph*)
		if (Parameters.parameters#getWeighted = true)&&(Parameters.parameters#getMultigraph = false) then
		begin
			for i= 0 to (List.length vertices * arraySize -1) do
				let posList = i / arraySize in
				if (List.nth vertices posList).(i mod arraySize)#isVertex then
				begin
					let strength = (List.nth vertices posList).(i mod arraySize)#getStrength in
					strengths <- strength::strengths;
					if strength > maxStrength then
						maxStrength <- strength;
				end
			done;
			strengths <- List.sort (fun a b -> (if a > b then 1 else -1)) strengths;

			(**let rec printStrengthsList w = 
			match w with
				[] -> ()
				| a :: l ->
					Printf.printf "%f " a;
					printStrengthsList l;
			in
			printStrengthsList strengths;
			Printf.printf "\n";*)
			(**p-function is built*)
			self#buildPFunction;
		end;

		(**p-function is applied to every vertex (every vertex applies it to each of its edges*)
		for i= 0 to (List.length vertices * arraySize -1) do
			let posList = i / arraySize in
			if (List.nth vertices posList).(i mod arraySize)#isVertex then
			begin
				let p = (List.nth vertices posList).(i mod arraySize)#getP pFunction (-2) in
				if p > maxPValue then
					maxPValue <- p;
			end
			
		done;

end;;
