(**This module defines a vertex as a node with a number and a set of neighbours, and allows to create vertices and append neighbours to them*)

open Log;;

(**Definition of class vertex*)
class ['a] vertex_class (**(number': int)*) (numberInFile': int)  =
object (self)

	(**Vertex's number. A value of -1 means this object is empty (it does not contain a real vertex). This allows to preallocate an array of vertex_class and realize which of them are real vertices and which of them are empty.*)
	(**val mutable number = number'*)
	
	val mutable numberInFile = numberInFile'

	(**Vertex's clustering coeficient*)
	val mutable cc = 0.0
	
	(**Vertex's p-value. Computed from degree or edges weight, depending on the graph being weighted or not.*)
	val mutable pValue = 0
	
	(**Vertex's amount of neighbours*)
	val mutable amountNeighbours = 0
	
	(**Gets the vertex's amount of neighbours (degree)*)
	method getAmountNeighbours = amountNeighbours
	
	(**Gets the vertex's degree*)
	method getDegree = amountNeighbours

	(**List of neighbour vertices references, weights and p-values*)
	val mutable neighbours = []

	method getWeight i =
		let n = List.nth neighbours i in
		match n with (a,b) ->
		b;

	method getStrength =
		let s = ref 0.0 in
		for n = 0 to ((List.length neighbours) - 1) do
			let i = (List.nth neighbours n) in
			match i with (nb, w) ->
			s := !s +.  w;
		done;
		!s;
	
	(**Returns sum of p-values of all edges*)
	method getP pFunction i = 
		self#applyPFunction pFunction i;
		pValue;
		
	val mutable name = ""
	
	(**True if this object contains a vertex. False if it's empty*)
	method isVertex =
		if numberInFile = (-1) then
			false
		else
			true
	
	(**Gets the vertex number*)
	(**method getNumber = number*)

	(**Gets the vertex number in the file*)
	method getNumberInFile = numberInFile
	
	method setName n = name <- n;
	
	method getName = name;
	
	(**Sets the vertex number*)
	(**method setNumber new_number = number <- new_number;*)

	(**Sets the vertex number in the file*)
	method setNumberInFile new_number_in_file = numberInFile <- new_number_in_file;
	
	(**Sets the clustering coeficient*)
	method setClusteringCoeficient new_cc = cc <- new_cc;
	
	(**Returns the clustering coeficient*)
	method getClusteringCoeficient = cc;
	
	(**Adds a new neighbour to this vertex*)
	method addNeighbour (vertex : 'a) (weight : float) =
		(**MULTIGRAPH*)
		if (Parameters.parameters#getMultigraph = true) || (not (List.exists (fun (a,b) -> a = vertex) neighbours)) then
		begin
			if (Parameters.parameters#getMultigraph = false) && (List.exists (fun (a,b) -> a#getNumberInFile = vertex#getNumberInFile) neighbours) then
			begin
				let v = List.find (fun (a,b) -> a#getNumberInFile = vertex#getNumberInFile) neighbours in
			 	
				self#removeNeighbour v;
			end;

			if (Parameters.parameters#getWeighted = true) then
			begin
				neighbours <- (vertex, weight)::neighbours
			end
			else
				neighbours <- (vertex, 1.0)::neighbours;

			if (Parameters.parameters#getMultigraph = true)&(Parameters.parameters#getWeighted = true) then
				amountNeighbours <- amountNeighbours + int_of_float weight
			else
				amountNeighbours <- amountNeighbours + 1;

		end;
	
	(**Removes a neighbour to this vertex*)
	method removeNeighbour (n : ('a * float)) =
		match n with (d,e) ->
		if List.exists (fun (a,b) -> a#getNumberInFile = d#getNumberInFile) neighbours then
		begin
			neighbours <- List.filter (fun (a,b) -> a#getNumberInFile <> d#getNumberInFile) neighbours;
			amountNeighbours <- List.length neighbours;
		end
		
		
	(**Gets a reference to the list of neighbours*)
	method getNeighbours : ('a * float) list = neighbours
	
	(**Returns true if vertex is v's neighbour*)
	method isNeighbourOf (vertex: 'a) =
		List.exists (fun (a,b) -> (a = vertex)) neighbours
	
	method applyPFunction pFunction i =
		let p = ref 0 in
		
		let strength = ref 0.0 in
		let rec sumWValues pl =
		match pl with
		[] -> ()
		| n :: l ->
			match n with (nb, w) ->
			if (nb#getShellIndex > i) then
			begin
				if (Parameters.parameters#getWeighted = true)&&(Parameters.parameters#getMultigraph = false) then
					strength := !strength +. w
				else
				begin
					p := !p + int_of_float w;
				end;
			end;
			sumWValues l;
		in
		sumWValues neighbours;

		if (Parameters.parameters#getWeighted = true)&(Parameters.parameters#getMultigraph=false) then
		begin
			p := 0;
			while (List.nth pFunction !p) < !strength do
				p := !p + 1;
			done;
		end;
		if (!p<i) then
			p := i;
		pValue <- !p;
	
			
	(**This is a test function. It prints vertex number and its neighbours*)
	method printVertex section =
		log#print (Printf.sprintf "Vertex number: %d\n" numberInFile) section;
		
		for n = 0 to ((List.length neighbours) - 1) do
			if Parameters.parameters#getWeighted = true then
			begin
				let i = List.nth neighbours n in
				match i with (nb, w) ->
				log#print (Printf.sprintf "	Neighbour: %d %f\n" nb#getNumberInFile w) section;
			end
			else
			begin
				let i = List.nth neighbours n in
				match i with (nb, w) ->
				log#print (Printf.sprintf "	Neighbour: %d\n" nb#getNumberInFile) section;
			end;
			
		done;
			
end;;
