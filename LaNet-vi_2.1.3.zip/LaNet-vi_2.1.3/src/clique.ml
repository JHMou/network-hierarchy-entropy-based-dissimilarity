open Log;;

class type graph = object ('a)
	
	method getMaxVertex: int
	
	method getVertex: int -> Host.host_class
	
	method getVertexInList: int -> Host.host_class
	
	method printGraph: unit
	
end;;

class clique_class =
object (self)
	
	val mutable cliques = []
	
	(**Gets a graph and returns a list of lists*)
	method buildCliques : 'a 'b. (#graph as 'a) -> int -> unit =
		cliques <- [];
		
		fun graph maxShellIndex ->
		let l = ref [] in
		Printf.printf "Building cliques...\n";
		
		graph#printGraph;
		(**Initially, all vertexes in the same list*)
		for i= 0 to graph#getMaxVertex do
			let v = graph#getVertexInList i in
			if v#isVertex = true then
			begin
				l := List.append !l (v::[]);
			end;
		done;
		
		(**Computes clustering coeficients*)
		let rec computeClusteringCoeficients listCliques =
			match listCliques with
				[] -> ()
				| v :: l -> 
					(**For each vertex, I compute its clustering coeficient*)
					let m = ref 0 in
					let n = ref 0 in
					(**Printf.printf "Processing vertex %d\n" v#getNumberInFile;*)
					let rec navigateNeighbours neighbours =
					match neighbours with
						[] -> ()
						| nb :: l ->
							(**If it belongs to the max core*)
							(**Printf.printf "	Processing neighbour %d\n" nb#getNumberInFile;*)
							match nb with (a,b) ->
							if a#getShellIndex = maxShellIndex then
							begin
								(**It counts as a neighbour*)
								n := !n + 1;
								(**For each neighbour of nb, if it's v'neighbour too, then it's a connection among neighbours*)
								let rec navigateNbNeighbours nbneighbours =
								match nbneighbours with
									[] -> ()
									| nbnb :: l ->
										match nbnb with (a,b) ->
										(**Printf.printf "	Processing neighbour of neighbour %d\n" nbnb#getNumber;*)
										(**If it belongs to the max core and is neighbour of both*)
										if (a#isNeighbourOf v) && (a#getShellIndex = maxShellIndex) then
										begin
											m := !m + 1;
										end;
										navigateNbNeighbours l
								in
								navigateNbNeighbours a#getNeighbours;		
							end;
							navigateNeighbours l
					in
					navigateNeighbours v#getNeighbours;

					(**let cc = (float !m)/.(float (!n*(!n-1))) in*)
					(**Not clustering coeficients, but amount of connections among neighbours*)
					let cc = (float !m) in
					
					v#setClusteringCoeficient cc;
					
					computeClusteringCoeficients l;
		in
		computeClusteringCoeficients !l;
		(**Printf.printf "Clustering Coeficients computed.\n";*)
		
		(**Sorting list according to clustering coeficients*)
		let comp = fun a b -> 
		match a with (a1, a2) ->
		match b with (b1, b2) ->
		if a1#getClusteringCoeficient > b1#getClusteringCoeficient then
			-1
		else
			if a1#getClusteringCoeficient < b1#getClusteringCoeficient then
				1
			else
				0
		in
		
		let comp2 = fun a b -> 
		if a#getClusteringCoeficient > b#getClusteringCoeficient then
			-1
		else
			if a#getClusteringCoeficient < b#getClusteringCoeficient then
				1
			else
				0
		in
				
		l := List.sort comp2 !l;
		(**Printf.printf "List sorted by clustering coeficients.\n";*)
		
		(***)	
		while List.length !l <> 0 do
			(**Printf.printf "\tStarting a clique. Nodes left in the list: %d\n" (List.length !l);*)
			
			let logging = ref "" in
			logging := Printf.sprintf "Clique:" ;
			
			let v = List.nth !l 0 in
			
			(**Printf.printf "\t\tNode %d added, cc=%f\n" v#getNumberInFile v#getClusteringCoeficient;*)
			logging := Printf.sprintf "%s %d" !logging v#getNumberInFile;
			
			let nb = v#getNeighbours in
			
			let clique = ref (v :: []) in
			
			(**Removing neighbours that are not in l*)			
			let nbToClique = ref nb in
			
			nbToClique := List.filter (fun (a,b) -> List.exists (fun (d) -> d = a) !l) !nbToClique;
		
			nbToClique := List.sort comp !nbToClique;
			
			(**Printf.printf "NBToClique tiene %d\n" (List.length !nbToClique);*)
			while (List.length !nbToClique <> 0) do
			
				match (List.hd !nbToClique) with (a,b) ->
				let front = ref a in
				
				nbToClique := List.tl !nbToClique;
				(**Printf.printf "Tomo: %d\n" !front#getNumberInFile;*)
			
				let rec findAllInClique clique v =
					match clique with
					[] -> true
					| c :: cl ->
						if (c <> v) && (not (List.exists (fun (a,b) -> a = v) c#getNeighbours)) then
							false
						else
							findAllInClique cl v
				in
			
				if (findAllInClique !clique !front) = true then
				begin
					clique := List.append !clique (!front::[]);
					(**Printf.printf "Added\n";*)
					logging := Printf.sprintf "%s %d" !logging !front#getNumberInFile;
			
				end;
				
			done;

			logging := Printf.sprintf "%s\n" !logging;
			log#print !logging "cores";
			
			let rec removeNeighboursFromList nbs =
				match nbs with
				[] -> ()
				| n :: nl ->
					clique := List.filter (fun a -> a <> n) (!clique);
					clique := List.append (!clique) (n::[]);
					(**Printf.printf "%d " n#getNumberInFile;*)
					l := List.filter (fun a -> a <> n) (!l);
					removeNeighboursFromList nl;
			in
			(**Printf.printf "\t\tNeighbours added: ";*)
			
			removeNeighboursFromList !clique;
			l := List.filter (fun a -> a <> v) (!l);
					
			(**Printf.printf "\t\t(tam desp %d) " (List.length !l);*)
			
			let compareHosts = fun a b -> 
				if a#getNumberInFile > b#getNumberInFile then
					1
				else
					-1
			in
			clique := List.sort compareHosts !clique;
			cliques <- List.append cliques (!clique::[]);

			(**Printf.printf "\n";*)
			
		done;
	
	method getCliques = cliques;
		
end;;

let clique = new clique_class;;
