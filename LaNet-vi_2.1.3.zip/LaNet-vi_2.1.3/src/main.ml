(**Main program*)
(**References: See "Large Scale Networks fingerprinting and visualization using the k-core decomposition, NIPS 2005". This paper will be referenced in this program as [NIPS2005]*)
open Log;;
open Parameters;;
open Graphics;;
open Povray;;
open Povray_renderer;;
open Svg_renderer;;
				
let main() =

		let renderFile = ref "" in
		
		(**Parameters validation*)
		parameters#printHeader;
		parameters#validateParameters;
		let inputFile = parameters#getInputFile in
		let outputFile = parameters#getOutputFile in
				
		Printf.printf "NETWORK: %s\n\n" inputFile;
					
		if Parameters.parameters#getOnlyGraphic = false then
		begin
				
			Printf.printf "Building graph...\n";
			flush stdout;
			
			(**Creates the network graph*)
			let n1 = new Network.network_class in
			
			(**Reads the network graph from file*)
			let builder = 
				if parameters#getFormat = "lanet" then
					new Graph_builder.graph_builder_class
				else
					new Graph_builder_nwb.graph_builder_nwb_class
				in
			builder#read_file n1 inputFile;

			if (parameters#getInputNodeNamesFile <> "")&&(parameters#getInputNodeNamesFile <> "0") then
			begin
				let node_names = new Graph_node_names.graph_node_names_class in
					node_names#read_file n1 parameters#getInputNodeNamesFile;
			end;

			n1#endGraph;

			n1#buildInitialLists;
			
			(**TEST: Prints the network graph*)
			n1#printGraph;
			
			(**TEST: Prints vertices grouped by degree*)
			n1#printLists;
			
			Printf.printf "Computing shell indexes...\n";
			flush stdout;
			
			(**Computes each vertex's shell index*)
			n1#computeShellIndex;
			
			(**TEST: Prints vertices grouped by shell index*)
			n1#printLists;
	
			if parameters#getCoresFile <> "" then
				n1#generateCoresFile parameters#getCoresFile;
					
			Printf.printf "Computing components and clusters...\n";
			flush stdout;
			
			(**Builds the components' structure*)
			n1#computeComponents;
			
			(**TEST: Prints components*)
			(**n1#printComponents;*)
	
			if parameters#getKConn = true then
			begin
			
				Printf.printf "Computing central core diameter <= 2...";
				flush stdout;
				
				(**For k-connectivity*)
				let diameter = n1#computeCentralCoreDiameter in
		
				if (diameter <> 1) && (diameter <> 2) then
				begin
					Printf.printf "Diameter > 2. k-connectivy analysis omitted.\n";
					flush stdout;
				end
				else
				begin
					Printf.printf "Determining k-connectivity...\n";
					flush stdout;
				
					(**For k-connectivity*)
					n1#determineConnectivity;
				end;
			end;
			
			Printf.printf "Finding coordinates...\n";
			flush stdout;
			
			(**Finds a position for each vertex*)
			n1#findCoordinates;

			(**TEST: Prints vertices' positions*)
			n1#printCoordinates;

			(**TEST: Prints central components*)
			n1#printCentralComponents;
	
			if parameters#getRenderer = "povray" then
				Printf.printf "Generating .pov file...\n"
			else 
			begin
				if parameters#getRenderer = "svg" then
					Printf.printf "Generating .svg file...\n";
			end;
			flush stdout;
	
			(**let ca = new Circular_average.circular_average_class in*)
			(**Printf.printf "Average 10, 358: %f\n" (ca#average 100.0 2 260.0 1);*)
	
			let engine =
				if parameters#getRenderer = "povray" then
					new Povray.povray_class outputFile
				else
					new Svg.svg_class outputFile
			in
			
			let graphics = new Graphics.graphics_class engine in
			
			graphics#generateNetworkFile n1;
			
			renderFile := outputFile;
		end
		else
		begin
			renderFile := inputFile;
		
		end;		

		if parameters#getNoGraphic = false then
		begin
			Printf.printf "Rendering image...\n";
			flush stdout;
		
			(**Render visualization*)
			if parameters#getRenderer = "povray" then
				povray_renderer#render !renderFile
			else
				svg_renderer#render !renderFile;
		end;
	
		Printf.printf "Done!\n";
		flush stdout;
		
		log#closeFiles;
		exit 0;;
main();;
