open Types;;

(**This class extends the functionality of a vertex*)

module IntMap = Map.Make(struct
type t = int
let compare = compare
end);;

(**Definition of class host*)
class host_class (number' : int) (**(numberInFile' : int)*) =
object (self)
	inherit [host_class] Vertex.vertex_class number' (**numberInFile'*)
	
	(**This host's subcomponent inside its parent component*)
	val mutable component = 0
	
	method getComponent = component
	
	method setComponent c = component <- c
	
	(**Previous host in the component*)
	val mutable prevHost: host_class list = []
	
	(**Next host in the component*)
	val mutable nextHost: host_class list = []
	
	(**This atribute keeps the last shellIndex for which the component number of this host was computed. It's initially 0, and will equal the shellIndex at the end.*)
	val mutable lastComponentComputed = 0
	
	val mutable clusterComputed = 0
	
	(**This host's unique cluster number*)
	val mutable id_cluster = 0
	
	(**This host's cluster inside its component*)
	val mutable cluster = 0
	
	method isClusterComputed = clusterComputed
	
	method setCluster c id = 
		cluster <- c;
		id_cluster <- id;
		clusterComputed <- 1

	method getCluster = cluster
	
	method getClusterId = id_cluster
	
	method setPrev h = prevHost <- h :: []
	
	method setNext h = nextHost <- h :: []
	
	method clearPrev = prevHost <- []
	
	method clearNext = nextHost <- []
	
	method hasPrev = List.length prevHost
	
	method hasNext = List.length nextHost
	
	method getPrev = List.nth prevHost 0
	
	method getNext = List.nth nextHost 0
	
	val mutable shellIndex = -1
	
	method getShellIndex = shellIndex
	
	method setShellIndex sh = shellIndex <- sh

	method setLastComponentComputed l = lastComponentComputed <- l
	
	method getLastComponentComputed = lastComponentComputed
	
	val mutable rho : float = -1.0
	
	method setRho r = rho <- r
	
	method getRho = rho
	
	val mutable phi : float = -1.0
	
	method setPhi p = phi <- p
	
	method getPhi = phi
	
	val mutable xCoord : float = 0.0
	
	method setX x = xCoord <- x
	
	method getX = xCoord
	
	val mutable yCoord : float = 0.0
	
	method setY y = yCoord <- y
	
	method getY = yCoord
	
	val mutable color = { r=0.00; g=0.00; b=0.00 }
	
	method setColor c = color <- c
	
	method getColor = color

	val mutable dplus = IntMap.empty

	(**List of (cliqueNumber, d+)*)
	method getdplus = dplus

	method adddplus (i:int) = IntMap.add i 0 dplus;

	method setdplus d = dplus <- d

	val mutable dminus = 0

	method getdminus = dminus

	method setdminus d = dminus <- d

	val mutable m = 0

	method getM = m

	method setM a = m <- a

	val mutable isKConnected = false

	method getIsKConnected = isKConnected

	method setIsKConnected i = isKConnected <- i

end;;
