(**This class implements a normal distribution number generator*)

(**Definition of class normal*)
class normal_class m d =
object (self)

	val mutable mean = m
	
	val mutable dev = d
	
	method setMean m = mean <- m
	
	method setDev d = dev <- d
	
	method getValue : float =
		let v = ref (float 1) in
		let n = 100 in
		(**A [0,1] normal distribution sample is obtained by averaging samples from a [-1,1] uniform distribution*)
		for i = 1 to n do
			v := !v +. ((Random.float (float 2)) -. (float 1));
		done;
		v := !v *. sqrt(3.00 /. float n);
		(**Denormalization*)
		mean +. (!v)*.dev;
end;;
