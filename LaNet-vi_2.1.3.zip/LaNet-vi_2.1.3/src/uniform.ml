(**This class implements a uniform distribution number generator*)

(**Definition of class uniform*)
class uniform_class mn mx =
object (self)

	val mutable min = mn
	
	val mutable max = mx
	
	method setMin m = min <- m
	
	method setMax m = max <- m
	
	method getValue : float =
		min +. Random.float (max -. min);
		
end;;

let uniform2Pi = new uniform_class (float 0) 6.28;;