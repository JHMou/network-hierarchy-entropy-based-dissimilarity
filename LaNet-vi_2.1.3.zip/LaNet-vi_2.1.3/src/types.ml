type color = {r: float; g: float; b: float};;

(**Rainbow colors*)
let magenta = { r = 1.0; g = 0.2; b = 1.00};;
let blue = { r = 0.2; g = 0.2; b = 1.};; 
let cyan = { r = 0.2; g = 1.; b = 1.};;
let green = { r = 0.2; g = 1.; b = 0.2};; 
let yellow = { r = 1.0; g = 1.0; b = 0.};;
let red = { r = 1.; g = 0.2; b = 0.2};; 

(**Colors list for color image*)
let rainbow = [ (magenta, 0.01); (blue, 0.20); (cyan, 0.35); (green,0.50); (yellow,0.65); (red,0.97)];;

(**B&W scale*)
let white = { r = 2.; g = 2.; b = 2.};;
let gray = { r = 0.7; g = 0.7; b = 0.7};;
let black = { r = 0.; g = 0.; b = 0.};; 

(**Colors list for B&W image*)
let blackwhite = [ (white,(-.0.75));(gray,0.41);(black,1.23) ];;
