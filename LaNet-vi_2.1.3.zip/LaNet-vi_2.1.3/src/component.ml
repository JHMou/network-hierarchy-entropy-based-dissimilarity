open Log;;
open Parameters;;
open Normal;;
open Uniform;;
open Host_list;;
open Host;;
open Graph;;
open Circular_average;;

let degree_squares = ref 0.0;;
let central_core_ratio = ref 0.0;;

type coordinate = {r: float; alfa: float};;

(**If this is the maximum shell index component, it's structured in cliques*)
let clique = new Clique.clique_class;;

(**Vector with all clusters, by id_cluster*)
let all_clusters = ref (let f = fun i -> new Host_list.host_list_class in Array.init 0 f);;

(**This class implements a component*)
let pi = 4.0 *. atan(1.0);;

(**Definition of class component*)
class component_class (shInd : int) =
object (self)
	
	(**All hosts belonging to this component, with shell index equal to this component's shell index. That's why they don't belong to a child component.*)
	val mutable hosts = (let f = fun i -> new Host_list.host_list_class in Array.init 1 f)

	(**Amount of lists in previous variable hosts. It's needed because lists are appended in groups of 1000 for performance, so there must be some way to determine which of them are useless*)
	val mutable hostListsCardinal = 1
	
	method getHosts = hosts

	(**For k-connectivity. Is computed as min(d+,d-)*)
	val mutable clustersConnectivity =  let f = fun i -> -1 in Array.init 1 f

	method getClusterConnectivity i = clustersConnectivity.(i)

	method getIdClusterConnectivity i = 
		!all_clusters.(i-1)#getFirstHost#getM;
		
	method setClusterConnectivity i n =
		clustersConnectivity.(i) <- n	

	val mutable parentComponent = []
	
	method setParentComponent p =
		parentComponent <- p :: []

	method hasParentComponent = List.length parentComponent
	
	method getParentComponent = 
		List.nth parentComponent 0
		
	(**All hosts belonging to this component children belong to this component as well.*)
	val mutable childrenComponents = []
	
	method getChildrenComponents = childrenComponents
	
	(**Amount of hosts inside this component*)
	val mutable componentCardinal = 0

	method getComponentCardinal = componentCardinal
	
	(**Sumatory of previous components cardinals*)
	method getPreviousComponentsCardinal =
		let sumatory = ref 0 in
		let rec addComponentCardinal cl =
		match cl with
		[] -> ()
		| c :: l ->
			sumatory := !sumatory + c#getComponentCardinal;
			if c <> (self :> component_class) then
				addComponentCardinal l
			else
				sumatory := !sumatory - c#getComponentCardinal / 2;
		in
		addComponentCardinal self#getParentComponent#getChildrenComponents;
		!sumatory;

	(**Sumatory of previous components cardinals' squares*)
	method getPreviousComponentsCardinalSquares =
		let sumatory = ref 0 in
		let rec addComponentCardinal cl =
		match cl with
		[] -> ()
		| c :: l ->
			sumatory := !sumatory + c#getComponentCardinal * c#getComponentCardinal;
			if c <> (self :> component_class) then
				addComponentCardinal l
			else
				sumatory := !sumatory - (c#getComponentCardinal * c#getComponentCardinal) / 2;
		in
		addComponentCardinal self#getParentComponent#getChildrenComponents;
		!sumatory;
			
	(**Sumatory of previous components cardinals*)
	method getBrotherComponentsCardinal =
			let sumatory = ref 0 in
		let rec addComponentCardinal cl =
		match cl with
		[] -> ()
		| c :: l ->
			sumatory := !sumatory + c#getComponentCardinal;
			addComponentCardinal l;
		in
		addComponentCardinal self#getParentComponent#getChildrenComponents;
		!sumatory;

	(**Sumatory of previous components cardinals' squares*)
	method getBrotherComponentsCardinalSquares =
			let sumatory = ref 0 in
		let rec addComponentCardinal cl =
		match cl with
		[] -> ()
		| c :: l ->
			sumatory := !sumatory + c#getComponentCardinal * c#getComponentCardinal;
			addComponentCardinal l;
		in
		addComponentCardinal self#getParentComponent#getChildrenComponents;
		!sumatory;
			
	(**Component's associated shell index*)
	val shellIndex = shInd

	(**Amount of hosts with this shell index, in this component*)
	val mutable shellCardinal = 0
	
	method getShellIndex = shellIndex
	
	method getShellCardinal = shellCardinal
	
	(**Component's rho*)
	val mutable rho = float 0
	
	method getRho = rho
	
	method setRho r = rho <- r
	
	(**Component's phi*)
	val mutable phi = float 0
	
	method getPhi = phi
	
	method setPhi p = phi <- p
	
	(**Component's center X coordinate*)
	val mutable xCoord = float 0
	
	method getX = xCoord
	
	method setX x = xCoord <- x
	
	(**Component's center Y coordinate*)
	val mutable yCoord = float 0
	
	method getY = yCoord
	
	method setY y = yCoord <- y
	
	(**Component's unit length*)
	val mutable u = parameters#getU
	
	method getU = u
	
	method setU v = u <- v
	
	method getClique = clique
			
	val mutable actualComponent = -1

	val mutable h = new Host.host_class 1
	
	method addHost (h : Host.host_class) = 
		let hostList = hosts.(0) in
		hostList#add h;
		shellCardinal <- shellCardinal + 1;
		componentCardinal <- componentCardinal + 1;
	
	method setHosts h =
		hosts.(0) <- h;
		shellCardinal <- h#getCardinal;
		componentCardinal <- h#getCardinal;
		
	(**Buils child components. A breadth search is done*)
	method computeComponents maxShellIndex cluster_id =
		(**log#print (Printf.sprintf "Computing components for shell index %d\n" (shellIndex + 1)) "componentsAlgorithm";*)
		
		(**Printf.printf "Paso 1\n";
		flush stdout;*)
		
		
		let newFifoList = ref
			(let f = fun i -> new Host.host_class 0 in
			Array.init 10000 f)
		in
		let fifoList = ref
			(let f = fun i -> new Host.host_class 0 in
			Array.init 1 f)
		in
		
		let listSize = ref 0 in
		
		(**For each host with bigger shellIndex than this component's one*)
		let rec navigateHost n =
			(**for j = 1 to recursionLevel do
				log#print (Printf.sprintf " ") "componentsAlgorithm";
			done;*)
			(**log#print (Printf.sprintf "Navigating host %d (inner component) \n" h#getNumber) "componentsAlgorithm";
			It's marked to be sent to a child component*)
			
			let h = (!fifoList).(n) in
			
			(**And each of it's neighbours is considered*)
			let neighboursList = h#getNeighbours in
				(**for k = 1 to (recursionLevel + 1) do
					log#print (Printf.sprintf " ") "componentsAlgorithm";
				done;
				log#print (Printf.sprintf "-> It has %d neighbours\n" (List.length neighboursList)) "componentsAlgorithm";*)
				let rec navigateNeighbours neighbours =
					match neighbours with
						[] -> ()
						| nexth :: l -> 
							
							match nexth with (a,b) ->
							if (a#getLastComponentComputed != self#getShellIndex + 1) & (a#getShellIndex > shellIndex) then
							begin
								a#setComponent actualComponent;
								a#setLastComponentComputed (self#getShellIndex + 1);
								(!fifoList).(!listSize) <- a;
								listSize := !listSize + 1;
								
								if !listSize mod 10000 = 0 then
								begin
									fifoList := Array.append !fifoList !newFifoList;
								end;
								
							end;
							navigateNeighbours l;
				in
				navigateNeighbours neighboursList;
				
				if !listSize > (n+1) then
					navigateHost (n+1);
		in
		
		(**For each host in the list*)
		let hostList = hosts.(0) in
		if hostList#hasFirstHost = 1 then
		begin
			let rec navigateList hosti i =
				(**log#print (Printf.sprintf "Analyzing host %d" hosti#getNumber) "componentsAlgorithm";*)
				if hosti#getShellIndex > shellIndex then
				begin
					if hosti#getLastComponentComputed != self#getShellIndex + 1 then
					begin
						(**If it has a bigger shell index and had not been marked, a new child component is created*)
						(**log#print (Printf.sprintf " (marked to delete)\n") "componentsAlgorithm";*)
						let c = new component_class (self#getShellIndex + 1) in
							c#setParentComponent (self :> component_class);
							actualComponent <- actualComponent + 1;
							childrenComponents <- childrenComponents @ c :: [];
							
							hosti#setComponent actualComponent;
							hosti#setLastComponentComputed (self#getShellIndex + 1);

							fifoList := !newFifoList;
							(!fifoList).(0) <- hosti;
							listSize := 1;
							navigateHost 0;
					end
					(**else
						log#print (Printf.sprintf " (already marked)\n") "componentsAlgorithm";*)
				end;(**
				else
					log#print (Printf.sprintf "->Belongs to shell index %d\n" shellIndex) "componentsAlgorithm";*)
				
				(**if i mod 10000 = 0 then
				begin
				Printf.printf "	i: %d\n" i;
				flush stdout;
				end;*)
				
				if hosti#hasNext = 1 then
					navigateList hosti#getNext (i+1);
			in
			navigateList hostList#getFirstHost 1;
		end;

		(**Printf.printf "Paso 2\n";
		flush stdout;*)
		
		(**Now, marked hosts are removed from the list*)
		let hayProximo = ref false in
		let proximo = ref (new Host.host_class 1) in
		if hostList#hasFirstHost = 1 then
		begin
			hayProximo := true;
			proximo := hostList#getFirstHost;
		end;

		while (!hayProximo=true) do
				let hosti = !proximo in
				
				if (!proximo)#hasNext = 1 then
					hayProximo := true
				else
					hayProximo := false;

				if (!hayProximo=true) then
					proximo := hosti#getNext;

				if hosti#getShellIndex > shellIndex then
				begin
					hostList#remove hosti;
					shellCardinal <- shellCardinal - 1;
					(List.nth childrenComponents hosti#getComponent)#addHost hosti;
				end;
		done;
		
		(**Printf.printf "Paso 3\n";
		flush stdout;*)
		
		(**Clusters are computed. A breadth search is done*)
		let rec navigateHost clusterNumber n =
			
			let h = (!fifoList).(n) in
					
			(**And each of it's neighbours is considered*)
			let neighboursList = h#getNeighbours in
				let rec navigateNeighbours neighbours =
					match neighbours with
						[] -> ()
						| nexth :: l -> 
							match nexth with (a,b) ->
							(**If this host is h's neighbour and they have the same shell index, then they are in the same cluster*)
							if (a#isClusterComputed = 0) && (a#getShellIndex = shellIndex) then
							begin
								(**It's marked to be sent to a cluster*)
								a#setCluster clusterNumber (!cluster_id + clusterNumber);
								(!fifoList).(!listSize) <- a;
								listSize := !listSize + 1;
								
								if !listSize mod 10000 = 0 then
								begin
									fifoList := Array.append !fifoList !newFifoList;
								end;
								
							end;
							navigateNeighbours l;
				in
				navigateNeighbours neighboursList;

				if !listSize > (n+1) then
					navigateHost clusterNumber (n+1);
		in
		
		let hostList = hosts.(0) in
		let number = ref 1 in
			
		(**The list of Host_list is build in steps of 1000 for performance.*)
		let newHostLists = ref
			(let f = fun i -> new Host_list.host_list_class in
			Array.init 999 f)
		in
		hosts <- Array.append hosts !newHostLists;

		let newConnectivities = ref
			(let f = fun i -> -1 in
			Array.init 999 f)
		in
		clustersConnectivity <- Array.append clustersConnectivity !newConnectivities;
				

		if hostList#hasFirstHost = 1 then
		begin
			let rec navigateList hosti =
				if hosti#isClusterComputed = 0 then
				begin
					(**If a new group of Host_list objects is needed, its created and appended to hosts*)
					if !number mod 1000 = 0 then
					begin
						newHostLists :=	
							( let f = fun i -> new Host_list.host_list_class in
							Array.init 1000 f );
						hosts <- Array.append hosts !newHostLists;

						newConnectivities :=
							(let f = fun i -> -1 in
							Array.init 1000 f);
						clustersConnectivity <- Array.append clustersConnectivity !newConnectivities;
						
					end;
					
					let c = hosts.(hostListsCardinal) in
					hostListsCardinal <- hostListsCardinal + 1;
					
					(**It's marked to be sent to a cluster*)
					hosti#setCluster !number (!cluster_id + !number);
					fifoList := !newFifoList;
					(!fifoList).(0) <- hosti;
					listSize := 1;
					navigateHost !number 0;
					
					number := !number + 1
				end;
				if hosti#hasNext = 1 then
					navigateList hosti#getNext;
			in
			navigateList hostList#getFirstHost;
		end;
		(**End of clusters computation*)

		(**Removal of useless lists in hosts*)
		hosts <- Array.sub hosts 0 hostListsCardinal;
		
		(**Now, clusters are built*)
		if hostList#hasFirstHost = 1 then
		begin
			let rec navigateList hosti =
				if hosti#hasNext = 1 then
					navigateList hosti#getNext;

				hostList#remove hosti;
				hosts.(hosti#getCluster)#add hosti;
				hosti#setCluster hosti#getCluster (!cluster_id + hosti#getCluster);
					
			in
			navigateList hostList#getFirstHost;
		end;
		
		(**Unsort of clusters to give them an arbitrary order, to avoid implementation bias in clusters positioning*)
		let u = new Uniform.uniform_class 1.00 (float ((hostListsCardinal) - 1)) in
		for i = 1 to (hostListsCardinal - 1) do
			let n = int_of_float u#getValue in
			let clusterN = hosts.(n) in
			let clusterNCon = clustersConnectivity.(n) in
			(**Swap*)
			hosts.(n) <- hosts.(i);
			hosts.(i) <- clusterN;
			clustersConnectivity.(n) <- clustersConnectivity.(i);
			clustersConnectivity.(i) <- clusterNCon;
		done;

				
		hosts <- Array.sub hosts 1 (hostListsCardinal-1);
		clustersConnectivity <- Array.sub clustersConnectivity 1 (hostListsCardinal-1);
		
		all_clusters := Array.append !all_clusters hosts;
			
		cluster_id := !cluster_id + (hostListsCardinal-1);
		(**If maxShellIndex has not been reached yed, inner components must be analyzed*)
		if self#getShellIndex < maxShellIndex then
		begin
			let rec compute c =
				match c with
					[] -> ()
					| n :: l -> 
						n#computeComponents maxShellIndex cluster_id;
						compute l;
			in
			compute childrenComponents;
		end;
		

	method printComponents =
		for i = 1 to (shellIndex - 1) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Component of core %d\n" shellIndex) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Shell index cardinal: %d\n" self#getShellCardinal) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Component cardinal: %d\n" self#getComponentCardinal) "components";
		
		let printHosts hosts =
			for i = 1 to shellIndex do
						log#print (Printf.sprintf " ") "components";
			done;
			log#print (Printf.sprintf "Cluster: ") "components";
			if hosts#hasFirstHost = 1 then
			begin
				let rec printHost h =
					log#print (Printf.sprintf "Host %d; " h#getNumberInFile) "components";
					if h#hasNext = 1 then
						printHost h#getNext
					else
						log#print (Printf.sprintf "\n") "components";
				in
				printHost hosts#getFirstHost;
			end
		in
		for cluster = 0 to ((Array.length hosts) - 1) do
			printHosts hosts.(cluster);
		done;
		
		let rec printChildrenComponents components =
			match components with
				[] -> ()
				| n :: c -> 
					n#printComponents;
					printChildrenComponents c;
		in
		printChildrenComponents childrenComponents;


	method printCentralComponents num =
		let id_capa = ref num in
		let rec printIsCentralComponent a =
			let printIsCentralComponentC hosts =
				if hosts#hasFirstHost = 1 then
				begin
					let rec printCHost h =
						log#print (Printf.sprintf "%d %d\n" !id_capa h#getNumberInFile) "centralComponents";
						if h#hasNext = 1 then printCHost h#getNext;
					in
					printCHost hosts#getFirstHost
				end
			in
			for cluster = 0 to ((Array.length hosts) - 1) do
				printIsCentralComponentC hosts.(cluster);
			done;
		in
		match childrenComponents with
			[] -> 
				id_capa := !id_capa + 1;
				printIsCentralComponent 0;
				!id_capa;
			| c -> 
				let rec printAllChildrenComponents components =
				match components with
					[] -> ();
					| n::c -> 
						id_capa := n#printCentralComponents !id_capa;
						printAllChildrenComponents c;
				in	
				printAllChildrenComponents c;
				!id_capa;


	method printCoordinates =
		for i = 1 to (shellIndex - 1) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Component of core %d\n" shellIndex) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "X: %f\n" self#getX) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Y: %f\n" self#getY) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "U: %f\n" self#getU) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Rho: %f\n" self#getRho) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Phi: %f\n" self#getPhi) "components";
		for i = 1 to (shellIndex) do
				log#print (Printf.sprintf " ") "components";
		done;
		log#print (Printf.sprintf "Component cardinal: %d\n" self#getComponentCardinal) "components";
		
		
		let printHosts hosts =
			if hosts#hasFirstHost = 1 then
			begin
				let rec printHost h =
					for i = 1 to shellIndex do
						log#print (Printf.sprintf " ") "components";
					done;
					log#print (Printf.sprintf "Host %d, x=%f y=%f rho=%f phi=%f\n" h#getNumberInFile h#getX h#getY h#getRho h#getPhi) "components";
				if h#hasNext = 1 then
						printHost h#getNext;
				in
				printHost hosts#getFirstHost;
			end
		in
		for cluster = 0 to ((Array.length hosts) - 1) do
			printHosts hosts.(cluster);
		done;
		
		let rec printChildrenCoordinates components =
			match components with
				[] -> ()
				| n :: c -> 
					n#printCoordinates;
					printChildrenCoordinates c;
		in
		printChildrenCoordinates childrenComponents;


		method placeInCircularSector ratio alfa n total random =
			let pos = ref ((float n /. float total) +. random) in
			if !pos > 1.0 then
			begin
				pos := !pos -. 1.0
			end;
			let div =
			if (alfa <> 2.0 *. pi) then			
				ref (!pos *. (2.0 *. ratio +. ratio *. alfa))
			else
				ref (ratio +. !pos *. ratio *. alfa)
			in
			let rho = ref 0.0 in
			let phi = ref 0.0 in
			if !div < ratio then
			begin
				rho := !div;
				phi := 0.0;
			end
			else
			begin
				if (!div >= ratio) && (!div < ratio +. ratio *. alfa) then
				begin
					rho := ratio;
					phi := (!div -. ratio) /. ratio;
				end
				else
				begin
					rho := ratio -. (!div -. ratio -. (ratio *. alfa));
					phi := alfa;
				end;
			end;
			{ r = !rho; alfa = !phi}

				
	(**This method calculates coordinates for all hosts in this connected component and, recursively, in its children*)
	method findCoordinates maxShellIndex minShellIndex maxDegree phiIni =

		(**Calculate this component's center*)
		let eps = Parameters.parameters#getEpsilon in
		let delta = Parameters.parameters#getDelta in
		
		if self#hasParentComponent = 1 then
		begin	
			
			(**See [NIPS2005], formula (4)*)
			rho <- float 1 -. (float componentCardinal /. float self#getBrotherComponentsCardinal);
			
			phi <- phiIni +. (float 2) *. pi *. (float (self#getPreviousComponentsCardinal) /. float self#getBrotherComponentsCardinal) ** 2.0;
			
			let distance =
				if !central_core_ratio < float maxShellIndex  -. float minShellIndex then
					!central_core_ratio +. ((float maxShellIndex -. float minShellIndex -. !central_core_ratio) /. (float maxShellIndex  -. float minShellIndex +. 1.0)) *. (float 1-.eps) *. (float (maxShellIndex - shellIndex + 2)) (**!sumatory*)
				else
					!central_core_ratio +. (1.0 /. (float maxShellIndex -. float minShellIndex +. 1.0)) *. (float 1-.eps)*. (float (maxShellIndex - shellIndex + 2)) (**!sumatory*)
			in
			(**See [NIPS2005], formula (3)*)
			xCoord <- self#getParentComponent#getX +. delta *. distance *. self#getParentComponent#getU *. rho *. cos(phi);
			yCoord <- self#getParentComponent#getY +. delta *. distance *. self#getParentComponent#getU *. rho *. sin(phi);
			
			(**See [NIPS2005], formula (5)*)
			u <- (Pervasives.sqrt (float componentCardinal /. float self#getBrotherComponentsCardinal)) *. self#getParentComponent#getU;

		end;

		let rec findCoordinatesInChildren components phiIn =
		match components with
			[] -> ()
			| n :: c -> 
				n#findCoordinates maxShellIndex minShellIndex maxDegree phiIn;
				findCoordinatesInChildren c phiIn;
		in
		let phiIn = 3.0 in
		findCoordinatesInChildren childrenComponents phiIn;

								
		let findClusterCoordinates cluster partialClusterSum =
			
			if cluster#hasFirstHost = 1 then
			begin
				
				let mean = pi *. float cluster#getCardinal /. float shellCardinal in
				let dev = pi *. float cluster#getCardinal /. float shellCardinal in
				let norm = new Normal.normal_class mean dev in
				let uniform = new Uniform.uniform_class 0.00 1.00 in
				let eps = Parameters.parameters#getEpsilon in
				let delta = Parameters.parameters#getDelta in
				let gamma = Parameters.parameters#getGamma in
				let rec findHostCoordinates h hostNumber =
					(**Calculate rho*)
					
					(**For this formula, see [NIPS2005], formula (1)*)
					let largerShellIndexNeighbours = ref 0 in
					let sumatory = ref 0.0 in
					let rec navigateNeighboursList nl =
						match nl with
						[] -> ()
						| n :: l ->
							match n with (a,b) ->
							if a#getShellIndex >= h#getShellIndex then
							begin
								largerShellIndexNeighbours := !largerShellIndexNeighbours + 1;
								sumatory := !sumatory +. float (maxShellIndex - a#getShellIndex + 1);
							end;

							navigateNeighboursList l;
					in
					navigateNeighboursList h#getNeighbours;
					
					let average =
						if (!largerShellIndexNeighbours != 0) then
							!sumatory /. float !largerShellIndexNeighbours
						else
							float_of_int(maxShellIndex - h#getShellIndex + 1)  +. (Random.float 1.0);
					in

					if (parameters#getNoCliques = true) && (h#getShellIndex = maxShellIndex) then
					begin
						h#setRho uniform#getValue; (**This will be multiplied by u when formulas (6) and (7) are applied*)
						h#setPhi (uniform#getValue *. float 2 *. pi);
					end
					else
					begin
						let rhoHost =
							if !central_core_ratio < float maxShellIndex  -. float minShellIndex then
								!central_core_ratio +. ((float maxShellIndex -. float minShellIndex -. !central_core_ratio) /. (float maxShellIndex  -. float minShellIndex)) *. ((float 1-.eps)*. (float (maxShellIndex - h#getShellIndex + 1)) +. eps *. average) (**!sumatory*)
							else
								!central_core_ratio +. (1.0 /. (float maxShellIndex -. float minShellIndex)) *. ((float 1-.eps)*. (float (maxShellIndex - h#getShellIndex + 1)) +. eps *. average) (**!sumatory*)
						in
						h#setRho rhoHost;

						(**End of rho computation*)
						
						(**Calculate phi*)
						let phiHost = ref 0.0 in
						
						if (parameters#getNoCliques = false) then
						begin
							let amount = ref 0 in
							let ca = new Circular_average.circular_average_class in
							let rec addNeighboursPhi nl =
								match nl with
								[] -> 
									if (!amount <> 0) then
										()
									else
										phiHost := float 2 *. pi *. uniform#getValue;
								| n::l ->
									match n with (a,b) ->
									if (a#getShellIndex > h#getShellIndex)||((a#getShellIndex = h#getShellIndex)&&(a#getRho <> -1.0))  then
									begin		
										(**let thisPhi = ref (atan (a#getY /. a#getX)) in
										if a#getX > 0.0 then
											thisPhi := !thisPhi
										else 
											thisPhi := (!thisPhi +. 3.141592);*)
										phiHost := ca#average !phiHost !amount a#getPhi (a#getShellIndex + 1 - h#getShellIndex);
										amount := !amount + (a#getShellIndex + 1 - h#getShellIndex)
									end;
									addNeighboursPhi l;
							in
							
							addNeighboursPhi h#getNeighbours;
						end
						else
						begin
							(**See [NIPS2005], formula (2)*)
							phiHost := float 2 *. pi *. (float partialClusterSum /. float shellCardinal) +. norm#getValue;
							(**Printf.printf "Asigno al host %d phi=%f\n" h#getNumber !phiHost;	*)
						end;
						
						h#setPhi !phiHost;
						(**End of phi computation*)
					end;
										
					(**See [NIPS2005], formula (6)*)
					(**Calculate x*)
					let xHost = xCoord +. (gamma *. u *. h#getRho *. cos(h#getPhi)) in
					h#setX xHost;
					(**End of x computation*)
					
					(**Calculate y*)
					let yHost = yCoord +. (gamma *. u *. h#getRho *. sin(h#getPhi)) in
					h#setY yHost;
					(**End of y computation*)
					
					if h#hasNext = 1 then
						findHostCoordinates h#getNext (hostNumber + 1);
			
			
				in
				
				(**If this component has maximum shell index*)
(**				if self#getShellIndex = maxShellIndex then*)
				if List.length childrenComponents = 0 then
				begin
					
					if (parameters#getNoCliques = false) then
					begin
						
						(**In this case, cliques are built*)
						let hmodel = new Host.host_class (-1) in
						let g1 = new Graph.graph_class hmodel in
						
						let cantHostsClique = ref 0 in
						
						(**Variable used to determine central core radio*)
						
						let rec agregarHost hg =
							g1#addVertex hg;
							degree_squares := !degree_squares +. Pervasives.log (float (1 + hg#getDegree)) *. Pervasives.log (float (1 + hg#getDegree));
							cantHostsClique := !cantHostsClique + 1;
							if hg#hasNext = 1 then
								agregarHost hg#getNext;
								
						in
						agregarHost cluster#getFirstHost;
	
						let c = 0.0007 +. 0.029 *. 1.0 *. 2.0 *. (float (maxShellIndex + 1 - minShellIndex)) /. Pervasives.log(float maxDegree)  in
						central_core_ratio := c *. Pervasives.sqrt(!degree_squares);
						clique#buildCliques g1 maxShellIndex;
						log#print (Printf.sprintf "Central core size: %d\n" !cantHostsClique) "cores";
						let listCliques = clique#getCliques in
						
						let rec computeCliqueHostCoordinates clique hostsSum hostsTotal cliqueHosts i random =
							let initialAngle = ref ((float hostsSum /. float hostsTotal) *. float 2 *. pi) in							
							let angle = ref ((float cliqueHosts /. float hostsTotal) *. float 2 *. pi) in								
							match clique with
							[] -> ()
							| ch :: chl ->
								
								h <- hosts.(0)#getFirstHost;
							
								(**Finding the host with the same number in the big graph*)
								while h#getNumberInFile <> ch#getNumberInFile do
									h <- h#getNext;
								done;
							
								let v = self#placeInCircularSector (0.7 *. !central_core_ratio) !angle i cliqueHosts random in
								
								(**Printf.printf "Node %d\n" i;
								Printf.printf "Angle %f\n" !angle;
								Printf.printf "v.r: %f\n" v.r;
								Printf.printf "v.alfa: %f\n" v.alfa;*)
								
								let x = v.r *. (cos (v.alfa +. !initialAngle)) +. 0.2 *. !central_core_ratio *. cos (!initialAngle +. !angle /. 2.0) in
								
								let y = v.r *. (sin (v.alfa +. !initialAngle)) +. 0.2 *. !central_core_ratio *. sin (!initialAngle +. !angle /. 2.0) in
								
								h#setRho (sqrt(x *. x +. y *. y));
								(**Printf.printf "RHO: %f\n" h#getRho;
								Printf.printf "\n";*)
								
								(**h#setRho (!central_core_ratio *. uniform#getValue);*) (**This will be multiplied by u when formulas (6) and (7) are applied*)
								let a = atan (y /. x) in
								if x > 0.0 then
									h#setPhi a
								else 
									h#setPhi (a +. 3.141592);
								(**h#setPhi (!initialAngle +. (uniform#getValue *. !angle));*)
								(**Calculate x*)
								let xHost = xCoord +. (gamma *. u *. h#getRho *. cos(h#getPhi)) in
								h#setX xHost;
								(**End of x computation*)
						
								(**Calculate y*)
								let yHost = yCoord +. (gamma *. u *. h#getRho *. sin(h#getPhi)) in
								h#setY yHost;
								(**End of y computation*)
								
								computeCliqueHostCoordinates chl hostsSum hostsTotal cliqueHosts (i+1) random;
						in
						
						let partialSum = ref 0 in
						let rec showList lc =
							match lc with
							[] -> ()
							| c :: l ->
							
								let random = (new Uniform.uniform_class 0.0 1.0)#getValue in
								computeCliqueHostCoordinates c !partialSum !cantHostsClique (List.length c) 0 random;
								partialSum := !partialSum + (List.length c);
								showList l;
						in
					
						showList listCliques;
						
					end
					else (**No cliques*)
					begin
						findHostCoordinates cluster#getFirstHost 1;
			
					end;
		
				end
				else
					findHostCoordinates cluster#getFirstHost 1;
		
				
			end;
		in
						
		let partialSum = ref 0 in
		for cluster = 0 to ((Array.length hosts) - 1) do
			findClusterCoordinates hosts.(cluster) !partialSum;
			partialSum := !partialSum + hosts.(cluster)#getCardinal;
		done;

		

	method computeDiameter2RecursiveWithFrontier h b =
		let h2 = new Host.host_class 0 in
		let gCentral = new Graph.graph_class h2 in
		gCentral#addVertex !h;
		while (!h#hasNext <> 0) do
			h := !h#getNext;
			gCentral#addVertex !h;
		done;
		let virtualVertex = gCentral#getMaxVertex + 1 in
		gCentral#addVertexNumber virtualVertex;
		let rec addFrontier bl =
		match bl with
			[] -> ()
			| b :: l ->
				match b with (a1,a2) ->
				gCentral#addEdge virtualVertex a1#getNumberInFile 1.0;
				addFrontier l;
		in
		addFrontier b;
		gCentral#computeDiameter2;

	method computeCentralCoreDiameter2Recursive =
		let h = ref hosts.(0)#getFirstHost in
		let gCentral = new Graph.graph_class !h in
		gCentral#addVertex !h;
		while (!h#hasNext <> 0) do
			h := !h#getNext;
			gCentral#addVertex !h;
		done;
		gCentral#computeDiameter2;
		
	method computeCentralCoreDiameter2 maxShellIndex =
	(**Diameter not computed*)	
	let diam = ref (-2) in

	(**If maxShellIndex has not been reached yed, inner components must be analyzed*)
	if self#getShellIndex < maxShellIndex then
	begin

		if (List.length childrenComponents <> 0) then
		begin
			let biggestComponent = ref (List.nth childrenComponents 0) in
			let rec compute c =
				match c with
					[] -> ()
					| n :: l -> 
						if n#getComponentCardinal > !biggestComponent#getComponentCardinal then
							biggestComponent := n;					
			in
			compute childrenComponents;
	
			diam := !biggestComponent#computeCentralCoreDiameter2 maxShellIndex;
		end;

	end
	else
	begin
		diam := self#computeCentralCoreDiameter2Recursive;
	end;
	!diam;			

	method determineConnectivity maxShellIndex =
	
	if (List.length childrenComponents <> 0) then
	begin
		let biggestComponent = ref (List.nth childrenComponents 0) in
		let rec compute c =
			match c with
				[] -> ()
				| n :: l -> 
					if n#getComponentCardinal > !biggestComponent#getComponentCardinal then
						biggestComponent := n;
		in
		compute childrenComponents;

		!biggestComponent#determineConnectivity maxShellIndex;
	end;

	(**Printf.printf "Shell %d\n" self#getShellIndex;*)
	if (self#getShellIndex <> 0) && ( self#getShellIndex < maxShellIndex) then
	begin
		let i=ref 0 in
		(**For each list*)
		(**Printf.printf "Capa %d\n" self#getShellIndex;*)
		while !i+1<hostListsCardinal do
			(**Printf.printf "Cluster %d\n" !i;*)
			let sizeCluster = ref 1 in

			if (hosts.(!i)#hasFirstHost=1) then
			begin
				(**Building frontier B*)
				let rec processHost h b =
					(**Printf.printf "    Tomo el %d\n" h#getNumber;*)
					
					let rec analizeVertexOnFrontierAndD h neighbours b already =
						match neighbours with
							[] -> ()
							| n :: nbs ->
								match n with (a1,a2) ->
								
								if a1#getShellIndex > h#getShellIndex then
								begin
									if (!already = false) then
									begin
										b := List.append !b ((h,0.0) :: []);
										already := true;
										()
									end;

									(**Incrementing d+*)
									if (IntMap.mem a1#getClusterId h#getdplus = true) then
										h#setdplus (IntMap.add a1#getClusterId ((IntMap.find a1#getClusterId h#getdplus) + 1) h#getdplus)
									else
										h#setdplus (IntMap.add a1#getClusterId 1 h#getdplus);
								end;
								analizeVertexOnFrontierAndD h nbs b already;

					in

					let already = ref false in
					analizeVertexOnFrontierAndD h h#getNeighbours b already;
				
					if (h#hasNext=1) then
					begin
						sizeCluster := !sizeCluster + 1;
						processHost h#getNext b;
					end;

				in
				let b = ref [] in

				processHost hosts.(!i)#getFirstHost b;

				(**Printf.printf "Cluster %d, size %d\n" !i !sizeCluster;*)
			
				let rec analizeDMinusNeigh h neighbours =
					match neighbours with
						[] -> ()
						| n :: nbs ->
							match n with (a1,a2) ->
							(**If the neighbour is in same cluster and it's not in the frontier then we increment d-*)
							if (a1#getClusterId = h#getClusterId) && (IntMap.empty = a1#getdplus) then
								h#setdminus (h#getdminus + 1);
							analizeDMinusNeigh h nbs;
							
							

				in

				let rec analizeDMinus h =
					analizeDMinusNeigh h h#getNeighbours;
					(**Printf.printf "d-: %d" h#getdminus;*)

					if (h#hasNext=1) then
						analizeDMinus h#getNext;
				in
				
				analizeDMinus hosts.(!i)#getFirstHost;

								
				(**cluster's m*)
				let m = ref 0 in

				let allFrontier = ref false in
				(**If all cluster is frontier, d- is not considered*)
				if (List.length !b) = !sizeCluster then
				begin
					allFrontier := true;
					(**Printf.printf "All cluster is frontier --> d- not considered\n";*)
				end;

				(**Printing frontier B*)

				let rec processFrontier b =
					match b with
						[] -> ()
						| n :: nb ->
							match n with (a1,a2) ->
							let dpl = ref 0 in (**dplus*)
							let f = (fun a b -> 
								(
									if (self#getIdClusterConnectivity a) < b then
										dpl := !dpl + (self#getIdClusterConnectivity a)
									else
										dpl := !dpl + b;
								)
							)
							in
							IntMap.iter f a1#getdplus;
							(**Printf.printf "Node %d, d- %d, d+ %d | " n#getNumber n#getdminus !dpl;*)
							
							if (a1#getdminus < !dpl) && (!allFrontier = false) then
								m := !m + a1#getdminus
							else
								m := !m + !dpl;

							processFrontier nb;
				in
				
				(**Printf.printf "    Frontier: ";*)
				processFrontier !b;
				(**Printf.printf "\n";*)

				(**Verifying cluster diameter <= 2*)
				let h = ref hosts.(!i)#getFirstHost in
				let diam = self#computeDiameter2RecursiveWithFrontier h !b 
in

				(**If cluster's diameter > 2 then connectivity = 1*)
				(**Printf.printf "Diametro con el nodo virtual: %d" !h3#getDiameter;*)

				if diam > 2 then
					m := 2;

				(**The bigger between m and size(B)*)				
				if !m > (List.length !b) then
					self#setClusterConnectivity !i !m
				else
					self#setClusterConnectivity !i (List.length !b);

				(**Printf.printf "    k-conectividad: %d\n" (self#getClusterConnectivity !i);*)
				
				
				let rec assignMToHosts h con =

					h#setM con;
					if (con>=h#getShellIndex) then
						h#setIsKConnected true;
					(**Printf.printf "Nodo %d, m=%d si=%d\n" h#getNumber con h#getShellIndex;*)
				
					if (h#hasNext=1) then
					begin
						assignMToHosts h#getNext con;
					end;
				in
	
				assignMToHosts hosts.(!i)#getFirstHost (self#getClusterConnectivity !i);
				

			end;
	
			i := !i + 1;
		done;

	end
	else
	begin
		if (self#getShellIndex = maxShellIndex) then
		begin
			(**Printf.printf "CAPA %d\n" self#getShellIndex;*)
			self#setClusterConnectivity 0 self#getShellIndex;
			(**Printf.printf "    m: %d\n" self#getShellIndex;*)


			let rec assignMToHosts h m =

				(**Printf.printf "Nodo %d, m=%d\n" h#getNumber m;*)
				h#setM m;
				h#setIsKConnected true;

				if (h#hasNext=1) then
				begin
					assignMToHosts h#getNext m;
				end;
			in

			assignMToHosts hosts.(0)#getFirstHost maxShellIndex;
	
		end
	end;

end;;
