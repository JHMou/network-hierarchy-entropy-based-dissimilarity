(**This class implements a list of hosts*)

(**Definition of class host_list*)
class host_list_class =
object (self)

	(**Amount of hosts in the list*)
	val mutable cardinal = 0
	
	(**Returns the amount of hosts in the list*)
	method getCardinal = cardinal
	
	val mutable firstHost = []
	
	val mutable lastHost = []

	(**Returns 1 if the list is not empty, 0 if it's empty*)
	method hasFirstHost = List.length firstHost
	
	method getFirstHost = List.nth firstHost 0
	
	method hasLastHost = List.length lastHost
	
	method getLastHost = List.nth lastHost 0
	
	(**Adds a host to the list*)
	method add: 'a. Host.host_class -> unit =
	fun h ->
		cardinal <- cardinal + 1;
		(**If the list is empty*)
		if self#hasFirstHost = 0 then
		begin
			firstHost <- h :: [];
			lastHost <- h :: [];
			h#clearPrev;
			h#clearNext
		end
		else
		begin
			(List.nth lastHost 0)#setNext h;
			h#setPrev (List.nth lastHost 0);
			lastHost <- h :: [];
			h#clearNext
		end;
		
	(**Removes a host from the list*)
	method remove: 'a. Host.host_class -> unit =
	fun h ->
		cardinal <- cardinal - 1;
		if h#hasPrev = 1 then
		begin
			if h#hasNext = 1 then
			begin
				h#getPrev#setNext h#getNext;
				h#getNext#setPrev h#getPrev
			end
			else
			begin
				h#getPrev#clearNext;
				lastHost <- h#getPrev :: []
			end
		end
		else
		begin
			if h#hasNext = 1 then
			begin
				firstHost <- h#getNext :: [];
				h#getNext#clearPrev
			end
			else
			begin
				firstHost <- [];
				lastHost <- []
			end
		end;
	
	method concat (h2 : host_list_class) =
		(**If h2 is not empty*)
		if h2#hasFirstHost = 1 then
		begin
			(**If this list is not empty*)
			if self#hasFirstHost = 1 then
			begin
				self#getLastHost#setNext h2#getFirstHost;
				h2#getFirstHost#setPrev self#getLastHost;
				lastHost <- h2#getLastHost :: [];
				cardinal <- cardinal + h2#getCardinal;
			end
			else
			begin
				firstHost <- h2#getFirstHost :: [];
				lastHost <- h2#getLastHost :: [];
				cardinal <- h2#getCardinal;
			end
		end
		
	(**Prints the list from first to last, and from last to first*)
	method printList : unit =
		let actual = List.nth firstHost 0 in
		let rec prn v =
			Printf.printf "-->%d" v#getNumberInFile;
			if v#hasNext = 1 then
				prn v#getNext
		in
		if self#hasFirstHost = 1 then
			prn actual;
		
		Printf.printf "\n";
		
		let actual2 = List.nth lastHost 0 in
		let rec prn v =
				Printf.printf "-->%d" v#getNumberInFile;
				if v#hasPrev = 1 then
					prn v#getPrev
		in
		if self#hasFirstHost = 1 then
			prn actual2;
		
		Printf.printf "\n";
		
end;;
