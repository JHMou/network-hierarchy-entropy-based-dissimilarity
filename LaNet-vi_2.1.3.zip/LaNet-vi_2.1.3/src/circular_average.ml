(**This class implements a weighted circular average calculator*)

(**Definition of class circular_average*)
class circular_average_class =
object (self)

	method average a weight_a b weight_b =
		let xa = cos a in
		let ya = sin a in
		
		let xb = cos b in
		let yb = sin b in
		
		let xav = ((xa *. float weight_a) +. ( xb *. float weight_b)) /. float (weight_a + weight_b) in
		let yav = ((ya *. float weight_a) +. ( yb *. float weight_b)) /. float (weight_a + weight_b) in
		
		if (xav > 0.0) then
			atan(yav /. xav)
		else
			atan(yav /. xav) +. 3.141592
		
		
end;;
