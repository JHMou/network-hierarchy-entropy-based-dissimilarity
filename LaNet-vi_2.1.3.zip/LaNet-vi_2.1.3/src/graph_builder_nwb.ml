(**This module reads a file with edges and adds them to an empty graph*)

open Files;;

class type graph = object method addEdge: int -> int -> float -> unit method addVertexNumber: int -> unit method setVertexName: int -> string -> unit end;;

(**Definition of class graph_builder G=(V,E)*)
class graph_builder_nwb_class  =
object
	(**Reads an input file with format:
		file :=  [ set of {line}
				EOF
			line := [ { vertex1 vertex 2 EOL}
				vertex1: int
				vertex2: int
			]
		]
		and builds the graph. Receives the name of the file and the graph*)
	method read_file : 'a 'b. (#graph as 'a) -> string -> unit =
		  
		fun graph filename ->
		let f_input = Unix.openfile filename (Unix.O_RDWR :: []) 511 in
		
		let  text = ref "" in
		let vertex1 = ref 0 in
		let vertex2 = ref 0 in
		let vertex3 = ref "" in
		let vertex4 = ref 0.0 in
		let n = ref 1 in
		let readyForEdges = ref false in
		let readyForVertices = ref false in
		let text = ref false in
		while !n > 0 do
			let line = ref "" in
			n := readLine f_input line;
			text := false;
			if (String.length !line) >= 9 then
			begin
				if (String.sub !line 0 9) = "*Vertices" then
				begin
					readyForVertices := true;
					text := true;
				end
			end;
			if (String.length !line) >= 6 then
			begin
				if (String.sub !line 0 6) = "*Edges" then
				begin
					readyForEdges := true;
					text := true;
				end;
			end;
			if !text = false then
			begin
				if !readyForEdges = true then
				begin
					(try
						Scanf.sscanf !line " %d %d %f" (fun a b c -> vertex1 := a; vertex2 := b; vertex4 := c);
						(**Printf.printf "Edge: %d %d\n" !vertex1 !vertex2;*)
						graph#addEdge !vertex1 !vertex2 !vertex4;
					with
						_ -> 
							(try
								Scanf.sscanf !line " %d %d" (fun a b -> vertex1 := a; vertex2 := b);
								(**Printf.printf "Edge: %d %d\n" !vertex1 !vertex2;*)
								graph#addEdge !vertex1 !vertex2 1.0;
							with
								End_of_file -> ()
							)
					)
				end
				else if !readyForVertices = true then
				begin
					(try
						(try
							let n = String.index !line '\"' in
							!line.[n] <- ' ';
							let n2 = String.rindex !line '\"' in
							!line.[n2] <- ' ';
						with
							Not_found -> ()
						);
						Scanf.sscanf !line " %d %s@\n" (fun a b -> vertex1 := a; vertex3 := b);
						(**Printf.printf "Vertex: %d \n" !vertex1;*)
						graph#addVertexNumber !vertex1;
						graph#setVertexName !vertex1 !vertex3;
					with
						End_of_file -> ());
				end;
			end;
		done;
		
		Unix.close f_input;
		
end;;
