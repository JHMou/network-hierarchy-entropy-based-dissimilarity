let readLine file refLine =
	let eol = ref false in
	let eof = ref false in
	let i = ref 0 in
	let n = ref 0 in
	let c = " " in
	while (!eol = false) && (!eof = false) do
		
		n := Unix.read file c 0 1;
		
		if !n = 0 then 
			eof := true
		else
		begin
			if c <> "\r" then
			begin
				i := !i + 1;
				refLine := !refLine ^c;
			end;
			if c = "\n" then
				eol := true;
		end;
	done;
	!n;;