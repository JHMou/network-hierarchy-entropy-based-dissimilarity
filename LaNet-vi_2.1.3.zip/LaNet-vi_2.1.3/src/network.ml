(**This module extends a graph functionality to a network. Besides defining a graph as a set of vertices and edges G=(V,E) and offering the graph class services, it maintains lists of vertices with the same degree, thus allowing the computation of the vertices' shell index (k-core decomposition). It also uses an extended version of a vertex: a host, which also has a shell index and references to the previous and next host with the same shell index.*)

open Log;;
open Uniform;;
open Parameters;;
open Component;;

let pi = 4.0 *. atan(1.0);;

(**Definition of class network*)
class network_class =
let h = new Host.host_class (-1) in

object (self)
	inherit ['a] Graph.graph_class h

	(**Indicates if shellIndex is already calculated*)
	val mutable isShellIndexComputed = false
	
	(*Maximum shell index. Also called cmax**)
	val mutable maxShellIndex = 0

	(*Maximum shell index.**)
	val mutable minShellIndex = 0
	
	method getMaxShellIndex = maxShellIndex
	
	method setMaxShellIndex shInd = maxShellIndex <- shInd
	
	method getMinShellIndex = minShellIndex
	
	method setMinShellIndex shInd = minShellIndex <- shInd
	
	val mutable component = new Component.component_class 0

	val mutable centralCoreDiameter = 0

	method getComponent = component
		
	(**An array of lists, containing vertices initially grouped by their degree, and finally grouped by their shell index. Initially, 1 list are built.*)
	val mutable lists =  
		let f = fun i -> new Host_list.host_list_class in
		Array.init 1 f
	
	(**Buils the list of lists, grouping vertices by their degree*)
	method (**private*) buildInitialLists =
		lists <- 
			if (Parameters.parameters#getWeighted = true)&&(Parameters.parameters#getMultigraph = false) then
			begin
				(let f = fun i -> new Host_list.host_list_class in Array.init (self#getMaxPValue + 1) f)
			end
			else
				(let f = fun i -> new Host_list.host_list_class in Array.init (self#getMaxDegree + 1) f);
		for i = 0 to self#getMaxVertex do
			let posList = i / arraySize in
			let v = (List.nth vertices posList).(i mod arraySize) in

			if v#getNumberInFile != -1 then
			begin
				(**Gets vertex-i's degree and adds the vertex to the corresponding list*)
				let p = v#getP pFunction (-2) in
				v#setShellIndex p;
				lists.(p)#add v;
			end
		done;

	(**Prints groups of vertices. If shellIndex is already computed, vertices are grouped by their degree. Otherway they're grouped by their shell index. Must not be called after computeComponents*)
	method printLists =
	let section = ref "" in
	if isShellIndexComputed = false then
		section := "degrees"
	else
		section := "cores";
		
	(** log#print (Printf.sprintf "Graph BEGIN\n") !section;*)
	
	let max = ref 0 in
		if isShellIndexComputed = false then
			max := maxPValue
		else
			max := maxShellIndex;
		
	for i = 0 to !max do

		if isShellIndexComputed = false then
			log#print (Printf.sprintf "Degree %d vertices\n" (i)) !section
		(**else
			log#print (Printf.sprintf "shell index %d vertices\n" (i)) !section*);
			
		let rec printHosts actualHost=
			(**log#print (Printf.sprintf "-->%d\n" actualHost#getNumber) !section;*)
			log#print (Printf.sprintf "%d %d\n" actualHost#getShellIndex actualHost#getNumberInFile) !section;
			if actualHost#hasNext = 1 then
				printHosts(actualHost#getNext);
		in
		if lists.(i)#hasFirstHost = 1 then
		begin
			let actualHost = lists.(i)#getFirstHost in
			printHosts actualHost;		
		end
	done;
	(**log#print (Printf.sprintf "Graph END\n") !section;*)
	
	(**Generates a file with (node, core) Must be called after shellIndex is already computed, and before computeComponents*)
	method generateCoresFile filename =
		let max = maxVertex in
		let out_file = open_out filename in

		for i= 0 to (List.length vertices * arraySize -1) do
			let posList = i / arraySize in
			if (List.nth vertices posList).(i mod arraySize)#isVertex then
			begin
				Printf.fprintf out_file "%d %d\n" i (List.nth vertices posList).(i mod arraySize)#getShellIndex;
			end
		done;
		close_out out_file;

	(**This method contains the algorithm to compute the shell index*)
	method (**private*) computeShellIndex = 

		for i = 0 to (Array.length lists) - 1 do
			let rec computeHosts actualHost=
				let nxt = ref 0 in
				if actualHost#hasNext = 1 then
					nxt := actualHost#getNext#getNumberInFile;
				log#print (Printf.sprintf "Working with vertex %d (list %d), next is %d\n" actualHost#getNumberInFile i  !nxt) "coresAlgorithm";

				let rec modifyNeighbours neighboursList =
					match neighboursList with
					[] -> ()
					| n :: l -> 
						match n with (a1,a2) ->
						log#print (Printf.sprintf "-->Analyzing neighbour %d\n" a1#getNumberInFile) "coresAlgorithm";
						if a1#getShellIndex > i then
						begin
							log#print (Printf.sprintf "---->This neighbour will be moved\n") "coresAlgorithm";
									
							lists.(a1#getShellIndex)#remove a1;

							let p = a1#getP pFunction i in

							lists.(p)#add a1;

							log#print (Printf.sprintf "---->Was moved to list %d\n"  p) "coresAlgorithm";
									
							a1#setShellIndex (p);
						end;
						modifyNeighbours l;
				in
				
				let nl = actualHost#getNeighbours in
				modifyNeighbours nl;
				actualHost#setShellIndex i;
			
				if actualHost#hasNext = 1 then
				begin
					let actualHost = actualHost#getNext in
					computeHosts actualHost;		
				end
				
			in
			if lists.(i)#hasFirstHost = 1 then
			begin
				let actualHost = lists.(i)#getFirstHost in
				computeHosts actualHost;		
			end
		done;
			
		(**Find maximum and minimum shell index*)
		let i = ref ((Array.length lists) - 1) in
		let exit = ref 0 in 
		while (!i > 0) & (!exit = 0) do
			(**If the ith list is empty, then i-1 is the maximum shell index*)
			if lists.(!i)#hasFirstHost = 1 then
			begin
				self#setMaxShellIndex (!i);
				exit := 1
			end;
			i := !i - 1;
		done;
		let exit = ref 0 in 
		let i = ref 0 in
		while (!i < ((Array.length lists) - 1)) & (!exit = 0) do
			(**If the ith list is not empty, then i is the minimum shell index*)
			if lists.(!i)#hasFirstHost = 1 then
			begin
				self#setMinShellIndex (!i);
				exit := 1
			end;
			i := !i + 1;
		done;
		isShellIndexComputed <- true;
	
	(**This method contains the algorithm to compute the components. computeShellIndex must have been invoked previously.*)
	method (**private*) computeComponents = 
		for i = 1 to (Array.length lists) - 1 do
			lists.(0)#concat lists.(i);
		done;
		component#setHosts lists.(0);
		
		component#computeComponents maxShellIndex (ref 0);
	
	(**computeComponents must have been invoked before*)
	method findCoordinates =
		(**Start recursive invocation*)
		let phiIni = uniform2Pi#getValue in
		component#findCoordinates maxShellIndex minShellIndex maxDegree phiIni;
		
	method computeCentralCoreDiameter =
		centralCoreDiameter <- component#computeCentralCoreDiameter2 maxShellIndex;
		if centralCoreDiameter = 2 then		
			Printf.printf "<= 2\n"
		else
			Printf.printf "> 2\n";
		centralCoreDiameter;
	
	method getCentralCoreDiameter = centralCoreDiameter;
	
	method determineConnectivity =
		component#determineConnectivity maxShellIndex;		
		
	(**findCoordinates must have been invoked before*)
	method printCentralComponents =
		component#printCentralComponents 0;

	(**computeComponents must have been invoked before*)
	method printComponents =	
		component#printComponents;
					
	(**findCoordinates must have been invoked before*)
	method printCoordinates =
		component#printCoordinates;

	(**Receives the vertex number*)
	method getShellIndex vertex = 
		if isShellIndexComputed = false then
			self#computeShellIndex;
		let v = self#getVertex vertex in
			v#getShellIndex;
		
end;;
