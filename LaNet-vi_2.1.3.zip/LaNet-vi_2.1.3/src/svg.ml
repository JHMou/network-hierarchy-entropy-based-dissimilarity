open Printf;;
open Parameters;;
open Types;;

(**Definition of class svg*)
class svg_class filename =
object (self)

	val out_file = open_out filename
	
	method addHeaders nc u r =
		let f = ref 0.1 in
		f := nc;
		f := u;
		f := r;
		fprintf out_file "<?xml version=\"1.0\" standalone=\"no\"?>\n";
		fprintf out_file "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\"\n";
	  	fprintf out_file "\"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">\n";

		let ratio = u *. 2.0 *. parameters#getGamma *. r in
		let width = 1.6*.ratio in
		let height = 1.2*.ratio in
		fprintf out_file "<svg width=\"800\" height=\"600\" viewBox=\"%f %f %f %f\" version=\"1.1\"\n" (-.0.8*.ratio +. parameters#getHStart *. width) (-.0.6*.ratio +. parameters#getVStart *. height) (width *. (parameters#getHEnd -. parameters#getHStart)) (height*.(parameters#getVEnd -. parameters#getVStart));
		fprintf out_file "xmlns=\"http://www.w3.org/2000/svg\">\n";
		if parameters#getBckGnd <> "white" then fprintf out_file "<rect x=\"-%f\" y=\"-%f\" width=\"%f\" height=\"%f\" fill=\"rgb(0,0,0)\"/>\n" (0.8*.ratio) (0.6*.ratio) (1.6*.ratio) (1.2*.ratio);
	
	method addHost x y ratio color =
		let red = int_of_float (color.r *. 255.0) in
		let green = int_of_float (color.g *. 255.0) in
		let blue = int_of_float (color.b *. 255.0) in
		fprintf out_file "<circle cx=\"%f\" cy=\"%f\" fill=\"rgb(%d,%d,%d)\" r=\"%f\"/>\n" x (-.y) red green blue ratio;
	
	method addBlock x y ratio color =
		let red = int_of_float (color.r *. 255.0) in
		let green = int_of_float (color.g *. 255.0) in
		let blue = int_of_float (color.b *. 255.0) in
		fprintf out_file "<rect x=\"%f\" y=\"%f\" fill=\"rgb(%d,%d,%d)\" width=\"%f\" height=\"%f\"/>\n" (x -. ratio) (-.y +. ratio) red green blue (2.0 *. ratio) (2.0 *. ratio);
	
	method addCylinder x1 y1 z1 x2 y2 z2 color diameter =
		(**Verify that base point != apex point, for that would generate an error in povray*)
		let f = ref 0.1 in
		f := z1;
		f := z2;
		if (Pervasives.floor((x1+.0.0005)*.(float)1000) <> Pervasives.floor((x2+.0.0005)*.(float)1000)) || (Pervasives.floor((y1+.0.0005)*.(float)1000) <> Pervasives.floor((y2+.0.0005)*.(float)1000)) then
			let red = int_of_float (color.r *. 255.0) in
			let green = int_of_float (color.g *. 255.0) in
			let blue = int_of_float (color.b *. 255.0) in
			fprintf out_file "<line x1=\"%.3f\" x2=\"%.3f\" y1=\"%.3f\" y2=\"%.3f\" stroke=\"rgb(%d,%d,%d)\" stroke-width=\"%.3f\" opacity=\"%f\"/>\n" x1 x2 (-.y1) (-.y2) red green blue (diameter *. 2.0) parameters#getOpacity;
	
	method addText text color size x y align =
		let red = int_of_float (color.r *. 255.0) in
		let green = int_of_float (color.g *. 255.0) in
		let blue = int_of_float (color.b *. 255.0) in

		if align="left" then
			fprintf out_file "<text x=\"%.3f\" y=\"%.3f\" font-family=\"Verdana\" font-size=\"%f\" fill=\"rgb(%d,%d,%d)\">%s</text>\n" (x*.size) ((-.y*.size)-.0.65*.size) (size) red green blue text
		else
			fprintf out_file "<text x=\"%.3f\" y=\"%.3f\" font-family=\"Verdana\" font-size=\"%f\" fill=\"rgb(%d,%d,%d)\">%s</text>\n" (x*.size) ((-.y*.size)-.0.65*.size) (size) red green blue text;

 	method addCircle x y ratio color =
		let red = int_of_float (color.r *. 255.0) in
		let green = int_of_float (color.g *. 255.0) in
		let blue = int_of_float (color.b *. 255.0) in
		fprintf out_file "<circle cx=\"%f\" cy=\"%f\" border=\"rgb(%d,%d,%d)\" r=\"%f\"/>" x y red green blue ratio;

	method close =
		fprintf out_file "</svg>\n";
		(**Close file*)
		close_out out_file;

		
end;;
