open Printf;;
open Parameters;;
open Types;;

type imagePosition = {xi: float; yi: float; dirxi: int; diryi: int};;

class graphics_class engine =
object (self)

	val mutable namesMesh = (let f = fun i -> 
		begin
			let g = fun j -> 0 in
			Array.init 1 g
		end
		in
		Array.init 1 f);

	val mutable xMeshSize = 1;
	val mutable yMeshSize = 1;

	method private interpolate c1 alfa1 c2 =
		{	r = c1.r *. (float 1 -. alfa1) +. c2.r *. (alfa1);
			g = c1.g *. (float 1 -. alfa1) +. c2.g *. (alfa1);
			b = c1.b *. (float 1 -. alfa1) +. c2.b *. (alfa1);
		}
	
		
	method private computeHostColor n shellIndex =
		let colorList =
			if parameters#getColor = "col" then
				rainbow
			else 
				blackwhite
		in
		let colorsNumber = List.length colorList in
		let par n =
			if (n mod 2) = 0 then
				true
			else
				false
		in
		let position = 
			if parameters#getColor = "col" then
				float (shellIndex - 1) /. float (n#getMaxShellIndex - 1)
			else if parameters#getColor = "bw" then
				float (shellIndex - 1) /. float (n#getMaxShellIndex - 1)
			else if (parameters#getColor = "bwi") & (par (shellIndex + n#getMaxShellIndex)) then
				(float (n#getMaxShellIndex - 1) +. float (shellIndex - 1)) /. (2.00 *. float (n#getMaxShellIndex - 1))
			else 
				float (shellIndex - 1) /. (2.00 *. float (n#getMaxShellIndex - 1))
		in
		
		(**Color calculation*)
		let hostColor =
				if n#getMaxShellIndex = 1 then
					red
				else
				begin
					let (c1,v1) = List.nth colorList 0 in
					let (c2,v2) = List.nth colorList (colorsNumber-1) in
					if position < v1 then
						c1
					else if position > v2 then
						c2
					else
					begin
						let index = ref 0 in
						let enc = ref false in
						
						while (!enc = false) do
							let (c1,v1) = List.nth colorList !index in
							let (c2,v2) = List.nth colorList (!index + 1) in
							if (v1<=position) & (position<=v2) then
								enc := true
							else
								index := !index + 1;
						done;

						let (c1,v1) = List.nth colorList !index in
						let (c2,v2) = List.nth colorList (!index + 1) in
						let alfa1 = (position -. v1) /. (v2 -. v1) in
						self#interpolate c1 alfa1 c2
					end;
				end;
			
		in
		
		(**End of color calculation*)
		if parameters#getColor = "col" then
		begin
			let lumin = 0.7 +. 0.5 *. float (shellIndex mod 2) in
			{	r = lumin *. hostColor.r; g = lumin *. hostColor.g; b = lumin *. hostColor.b;};
		end
		else
			hostColor		
		
	method private computeHostRatio n strength degree weighted =
		if weighted = false then
			(0.0007 +. 0.029 *. (log((float) (1 + degree)) /. log(float n#getMaxDegree))) *. (float n#getMaxShellIndex +. 1.0 -. float n#getMinShellIndex)
		else
			(0.0007 +. 0.029 *. ( log((1.0 +. strength)) /. log(n#getMaxStrength))) *. (float n#getMaxShellIndex +. 1.0 -. float n#getMinShellIndex);

	method generateNetworkFile ( n : Network.network_class ) : unit =
		let u = parameters#getU in
		(**Uniform probability distribution for edges drawing*)
		let uniform = new Uniform.uniform_class (float 0) (float 1) in
		
		(**Color computation for all hosts*)
		for i = 0 to n#getMaxVertex do
			let h = n#getVertexInList i in
				if h#isVertex then
				begin
					h#setColor (self#computeHostColor n h#getShellIndex);
					if (parameters#getKConn = true) then
					begin
						if h#getIsKConnected = false then
						begin
							Log.log#print (Printf.sprintf "Host %d is not k-connected. m=%d and k-core=%d\n" h#getNumberInFile h#getM h#getShellIndex) "cores";
							if parameters#getBckGnd = "white" then
								h#setColor black
							else
								h#setColor white;
						end;
					end;
				end
		
		done;
		
		(**Generating mesh for nodes names*)
		let ppcV = 12 in (**Pixels per character vertically*)
		let ppcH = 10 in (**Pixels per character horizontally*)
		
		xMeshSize <- int_of_float ((float parameters#getWidthResolution) /. (float ppcH));
		yMeshSize <- int_of_float ((float parameters#getHeightResolution) /. (float ppcV));
		namesMesh <- (let f = fun i -> 
		begin
			let g = fun j -> 0 in
			Array.init yMeshSize g
		end
		in
		Array.init xMeshSize f);
		
		let numberOfEdges = ref 0 in
		let ratio = ref ((float n#getMaxShellIndex) +. 1.0 -. (float n#getMinShellIndex)) in
		if (!Component.central_core_ratio +. 1.0 > !ratio) then
			ratio := !Component.central_core_ratio +. 1.0;
		engine#addHeaders (float (n#getMaxShellIndex + 1 - n#getMinShellIndex)) u !ratio;
		
		let textColor =
			if parameters#getBckGnd = "black" then
				white
			else
				black
		in

		let rec addComponents componentsList order =
			match componentsList with
			[] -> ()
			| c :: compList ->
				let rec addHost host order = 
				
					(**Computing host ratio*)
						let hostRatio = self#computeHostRatio n (host#getStrength) (host#getDegree) (parameters#getWeighted && (not parameters#getMultigraph)) in
					
					if (order=2) then
					begin
						(**Adding sphere or block*)
						if (parameters#getKConn = true) && (host#getIsKConnected=false) && (parameters#getColor <> "col") then
							engine#addBlock host#getX host#getY (hostRatio *. u) host#getColor
						else
							engine#addHost host#getX host#getY (hostRatio *. u) host#getColor;
					end;

					if (order=3) then
					begin
						(**Adding node's name*)
						
						let hasName = ref true in

						let nodeName =
							if host#getName <> "" then
								host#getName
							else
								if	parameters#getInputNodeNamesFile = "0" then
									Printf.sprintf "%d" host#getNumberInFile
								else
								begin
									hasName := false;
									""
								end
						in

						if !hasName then
						(**if host#getName <> "" then*)
						begin
							(**Printf.printf "Nodo %s\n" host#getName;*)
							let large = parameters#getU *. parameters#getGamma *. !ratio in
							let size = 0.05 *. large *. 800.0 /. float_of_int (parameters#getWidthResolution) in
							(**engine#addText host#getName textColor size ((host#getX +. 0.08) /. size) (host#getY /. size);*)
							
							let xCoordRight = (host#getX +. 1.2 *. hostRatio) /. size in
							let yCoordRight = host#getY /. size in
							let ip1 = { xi = xCoordRight ; yi = yCoordRight ; dirxi = 1 ; diryi = 0} in
														
							let xCoordLeft = (host#getX -. 1.2 *. hostRatio) /. size in
							let yCoordLeft = host#getY /. size in
							let ip2 = { xi = xCoordLeft ; yi = yCoordLeft ; dirxi = -1 ; diryi = 0} in

							let xCoordUp = host#getX /. size in
							let yCoordUp = (host#getY +. 1.2 *. hostRatio) /. size in
							let ip3 = { xi = xCoordUp ; yi = yCoordUp ; dirxi = 1 ; diryi = 0} in
							let ip4 = { xi = xCoordUp ; yi = yCoordUp ; dirxi = -1 ; diryi = 0} in
							
							let xCoordDown = host#getX /. size in
							let yCoordDown = (host#getY -. 1.2 *. hostRatio) /. size in
							let ip5 = { xi = xCoordDown ; yi = yCoordDown ; dirxi = 1 ; diryi = 0} in
							let ip6 = { xi = xCoordDown ; yi = yCoordDown ; dirxi = -1 ; diryi = 0} in
							
							let meshPosVector	= ip1 :: ip2 :: ip3 :: ip4 :: ip5 ::ip6 :: [] in
							
							(**let nodeName = (Printf.sprintf "%d" host#getNumber) in*)
							let chars = String.length nodeName in
							
							let overlaps =  ref (Array.create 6 0) in
							
							
							(**For each position*)
							for n = 0 to (List.length meshPosVector) - 1 do
								let xMesh = int_of_float (float (xMeshSize / 2) +. ((List.nth meshPosVector n).xi *. size /. (2.0 *. large)) *. float xMeshSize) in
								let yMesh = int_of_float (float (yMeshSize / 2) +. ((List.nth meshPosVector n).yi *. size /. (2.0 *. large)) *. float yMeshSize) in
								
								(**Printf.printf "n=%d xMesh: %d yMesh: %d\n" n xMesh yMesh;*)

								let dir = (List.nth meshPosVector n).dirxi in
								(**For each character*)
								for i = 0 to chars do
									
									if ((xMesh+dir*i) < xMeshSize)&&((xMesh+dir*i)>0)&&(yMesh < yMeshSize)&&(yMesh>0) then
									begin
										
										if Array.get (Array.get namesMesh (xMesh+dir*i)) yMesh <> 0 then
										begin
											let overlapsi = Array.get (Array.get namesMesh (xMesh+dir*i)) yMesh in
											Array.set !overlaps n ((Array.get !overlaps n) + overlapsi);
										end
									end
									else
									begin
										Array.set !overlaps n ((Array.get !overlaps n) + 1);
									end;
									
									if ((xMesh+dir*i) < xMeshSize)&&((xMesh+dir*i)>0)&&(yMesh + 1 < yMeshSize)&&(yMesh + 1 >0) then
									begin
										
										if Array.get (Array.get namesMesh (xMesh+dir*i)) (yMesh + 1) <> 0 then
										begin
											let overlapsi = Array.get (Array.get namesMesh (xMesh+dir*i)) (yMesh + 1) in
											Array.set !overlaps n ((Array.get !overlaps n) + overlapsi);
										end
									end
									else
									begin
										Array.set !overlaps n ((Array.get !overlaps n) + 1);
									end;
									
									if ((xMesh+dir*i) < xMeshSize)&&((xMesh+dir*i)>0)&&(yMesh - 1 < yMeshSize)&&(yMesh - 1 >0) then
									begin
										
										if Array.get (Array.get namesMesh (xMesh+dir*i)) (yMesh - 1) <> 0 then
										begin
											let overlapsi = Array.get (Array.get namesMesh (xMesh+dir*i)) (yMesh - 1) in
											Array.set !overlaps n ((Array.get !overlaps n) + overlapsi);
										end
									end
									else
									begin
										Array.set !overlaps n ((Array.get !overlaps n) + 1);
									end;
									
								done;
							done;
							
							(**Printf.printf " [%d %d %d %d %d %d] \n" !overlaps.(0) !overlaps.(1) !overlaps.(2) !overlaps.(3) !overlaps.(4) !overlaps.(5);*)
							
							let minPos = ref 0 in
							for n = 1 to 5 do
								if !overlaps.(n) < !overlaps.(!minPos) then
									minPos := n;
							done;
							
							let xMesh = int_of_float (float (xMeshSize / 2) +. ((List.nth meshPosVector !minPos).xi *. size /. (2.0 *. large)) *. float xMeshSize) in
							let yMesh = int_of_float (float (yMeshSize / 2) +. ((List.nth meshPosVector !minPos).yi *. size /. (2.0 *. large)) *. float yMeshSize) in
				
							let dir = (List.nth meshPosVector !minPos).dirxi in
							(**Printf.printf "pos %d\n" !minPos;*)
							
							(**If adding this text doesn't result in a great superposition*)
							if !overlaps.(!minPos) <= 1 then
							begin
								if dir = 1 then
									engine#addText nodeName textColor size (List.nth meshPosVector !minPos).xi (List.nth meshPosVector !minPos).yi "left"
								else
									engine#addText nodeName textColor size ((List.nth meshPosVector !minPos).xi -. float (chars + 1) *. (float ppcH /. float parameters#getWidthResolution) *. 2.0 *. large /. size) (List.nth meshPosVector !minPos).yi "right";
	
								(**Marking mesh*)
								for i = 0 to chars do
									if ((xMesh+dir*i) < xMeshSize)&&((xMesh+dir*i)>0)&&(yMesh < yMeshSize)&&(yMesh>0) then
									begin
										let prevVal = Array.get (Array.get namesMesh (xMesh+dir*i)) yMesh in
										Array.set (Array.get namesMesh (xMesh+dir*i)) yMesh (prevVal+1);
									end;	
								done;
							end;
						end;
				
					end;

					if (order=1) then
					begin
						(**Adding edge*)
						let rec edgeToNeighbour ngb p =
							(**Probability factor*)
							if (uniform#getValue < max parameters#getPercentOfEdges (float parameters#getMinEdges /. float n#getAmountOfEdges)) then
							begin
								numberOfEdges := !numberOfEdges + 1;
								(**To avoid selecting the same edge when host n is analyzed*)
								if host#getNumberInFile > ngb#getNumberInFile then
								begin
									let midPointX = (host#getX +. ngb#getX) /. 2.00 in
									let midPointY = (host#getY +. ngb#getY) /. 2.00 in
									let z = (2.0 *. float n#getMaxShellIndex) in
									let ngbColor = ngb#getColor in
									let ngbColor = 
										if parameters#getColor = "col" then
											{ r=0.5*.ngbColor.r; g=0.5*.ngbColor.g; b=0.5*.ngbColor.b }
										else
											{ r=1.2*.ngbColor.r; g=1.2*.ngbColor.g; b=1.2*.ngbColor.b }
									in
									(**If it's a connection between cliques, it's drawn closer to the camera*)
									if (host#getShellIndex = n#getMaxShellIndex) & (ngb#getShellIndex = n#getMaxShellIndex) then
									begin
										engine#addCylinder host#getX host#getY (z *. 0.2) midPointX midPointY (z *. 0.2) ngbColor (p *. 0.00476 *. (float n#getMaxShellIndex +. 1.0 -. float n#getMinShellIndex) );
									end
									else
									begin
										engine#addCylinder host#getX host#getY z midPointX midPointY z ngbColor (p *. 0.00176 *. (float n#getMaxShellIndex +. 1.0  -. float n#getMinShellIndex) );
									end;
									
									let hostColor = host#getColor in
									let hostColor = 
										if parameters#getColor = "col" then
											{ r=0.5*.hostColor.r; g=0.5*.hostColor.g; b=0.5*.hostColor.b }
										else
											{ r=1.2*.hostColor.r; g=1.2*.hostColor.g; b=1.2*.hostColor.b }
									in
									if (host#getShellIndex = n#getMaxShellIndex) & (ngb#getShellIndex = n#getMaxShellIndex) then
									begin
										engine#addCylinder midPointX midPointY (z *. 0.2) ngb#getX ngb#getY (z *. 0.2) hostColor (p *. 0.00476 *. (float n#getMaxShellIndex  +. 1.0 -. float n#getMinShellIndex) );
									end
									else
									begin							
										engine#addCylinder midPointX midPointY z ngb#getX ngb#getY z hostColor (p *. 0.00176 *. (float n#getMaxShellIndex  +. 1.0 -. float n#getMinShellIndex) );
									end;
								end
							end
						in
						let rec edgesToNeighbours nl =
						match nl with
						[] -> ()
						| n :: l ->
							match n with (a1,a2) ->
							edgeToNeighbour a1 a2;
							edgesToNeighbours l;
						in
						edgesToNeighbours host#getNeighbours;

					end;
					if host#hasNext = 1 then
						addHost host#getNext order;

				in
				
				(**Component's circle*) 
				(**if c#getShellIndex <> 0 then
				begin
					let color=self#computeHostColor n c#getShellIndex in
					engine#addCircle c#getX c#getY (parameters#getGamma *. c#getU *. float (n#getMaxShellIndex + 1 - c#getShellIndex)) color;
  				end;
				*)	
				(**For vertices, starting from the center*)
				if (order=2)||(order=3) then
					addComponents c#getChildrenComponents order;
				
				let hosts=c#getHosts in
				for cluster = 0 to ((Array.length hosts) - 1) do
					if hosts.(cluster)#hasFirstHost = 1 then
						addHost hosts.(cluster)#getFirstHost order;	
				done;

				(**For edges, starting from outside*)
				if (order=1) then
					addComponents c#getChildrenComponents order;
		
				addComponents compList order;
				
				
		in

		addComponents (n#getComponent :: []) 1;
		addComponents (n#getComponent :: []) 2;
		if parameters#getInputNodeNamesFile <> "" then
			addComponents (n#getComponent :: []) 3;

		(**Cores references*)
		for i = 1 to n#getMaxShellIndex do
		
			let max a b =
				if a > b then
					a
				else b
			in
			let par n =
			if (n mod 2) = 0 then
				true
			else
				false
			in
			
			let nc = ((float n#getMaxShellIndex) +. 1.0 -. (float n#getMinShellIndex)) in
			let x = u *. parameters#getGamma *. (!ratio *. 27.0 /. 24.0) in
			let separationRatio = 0.8 *. u *. float 2 *. parameters#getGamma *. nc /. ((max (float n#getMaxShellIndex) 15.0) *. float 5) in
			let ratio = 1.5 *. separationRatio in
			let y = -.u *. parameters#getGamma *. nc *. 0.9 +. 5.0 *. separationRatio *. float i in
			let color = self#computeHostColor n i in
			
			(**Adding sphere*)
			engine#addHost x y ratio color;
				
			let shellNumber = sprintf "%d" i in
			let size = 4.0 *. 0.8 *. u *. float 2 *. parameters#getGamma *. nc /. (15.0 *. float 5) in
			
			if (n#getMaxShellIndex <= 15) || ((n#getMaxShellIndex - i) mod ((n#getMaxShellIndex / 15) + 1) = 0) then
			begin
				engine#addText shellNumber color size ((x +. 3.0 *. separationRatio) /. size) ((y -. separationRatio) /. size) "left";
			end;
							
		done;
		
		(**Degree references, 5 at most*)
		(**let textColor =
			if parameters#getBckGnd = "black" then
				white
			else
				black
		in*)
		let sphereColor =
			if parameters#getBckGnd = "black" then
				white
			else
				gray
		in
				
		let nc = ((float n#getMaxShellIndex) +. 1.0 -. (float n#getMinShellIndex)) in
		let x = -.u *. parameters#getGamma *. (!ratio *. 15.0 /. 12.0) in
		
		if (parameters#getWeighted = false) || (parameters#getMultigraph = true) then
		begin
			let separationRatio = 1.5 *. (0.0007 +. 0.029 *. (log (float (1 + n#getMaxDegree)) /. log(float n#getMaxDegree))) *. (float n#getMaxShellIndex +. 1.0 -. float n#getMinShellIndex) in
			for i = 1 to 5 do
			let degree = int_of_float (ceil (float n#getMaxDegree/.(4.0**(float (i-1)))) ) in
				if degree > 1 then
		 		begin
				
					let ratio = self#computeHostRatio n 0.0 degree false in
					let y = -.u *. parameters#getGamma *. nc *. 0.5 +. 3.0 *. separationRatio *. float i in
				
					engine#addHost x y ratio sphereColor;
			
					let shellNumber = sprintf "%d" degree in
					let size = 2.0 *. separationRatio in
					engine#addText shellNumber textColor size ((x +. separationRatio) /. size) ((y -. 0.5 *. separationRatio) /. size) "left";
			
				end
			done;
		end
		else
		begin
			let separationRatio = 1.5 *. (0.0007 +. 0.029 *. (log (1.0 +. n#getMaxStrength) /. log(n#getMaxStrength))) *. (float n#getMaxShellIndex +. 1.0 -. float n#getMinShellIndex) in
			for i = 1 to 5 do
			let strength = n#getMaxStrength/.(4.0**(float (i-1))) in
				
				let ratio = self#computeHostRatio n strength 0 true in
				let y = -.u *. parameters#getGamma *. nc *. 0.5 +. 3.0 *. separationRatio *. float i in
			
				engine#addHost x y ratio sphereColor;
		
				let shellNumber = sprintf "%.2f" strength in
				let size = 2.0 *. separationRatio in
				engine#addText shellNumber textColor size ((x +. separationRatio) /. size) ((y -. 0.5 *. separationRatio) /. size) "left";
		
			done;
		end;
			
		engine#close;
			
end;; 
