open Printf;;
open Parameters;;
open Types;;

(**This class generates the .pov file, drawing every host as a sphere and some edges as lines, and adding references*)

(**Definition of class povray*)
class povray_class filename =
object (self)

	val out_file = open_out filename
	
	val mutable r_saved = 0.0
	val mutable u_saved = 0.0
	
	method addHeaders nc u r =
		fprintf out_file "#include \"colors.inc\"\n";
		fprintf out_file "#include \"stones.inc\"\n";
		fprintf out_file "#include \"textures.inc\"\n";
		fprintf out_file "#include \"shapes.inc\"\n";
		fprintf out_file "#include \"glass.inc\"\n";
		fprintf out_file "#include \"metals.inc\"\n";
		fprintf out_file "#include \"woods.inc\"\n";
		fprintf out_file "global_settings { max_trace_level 10 }\n";
		fprintf out_file "global_settings { assumed_gamma 1.8 }\n";
		fprintf out_file "camera { orthographic location <0, 0, %f> look_at  <0, 0, 0> }\n" (-. u *. 2.0 *. parameters#getGamma *. r) ;
		r_saved <- r;
		u_saved <- u;
		fprintf out_file "light_source { < %f, %f, %f> color rgb <1.3, 1.3, 1.3>}\n" nc nc (-.nc/.0.3);
		fprintf out_file "global_settings { ambient_light rgb<0.8, 0.8, 0.8> }\n";
		(**White or black background*)
		if parameters#getBckGnd = "white" then fprintf out_file "background { color rgb <5, 5, 5> }\n";

	method addHost x y ratio color =
		fprintf out_file "sphere { <%.3f, %.3f, %.3f>, %.3f pigment { rgb <%.3f, %.3f, %.3f> }  }\n" x y (float 0) ratio color.r color.g color.b;
	
	method addBlock x y ratio color =
		fprintf out_file "box { <%.3f, %.3f, %.3f>, <%.3f, %.3f, %.3f> pigment { rgb <%.3f, %.3f, %.3f> }  }\n" (x -. ratio) (y -. ratio) (float 0) (x +. ratio) (y +. ratio) (float 0) color.r color.g color.b;
	
	method addCircle x y ratio color =
		fprintf out_file "torus { %f 0.02 rotate -90*x translate <%f,%f,0> pigment { rgb <%f, %f, %f> } }\n" ratio x y color.r color.g color.b;
		
	method addCylinder x1 y1 z1 x2 y2 z2 color diameter =
		(**Verify that base point != apex point, for that would generate an error in povray*)
		if (Pervasives.floor((x1+.0.0005)*.(float)1000) <> Pervasives.floor((x2+.0.0005)*.(float)1000)) || (Pervasives.floor((y1+.0.0005)*.(float)1000) <> Pervasives.floor((y2+.0.0005)*.(float)1000)) || (Pervasives.floor((z1+.0.0005)*.(float)1000) <> Pervasives.floor((z2+.0.0005)*.(float)1000)) then
			fprintf out_file "cylinder { <%.3f, %.3f, %.3f>, <%.3f, %.3f, %.3f> %.3f open texture { pigment { color rgbf <%.3f, %.3f, %.3f> } } }\n" x1 y1 z1 x2 y2 z2 diameter color.r color.g color.b;
	
	method addText text color size x y align =
		let f = ref "" in
		f := align;
		fprintf out_file "text { ttf \"cyrvetic.ttf\" \"%s\" 0.37, 0 pigment { color rgbf < %.3f , %.3f , %.3f> } translate < %.3f , %.3f , %.3f > scale < %.3f , %.3f, %.3f >  }\n" text color.r color.g color.b x y ((-. u_saved *. 1.0 *. parameters#getGamma *. r_saved) /. size) size size size;

	method close =
		(**Close file*)
		close_out out_file;

						
end;;
