(**This class manages the program logs through stdout or log files*)

let null =
        if Sys.os_type = "Win32" then
                "nul"
        else
                "/dev/null";;

class log_class =
object
(self)

	(**Logs must be send to stdout*)
	val mutable isLogStdout = false;

	(**Logs must be send to files*)
	val mutable isLogFile = false;

	(**Names of logs files. They'll be assigned when isLogFile is set to true*)
	val mutable vertexInsertionFile = open_out null;
	val mutable graphFile = open_out null;
	val mutable coresAlgorithmFile = open_out null;
	val mutable degreesFile = open_out null;
	val mutable coresFile = open_out null;
	val mutable centralComponentsFile = open_out null;
	val mutable componentsFile = open_out null;
	val mutable componentsAlgorithmFile = open_out null;

	(**Formatter to send to stdout*)
	val formatstd = Format.std_formatter;

	(**Formatters to send to log files*)
	val mutable vertexInsertionFormat = Format.std_formatter;
	val mutable graphFormat = Format.std_formatter;
	val mutable coresAlgorithmFormat = Format.std_formatter;
	val mutable degreesFormat = Format.std_formatter;
	val mutable coresFormat = Format.std_formatter;
	val mutable centralComponentsFormat = Format.std_formatter;
	val mutable componentsFormat = Format.std_formatter;
	val mutable componentsAlgorithmFormat = Format.std_formatter;

	(**Sets log to stdout*)
	method setLogStdout =
		isLogStdout <- true;
		
	method getLogStdout =
		isLogStdout;
		
	(**Sets log to files*)
	method setLogFile inputFile =
		isLogFile <- true;
		let createDir =
			try
				Unix.mkdir "log" 755
			with
				Unix.Unix_error (a, b, c) -> ();
		in
		createDir;
		(**Log Filenames*)
		vertexInsertionFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/vertexInsertion.log";
		graphFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/graph.log";
		coresAlgorithmFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/coresAlgorithm.log";
		degreesFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/degrees.log";
		coresFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/cores.log";
		centralComponentsFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/centralComponents.log";
		componentsFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/components.log";
		componentsAlgorithmFile <- open_out_gen (Open_append :: Open_creat :: []) 0o600 "log/componentsAlgorithm.log";
		
		(**Log formatters*)
		vertexInsertionFormat <- Format.formatter_of_out_channel vertexInsertionFile;
		graphFormat <- Format.formatter_of_out_channel graphFile;
		coresAlgorithmFormat <- Format.formatter_of_out_channel coresAlgorithmFile;
		degreesFormat <- Format.formatter_of_out_channel degreesFile;
		coresFormat <- Format.formatter_of_out_channel coresFile;
		centralComponentsFormat <- Format.formatter_of_out_channel centralComponentsFile;
		componentsFormat <- Format.formatter_of_out_channel componentsFile;
		componentsAlgorithmFormat <- Format.formatter_of_out_channel componentsAlgorithmFile;
	
		Format.pp_print_string vertexInsertionFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string graphFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string coresAlgorithmFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string degreesFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string coresFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string centralComponentsFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string componentsFormat (Printf.sprintf "**************%s**************\n"inputFile);
		Format.pp_print_string componentsAlgorithmFormat (Printf.sprintf "**************%s**************\n"inputFile);
		
	method getLogFile =
		isLogFile;
		
	(**Prints information in logs. Section indicates one among the possible log sections. See match for examples*)
	method print str section =
			if isLogStdout = true then
			begin
				Format.pp_print_string formatstd str;
				flush stdout
			end;
			if isLogFile = true then
			begin
				match section with
				"vertexInsertion" -> Format.pp_print_string vertexInsertionFormat str
				| "graph" -> Format.pp_print_string graphFormat str
				| "coresAlgorithm" -> Format.pp_print_string coresAlgorithmFormat str
				| "degrees" -> Format.pp_print_string degreesFormat str
				| "cores" -> Format.pp_print_string coresFormat str
				| "centralComponents" -> Format.pp_print_string centralComponentsFormat str
				| "components" -> Format.pp_print_string componentsFormat str
				| "componentsAlgorithm" -> Format.pp_print_string componentsAlgorithmFormat str
				| _ -> ();
			end;

	method closeFiles =
		flush vertexInsertionFile; 
		close_out vertexInsertionFile; 
		close_out graphFile; 
		close_out coresAlgorithmFile; 
		close_out degreesFile; 
		flush coresFile; 
		close_out coresFile; 
		close_out centralComponentsFile; 
		close_out componentsFile; 
		close_out componentsAlgorithmFile; 

end;;

(**The log object*)
let log = new log_class;
