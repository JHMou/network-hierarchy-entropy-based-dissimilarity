(**This module reads a file with nodes and their names, and saves it in the graph*)

open Files;;

class type graph = object method addName: int -> string -> unit end;;

(**Definition of class graph_node_names*)
class graph_node_names_class  =
object
	(**Reads an input file with format:
		file :=  [ set of {line}
				EOF
			line := [ { vertex1 vertex 2 EOL}
				vertex1: int
				vertex2: int
			]
		]
		and builds the graph. Receives the name of the file and the graph*)
	method read_file : 'a 'b. (#graph as 'a) -> string -> unit =
		  fun graph filename ->
		  let f_input = Unix.openfile filename (Unix.O_RDWR :: []) 511 in
	          Gc.set {(Gc.get()) with Gc.space_overhead = 50};
		  let vertex = ref 0
		  and text = ref ""
		  and name = ref ""
          and n = ref 1 in
			while !n > 0 do
            	let line = ref "" in
                	n := readLine f_input line;
                    (try 
                    	(try
							let n = String.index !line '\"' in
							!line.[n] <- ' ';
							let n2 = String.rindex !line '\"' in
							!line.[n2] <- ' ';
						with
							Not_found -> ()
						);
        				
						Scanf.sscanf !line "%d %s@\n" (fun a b -> 	vertex := a;
																	name := b);
						graph#addName !vertex !name;
                    with
                     	End_of_file -> ());
					done
end;;
