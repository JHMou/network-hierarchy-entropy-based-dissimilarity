

#ifndef ANEALING_KNN_H
#define ANEALING_KNN_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "graph_library.h"
#include "rewiring.h"

//----- HEADERS --------//


double calculate_total_js_divergence(int** knn, int** knn_aim, int N, double L); 
double calculate_js_divergence(double* P, double* Q, int N); 
int rewiring_Knn_annealing(GRAPH* G,GRAPH* ORIGINAL_GRAPH,double B,double increment,double accmin,int rewires,double L,double p,gsl_rng* randgsl);
#endif

