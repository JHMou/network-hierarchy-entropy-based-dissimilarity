Simulated annealing for generating networks preserving the node hierarchy structure
========================================================================

The simulated annealing algorithm  inherits the idea from DK model. We put a new subject function aiming to minimize the difference of node hierarchy matrix between the original and generated networks.





