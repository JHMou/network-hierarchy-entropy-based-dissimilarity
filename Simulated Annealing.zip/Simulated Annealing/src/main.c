
#include "main.h"


int main(int argc, char * const argv[]){

 /***********************************************************************
            Read arguments and initialize random generator	
 ************************************************************************/ 
	
	int seed,rewires,pkk;
    double beta0,Abeta,accMIN,dk,L;//L is the parameter for layer
	char netNAME [200],ck [200],cbar [200],tri [200],knn[200];
	
	read_arguments(netNAME,&rewires,&beta0,&Abeta,&accMIN,&pkk,&dk,ck,cbar,tri,knn,&L,&seed,argc,argv);
	
	gsl_rng * randgsl = gsl_rng_alloc(gsl_rng_taus);	/// we initialize the random generator of the gsl
	gsl_rng_set(randgsl,seed);

	GRAPH G_original = read_network(netNAME);

    char nom[200],output [200];                  /// output file name
    
    /****** IF we want to fix the average neighbour degree ******/
    double Final_EN;
    if(strcmp(knn,"none")){
        // k ranges from 1 to 6
        // 50 simulations for each parameter
        int r=6;
        int simu=2;
        for (int k = 5; k <r; ++k){//k=1 represents the degree distribution
             printf("L=%d \n",k);
             for (int p1 = 5; p1 <6; ++p1){
             	double p=(double)p1/10.0;
             	printf("p=%e \n",p);
             	for (int j = 1; j <simu; ++j){
             	   printf("j=%d\n",j);
             	   GRAPH G = read_network(netNAME);
             	   create_edges(&G);               
    		   degree_distribution(&G); 
    		    /**********************************************************************
                 we calculate the target properties
 		***********************************************************************/ 	
		    
		    if(!strcmp(knn ,"original")) G.Knn = Knn(&G);                        /// IF want to fix the average neighbour degree
		    else if(strcmp(knn,"none" )) G.Knn = read_Knn_fromFILE(&G,knn);
    		         
             	   rewiring_Pk(&G,rewires,randgsl); 
             	   sprintf(output,"Initial_%s",netNAME);
             	   print_network (&G,output,0);
        	   Final_EN=rewiring_Knn_annealing (&G,&G_original,beta0,Abeta,accMIN,rewires,k,p,randgsl); 
        	   sprintf(output,"L%d_%d_%d_%d_%s",k,p1,j,(int)Final_EN,netNAME);
        	   print_network (&G,output,0);
    	 	   free(G.node);
    	 	   free(G.edge);
             	}	
             }
        } 
    }
 
 /**********************************************************************
					we print the results	
 ***********************************************************************/

    gsl_rng_free(randgsl);
    return 0;
	
}
//**********************************************************************
//**********************************************************************
//							FUNCTIONS
//**********************************************************************
//**********************************************************************
/// a function that read the arguments of the program
int read_arguments(char netNAME[],int*rewires,double* beta0,double* Abeta,double* accMIN,int* pkk,double* dk,char ck[],char cbar[],char tri[],char knn[],double* L,int* seed,int argc,char * const  argv[]){
	
  /******  Default values *******/
	
    *pkk     = 0;
    *rewires = 1;
    *beta0   = 1;
    *Abeta   = 0.95;
    *L=2;
    *accMIN  =0; //0.00000005;
    *seed    = time(NULL);
    sprintf(ck     ,"none");
    sprintf(cbar   ,"none");
    sprintf(tri    ,"none");
    sprintf(knn    ,"none");
    sprintf(netNAME,"none");
    //
    *dk = 0;
    
    	
  /******  Reading arguments *******/

	int i;
	for (i=1; i<argc; ++i){
                    
		if      (!strcmp(argv[i],"-rewires")) *rewires = atoi(argv[++i]);
        else if (!strcmp(argv[i],"-pkk"    )) *pkk     = atoi(argv[++i]);
		else if (!strcmp(argv[i],"-seed"   )) *seed    = atoi(argv[++i]);
 		else if (!strcmp(argv[i],"-beta0"  )) *beta0   = atof(argv[++i]);
		else if (!strcmp(argv[i],"-Abeta"  )) *Abeta   = atof(argv[++i]);
		else if (!strcmp(argv[i],"-accMIN" )) *accMIN  = atof(argv[++i]);
        else if (!strcmp(argv[i],"-dk"     )) *dk      = atof(argv[++i]);
        else if (!strcmp(argv[i],"-ck"     )) sprintf(ck     ,"%s",argv[++i]);
        else if (!strcmp(argv[i],"-cbar"   )) sprintf(cbar   ,"%s",argv[++i]);
        else if (!strcmp(argv[i],"-tri"    )) sprintf(tri    ,"%s",argv[++i]);
        else if (!strcmp(argv[i],"-knn"    )) sprintf(knn    ,"%s",argv[++i]);
        else if (!strcmp(argv[i],"-L"    )) sprintf(L    ,"%s",argv[++i]);
       	else if (!strcmp(argv[i],"-net"    )) sprintf(netNAME,"%s",argv[++i]);
		
		else {
		  fprintf(stderr,"\nError:    '%s' not recognized as an argument type.\n",argv[i]);
		  fprintf(stderr,"          Before any argument you should first write the argument -key and then the value\n"); 
		  fprintf(stderr,"Example:  ./rng -net netFILE.net -cbar 0.25\n\n");
          fprintf(stderr,"        For more information read the README file \n\n");
		  exit(-1);
		}
       
	}

    /************** dk series *****************************/
    /// if the user uses the dk sries we have to rearrange the arguments
    if( *dk > 0.9 && *dk < 1.1 )  { /// dk = 1
    
        if(*pkk != 0) printf("-pkk 1 contradicts dk 1\n");
        if(strcmp(cbar,"none")) printf("-cbar %s contradicts dk 1\n",cbar);
        if(strcmp(ck  ,"none")) printf("-ck %s contradicts dk 1\n",ck);
        if(strcmp(tri ,"none")) printf("-tri %s contradicts dk 1\n",tri);
        if(strcmp(knn ,"none")) printf("-knn %s contradicts dk 1\n",knn);
        
        
    }
    else if( *dk > 1.9 && *dk < 2.05 ) { /// dk = 2
        
        if(*pkk != 0) printf("-pkk 1 is redundant with dk 2\n");
        *pkk = 1;
        
        if(strcmp(cbar,"none")) printf("-cbar %s contradicts dk 2\n",cbar);
        if(strcmp(ck  ,"none")) printf("-ck %s contradicts dk 2\n",ck);
        if(strcmp(tri ,"none")) printf("-tri %s contradicts dk 2\n",tri);
        if(strcmp(knn ,"none")) printf("-knn %s contradicts dk 2\n",knn);
        
    }
    else if( *dk > 2.05 && *dk < 2.11 ){ /// dk = 2.1
    
        if(*pkk != 0) printf("-pkk 1 is redundant with dk 2.1\n");
        *pkk = 1;
        
        if(strcmp(cbar,"none")) printf("-cbar option contradicts dk 2.1\n");
        sprintf(cbar,"original");
        
        if(strcmp(ck  ,"none")) printf("-ck option contradicts dk 2.1\n");
        if(strcmp(tri ,"none")) printf("-tri option contradicts dk 2.1\n");
        if(strcmp(knn ,"none")) printf("-knn option contradicts dk 2.1\n");
        
        
    }
    else if( *dk > 2.4 && *dk < 2.6 )  { /// dk = 2.5
        
        if(*pkk != 0) printf("-pkk 1 is redundant with dk 2.5\n");
        *pkk = 1;
        
        if(strcmp(ck  ,"none")) printf("-ck %s contradicts dk 2.5\n",ck);
        
        sprintf(ck,"original");
        
        
        if(strcmp(cbar,"none")) printf("-cbar option contradicts dk 2.5\n");
        if(strcmp(tri ,"none")) printf("-tri option contradicts dk 2.5\n");
        if(strcmp(knn ,"none")) printf("-knn option contradicts dk 2.5\n");   
        
    }
    else if(*dk==0){}
    else{                         /// dk = others
    
        printf("the dk value that you want is %2.1f. Are you sure this make sense?\n Possible values are 1,2,2.1,2.5\n Try again and good luck\n",*dk);
        abort();        
        
    }
    
    /******************************************************/
    
    
    
    
    printf("\nARGUMENTS:\n");
    printf("   Network : %s\n",netNAME);
    if  (*pkk) printf("   Preserving the P(k,k')\n");
    else      printf("   Preserving the P(k)\n");
    if(strcmp(cbar,"none")) printf("   Target cbar: %s\n",cbar);
    if(strcmp(ck  ,"none")) printf("   Target c(k): %s\n",ck);
    if(strcmp(tri ,"none")) printf("   Target triangles: %s\n",tri);
    if(strcmp(knn ,"none")) printf("   Target Knn(k): %s\n",knn);
    printf("   Num of rewires x step : %d*E\n   Initial beta : %f\n   Beta increment : %f\n   Min acceptation rate : %f\n",*rewires,*beta0,*Abeta,*accMIN);  
    printf("   Random seed %i\n\n",*seed);
    
    if(!strcmp(netNAME,"none")){
        
        fprintf(stderr,"You did not give any edgelist file name as an imput. Its is necessary\n\n");
        fprintf(stderr,"Example:  ./rng -net netFILE.net -cbar 0.25\n\n");
        fprintf(stderr,"        For more information read the README file \n\n");
        exit(-1);
    }
    
    if(strcmp(cbar,"none") && strcmp(ck,"none")){
        
        printf("You tried to fix the clustering coefficient and the clsuteirng spectrum. Redudant\n");
        printf("We keep the most restricted constrain. The clustering spectrum\n\n");
        sprintf(cbar   ,"%s","none");
    }
    
    if(strcmp(tri,"none") && strcmp(ck,"none")){
        
        printf("You tried to fix the number of triangles and the clusteirng spectrum. Redudant\n");
        printf("We keep the most restricted constrain. The clustering spectrum\n\n");
        sprintf(cbar   ,"%s","none");
    }
    
    if(strcmp(cbar,"none") && strcmp(tri,"none")){
        
        fprintf(stderr,"You tried to fix the clustering coefficient and the number of triangles.\n");
        fprintf(stderr,"Incompatible. Decide which one you prefer and run again the program.\n\n");
        exit(-1);
    }
    if(strcmp(knn,"none") && *pkk){
    
        fprintf(stderr,"You tried to fix the Knn(k) preserving the P(k,k').\n");
        fprintf(stderr,"Incompatible. Decide which one you prefer and run again the program.\n\n");
        exit(-1);
    }
    
    
    
    
  
	
	return 1;
 }

//**********************************************************************
//**********************************************************************
//							END OF CODE		
//**********************************************************************
//**********************************************************************
