


#include "annealingKnn.h"
#include "rewiring.h"

//**********************************************************************
//**********************************************************************
int rewiring_Knn_annealing(GRAPH* G,GRAPH* ORIGINAL_GRAPH,double B,double increment,double accmin,int rewires,double L,double p,gsl_rng* randgsl){

	int N=G->N;
	double q=0.5;
 /***********************************************************************
	 we create a random network with the same degree sequence 
 ************************************************************************/
	int**knn  = calculate_avg_shortest_path_counts(G);	/// we calculate the actual knn, before the move
	int** knn2 = (int**)malloc(G->N * sizeof(int*));  
	for (int i = 0; i < G->N; ++i) {  
		knn2[i] = (int*)malloc((L + 1) * sizeof(int));
	}  

	int**knn_aim =G->avg_shortest_path_counts;
	int i;/// the two are the same at the begining so we copy the first inot the secondone
	for (int i = 0; i < N; ++i) {  
        for (int j = 0; j < L; ++j){ knn2[i][j] = knn[i][j]; // knn2: knn for after the move
		}
	}		       		

	int s1,s2,r1,r2,pos_r,pos_s,j=0;						/// rewiring variables that will store the proposed rewiring
	int accepted=0,rewirestemp=0;					/// during the proces we count how many proposals rewirings are with AH>0, AH<o and AH=0
	double averAH = 0,averAHneg = 0,averAHpos = 0,oldacc=0;
	int numAH0 = 0,numAHneg = 0,numAHpos = 0;
	double H =0;
	double p1=0;
	double * H_values=malloc(rewires*G->E *sizeof(double));
	int h_count=0;
	
    for (int i = 0; i < N; ++i) {  
        for (int j = 0; j < L; ++j) {  
            H += fabs(knn[i][j] - knn_aim[i][j]);  
        }  
    } 
    
       printf("H=%e\n"              ,H);
       fflush(stdout);
	
	/******** we start the rewiring *************/
	
	printf("Fixing Knn(k) by an annealed rewiring ...\n");fflush(stdout);
	printf("G->N = %d\n "                ,G->N);
	printf("G->E = %d\n "                ,G->E);
	time_t start,end;										/// we will measure the time
	double dif;
	time (&start);	
	//int iter=rewires*G->E+2;
	i=1;

	
	int consecutive_zero_count = 0;
	while(H>0){
	    ++i;
	    while(!choose_2_edges_random_heuristic(G,ORIGINAL_GRAPH,&pos_r,&pos_s,p,randgsl)){} /// we try to find two edges avoiding selfedges and multipledges,and aimed to form links 
	    r1 = G->edge[pos_r].s;		 						/// the nodes are
	    r2 = G->edge[pos_r].d; 
	    s1 = G->edge[pos_s].s;		 						/// the nodes are
	    s2 = G->edge[pos_s].d;
	    //keep the heuristic proposeal although it may increas the H with probability q
	    if (edge_exists(ORIGINAL_GRAPH, s1, r2) || edge_exists(ORIGINAL_GRAPH, r1, s2)){
	    
	    	swap_edges(G, s1, s2, r1, r2);
	    	G->edge[pos_r].d = s2;							/// we modify the edge vector
		G->edge[pos_s].d = r2;
		for (int i = 0; i < N; ++i) {  
			for (int j = 0; j <L; ++j) {
					knn[i][j] = knn2[i][j];
			}
		}						/// we update the clustering vector
	    	
	    }
	    else{



        int old_r2 = r2;  
        int old_s2 = s2;  

        swap_edges(G, s1, s2, r1, r2);  
        int** new_knn = calculate_avg_shortest_path_counts(G);
        double Enew = 0;  
       for (int i = 0; i <N; ++i) {  
            for (int j = 0; j <L; ++j) {  
                Enew += fabs(new_knn[i][j] - knn_aim[i][j]);  
            }  
        }  
        double AH = Enew - H;  
	//printf("AH = %e\n "                ,AH);
		averAH = averAH + fabs(AH);							///we also counbt the average AH of the proposals
		
		if(AH < 0.) {										/// we count how many proposals have AH > 0
			
			numAHneg++;
			averAHneg = averAHneg + AH;
		}
		else if (AH > 0.) {									/// we count how many proposals have AH < 0
			
			numAHpos++;
			averAHpos = averAHpos + AH;
			
		}
		else numAH0++;										/// we count how many proposals have AH = 0
		
		p1 =  gsl_rng_uniform(randgsl);						/// we throw a random number (0,1)
		
        
		/********** IF we acccept **************/
		double pro=exp(-AH/B);
		if( p1 <pro){	//B*AH					
			G->edge[pos_r].d = s2;							/// we modify the edge vector
			G->edge[pos_s].d = r2;
			for (int i = 0; i < N; ++i) {  
				for (int j = 0; j <L; ++j) {
						knn[i][j] = knn2[i][j];
				}
			}						/// we update the clustering vector
			
			if(fabs(AH)>0.)	accepted++;						/// we coubt how many changes we accept
			H = H + AH;	

		}
		
		/********** IF we reject **************/
		
		else {
			swap_edges(G, s1, old_r2, r1, old_s2);					
			for (int i = 0; i < N; ++i) {  
				for (int j = 0; j < L; ++j) {knn2[i][j] = knn[i][j];
				}
			}				/// we recover the old connections
		}
		
		rewirestemp++;
		
		/********** we reduce the temperature and we check the acceptance **************/
		//printf("rewirestemp = %d\n "                ,rewirestemp);
		char output [256];
		char netNAME1="karate";
		if(rewirestemp > rewires*G->E ) {	///we try to find the appropiate temperature in order to have the desire acceptation
			sprintf(output,"%d_%d.txt",(int)H,i);
			print_network (G,output,0);
			printf("%d \n",G->N);

			printf("acceptance rate = %f "                ,(double)accepted/(numAHneg+numAHpos));				/// the acceptance
			//printf("AH = %f "                 ,averAH/(numAHneg+numAHpos));							/// the average energy of the proposed swaps
			//printf("numAHneg = %f AHneg = %e ",(double)numAHneg/rewirestemp,averAHneg/numAHneg);	/// the proportion of negative energy swaps and the average
			//printf("numAHpos = %f AHpos = %e ",(double)numAHpos/rewirestemp,averAHpos/numAHpos);	/// the proportion of positive energy swaps and the average
			//printf("numAH0=%f "               ,(double)numAH0/rewirestemp);							/// the proportion of proposals that do not change the energy
			printf("Beta=%e Energy=%e\n AH=%e\n"              ,B,H,AH);
			printf("i=%d\n "              ,i);												/// the temperature and the energy
			printf("p=%e",exp(-AH/B));
			//fflush(stdout);
			if( (double)accepted/(numAHneg+numAHpos) ==0.0) {consecutive_zero_count++;}
			else{consecutive_zero_count=0;}
			if(consecutive_zero_count > 20) {consecutive_zero_count=0;B=1;}
			
			oldacc		= ((double)accepted/(numAHneg+numAHpos));								/// we save the old acceptance in order to compare with the next one
			accepted    = 0;												/// we put to zero all the acceptance counters
			rewirestemp = 0;
			averAH      = 0; numAHneg = 0;averAHneg = 0;
			numAH0      = 0; numAHpos = 0;averAHpos = 0;
			
			B = B*increment;
			if (h_count<rewires*G->E){
			H_values[h_count++]=H;
			}
											/// we reduce the temperature			
		}
		
	}		
	}
	double Final_H=H;
	
	
	
	time (&end);
	dif = difftime (end,start);
	printf ("You rewired the entire network %.2f times with %.2lf seconds.\n",(double)i/G->E, dif );
	for (int i=0;i<h_count;i++){
	printf("%d",(int)H_values[i]);
	printf(",");
	}
	
 /***********************************************************************
		 we free the memory
 ************************************************************************/
	//output the aim_bfs
	for (int i = 0; i < N; ++i) {  
        for (int j = 0; j < L; ++j) {  
            H += fabs(knn[i][j] - knn_aim[i][j]);  
        }  
    } 
	
	
	free(knn);
	free(knn2);

	return Final_H;
	
}

//**********************************************************************
//**********************************************************************
/// a function that calculates the difference in the clustering that the proposed change does  

double calculate_total_js_divergence(int** knn, int** knn_aim, int N, double L) {  
    double total_js_divergence = 0.0;  


    for (int j = 0; j < L; ++j) {  

        double P[N], Q[N];  


        for (int i = 0; i < N; ++i) {  
            P[i] = knn[i][j];  
            Q[i] = knn_aim[i][j];  

        }  

        double js_divergence = calculate_js_divergence(P, Q, N);  
        total_js_divergence += js_divergence;  
    }  

    return total_js_divergence;  
}



double calculate_js_divergence(double* P, double* Q, int N) {  
    double M[N];  
    double kl_p_m = 0.0, kl_q_m = 0.0;  

    for (int i = 0; i < N; ++i) {  
        M[i] = 0.5 * (P[i] + Q[i]);  
    }  

    for (int i = 0; i < N; ++i) {  
        kl_p_m += P[i] * log(P[i] / M[i]);  
        kl_q_m += Q[i] * log(Q[i] / M[i]);  
    }  

    return 0.5 * kl_p_m + 0.5 * kl_q_m;  
}  
