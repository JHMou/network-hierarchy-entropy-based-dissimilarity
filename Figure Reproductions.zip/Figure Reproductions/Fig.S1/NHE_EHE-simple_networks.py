import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import Network_hierarchy as nh
from tqdm import tqdm
import pickle


def Special_size():
    """
    Analyze how network hierarchy metrics change with different network sizes.
    Generates three types of networks (cycle, star, path) with varying sizes
    and calculates their node hierarchy entropy and edge hierarchy entropy.
    Saves the results to pickle files for later analysis.
    """
    # Different network sizes to analyze (from 3 to 1499 nodes)
    NETWORK_SIZE = list(range(3, 1500))
    node_similarity_list = []
    edge_similarity_list = []

    # Analyze cycle graphs (ring networks)
    for n in tqdm(NETWORK_SIZE):
        G1 = nx.cycle_graph(n)
        a1, b1 = nh.NND_GAP_cross3(G1)
        node_similarity_list.append(a1)
        edge_similarity_list.append(b1)

    df = pd.DataFrame({
        'node': node_similarity_list,
        'edge': edge_similarity_list,
        'n': NETWORK_SIZE
    })
    # Save cycle graph results to pickle file
    with open('./Fig.S1/DF_cycle.pkl', 'wb') as file:
        pickle.dump(df, file)

    # Reset lists for star graph analysis
    node_similarity_list = []
    edge_similarity_list = []
    NETWORK_SIZE = list(range(3, 1500))

    # Analyze star graphs (hub-and-spoke networks)
    for n in tqdm(NETWORK_SIZE):
        G1 = nx.star_graph(n)  # Create a star graph with n nodes (1 center + n-1 leaves)
        a1, b1 = nh.NND_GAP_cross3(G1)
        node_similarity_list.append(a1)
        edge_similarity_list.append(b1)

    df = pd.DataFrame({
        'node': node_similarity_list,
        'edge': edge_similarity_list,
        'n': NETWORK_SIZE
    })

    with open('./Fig.S1/DF_star.pkl', 'wb') as file:
        pickle.dump(df, file)

    # Reset lists for path graph analysis
    node_similarity_list = []
    edge_similarity_list = []
    NETWORK_SIZE = list(range(2, 1500))  # Path graphs can start from 2 nodes

    # Analyze path graphs (linear chains)
    for n in tqdm(NETWORK_SIZE):
        G1 = nx.path_graph(n)
        a1, b1 = nh.NND_GAP_cross3(G1)
        node_similarity_list.append(a1)
        edge_similarity_list.append(b1)

    df = pd.DataFrame({
        'node': node_similarity_list,
        'edge': edge_similarity_list,
        'n': NETWORK_SIZE
    })
    with open('./Fig.S1/DF_line.pkl', 'wb') as file:
        pickle.dump(df, file)


def draw_Special_size():
    """
    Visualize the relationship between node hierarchy entropy and edge hierarchy entropy
    for different network types (cycle, star, path) across various network sizes.
    """
    files = './Fig.S1/DF_cycle.pkl'
    with open(files, 'rb') as file:
        df = pickle.load(file)

    plt.figure()
    sns.scatterplot(x='node', y='edge', data=df, hue='n')
    plt.title('Cycle Graph')
    plt.show()
    files = './Fig.S1/DF_star.pkl'
    with open(files, 'rb') as file:
        df = pickle.load(file)

    plt.figure()
    sns.scatterplot(x='node', y='edge', data=df, hue='n')
    plt.title('Star Graph')
    plt.show()

    files = './Fig.S1/DF_line.pkl'
    with open(files, 'rb') as file:
        df = pickle.load(file)

    plt.figure()
    sns.scatterplot(x='node', y='edge', data=df, hue='n')
    plt.title('Line Graph ')
    plt.show()


if __name__ == '__main__':
    """
    Main execution block for network size analysis.
    First generates the network data and calculates metrics, then creates visualizations.
    """
    # Step 1: Generate network data and calculate NHE metrics
    Special_size()

    # Step 2: Create visualizations of the results
    draw_Special_size()