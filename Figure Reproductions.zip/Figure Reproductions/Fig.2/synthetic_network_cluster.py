import math
import pickle
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import itertools
import seaborn as sns
import Network_hierarchy as nh
from tqdm import tqdm
from multiprocessing import Pool
import LFR_init as lfr_init
from collections import defaultdict


def WS_BA_ER_distance_model_p_station():
    """
    Generates multiple network models and computes similarity matrices between them.

    Input: None
    Output: None (results are saved to a pickle file)
    Function:
        - Generates WS small-world, ER random, BA scale-free, and LFR benchmark networks
        - Creates multiple instances with different parameters for each model type
        - Uses multiprocessing to compute pairwise network similarities in parallel
        - Saves results to file for subsequent clustering analysis
    """
    G_dict = {}
    G_list = []
    NETWORK_SIZE = 500
    per_num = 5

    # Generate Watts-Strogatz small-world networks
    p = [0.0005, 0.005, 0.05, 0.5]
    for p1 in (p):
        for inum in range(per_num):
            num_neighbor = 8
            G1 = nx.watts_strogatz_graph(NETWORK_SIZE, num_neighbor, p1, seed=inum)
            G_dict[('WS', p1)] = G1
            G_list.append(G1)

    # Generate Erdős-Rényi random networks
    p = [0.0005, 0.005, 0.05, 0.5]
    for p1 in (p):
        for inum in range(per_num):
            G1 = nx.erdos_renyi_graph(NETWORK_SIZE, p1, seed=inum)
            G_dict[('ER', p1)] = G1
            G_list.append(G1)

    # Generate Barabási-Albert scale-free networks
    m = [1, 3, 5, 7]
    for num_neighbor in m:
        for inum in range(per_num):
            G1 = nx.barabasi_albert_graph(NETWORK_SIZE, num_neighbor, seed=inum)
            G_dict[('BA', num_neighbor)] = G1
            G_list.append(G1)

    # Generate LFR benchmark networks with community structure
    mu_list = list(np.arange(1, 5))
    for i in range(len(mu_list)):
        mu = mu_list[i]
        for inum in range(per_num):
            paras = {"n": NETWORK_SIZE, "tau1": 1.5, "tau2": 1.5, "mu": mu / 10, "average_d": 10, "max_d": 50,
                     "min_community": 15,
                     "max_community": 120, "seed": inum}
            args = tuple(paras.values())
            G1, true_label = lfr_init.LFR_init(*args)
            G_dict[('LFR', '1.5', mu)] = G1
            G_list.append(G1)

    # Additional LFR networks with different tau1 parameters
    for i in range(len(mu_list)):
        mu = mu_list[i]
        for inum in range(per_num):
            paras = {"n": NETWORK_SIZE, "tau1": 2.5, "tau2": 1.5, "mu": mu / 10, "average_d": 10, "max_d": 50,
                     "min_community": 15,
                     "max_community": 120, "seed": inum}
            args = tuple(paras.values())
            G1, true_label = lfr_init.LFR_init(*args)
            G_dict[('LFR', '2.5', mu)] = G1
            G_list.append(G1)

    for i in range(len(mu_list)):
        mu = mu_list[i]
        for inum in range(per_num):
            paras = {"n": NETWORK_SIZE, "tau1": 3.5, "tau2": 1.5, "mu": mu / 10, "average_d": 10, "max_d": 50,
                     "min_community": 15,
                     "max_community": 120, "seed": inum}
            args = tuple(paras.values())
            G1, true_label = lfr_init.LFR_init(*args)
            G_dict[('LFR', '3.5', mu)] = G1
            G_list.append(G1)

    print(len(G_list))

    # Parallel computation of network similarities
    cpu_cores = 40
    pool = Pool(cpu_cores)
    results = []
    mobility_list = []
    for g_id in (range(len(G_list))):
        results.append(pool.apply_async(WS_BA_ER_distance_model_p, args=(G_list, g_id)))
    pool.close()
    pool.join()
    for result in [r.get() for r in results]:
        mobility_list.append(result)

    # Save results to file
    with open('./Model_cluster_10_other.pkl',
              'wb') as file:
        pickle.dump(mobility_list, file)


def WS_BA_ER_distance_model_p(G_list, g_id):
    """
    Computes similarity measures between a target network and all networks in the list.

    Input:
        G_list: List of network graphs
        g_id: Index of the target network in G_list

    Output:
        List containing:
            [0]: Dictionary with NHE (Network Hierarchy Entropy) features of the target network
            [1]: Dictionary of similarity matrices for different similarity measures

    Function:
        - Computes NHE features for the target network
        - Calculates various similarity measures between target network and all other networks
        - Constructs symmetric similarity matrices for each similarity measure
    """
    # Compute NHE features for the target network
    model_dict = {}
    g11 = G_list[g_id]
    a1, b1 = nh.NND_GAP_cross3(g11)
    model_dict[g_id] = [a1, b1]

    # Initialize dictionaries for storing similarity results
    result_2list_dict = {}
    result_dict = defaultdict(list)
    id_list = list(range(len(G_list)))

    # Compute similarities between target network and all other networks
    for value1 in tqdm(id_list):
        G1 = G_list[value1]
        G2 = G_list[g_id]
        other_dict = nh.similarity_2g_various_size(G1, G2)
        for key, value in other_dict.items():
            result_dict[key].append((g_id, value1, value))

    # Construct symmetric similarity matrices for each measure
    for key, value_list in result_dict.items():
        result_2list = np.array([[0] * len(id_list)] * len(id_list), dtype=float)
        for ivalue in value_list:
            result_2list[id_list.index(ivalue[0]), id_list.index(ivalue[1])] = ivalue[2]
            result_2list[id_list.index(ivalue[1]), id_list.index(ivalue[0])] = ivalue[2]
        result_2list_dict[key] = result_2list

    return [model_dict, result_2list_dict]


from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import normalized_mutual_info_score


def draw_model_cluster():
    """
    Loads network similarity results and performs clustering analysis with visualization.

    Input: None (reads from pickle file)
    Output: None (displays visualization plots)

    Function:
        - Loads precomputed network similarity data
        - Constructs distance matrices from NHE features and other similarity measures
        - Performs hierarchical clustering on each distance matrix
        - Computes NMI scores to evaluate clustering quality against ground truth labels
        - Visualizes distance matrices as heatmaps with clustering results
    """
    files = './Model_cluster_10_other.pkl'
    with open(files, 'rb') as file:
        model_cluster = pickle.load(file)

    n = 120
    NHE_dict = defaultdict(list)
    other_dict = defaultdict(list)

    # Extract NHE features and similarity matrices from loaded data
    for index in range(len(model_cluster)):
        imodel = model_cluster[index]
        id_nhe_dict = imodel[0]

        NHE_dict[list(id_nhe_dict.keys())[0]].append(list(id_nhe_dict.values())[0])
        id_other_dict = imodel[1]
        for imethod, matric in id_other_dict.items():
            other_dict[imethod].append(list(matric[index]))

    # Construct NHE distance matrix using Euclidean distance
    NHE_matirx = np.zeros((n, n), dtype=np.float64)
    for ikey1, value1 in NHE_dict.items():
        for ikey2, value2 in NHE_dict.items():
            a1, b1 = value1[0][0], value1[0][1]
            a2, b2 = value2[0][0], value2[0][1]
            d = math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2)
            NHE_matirx[ikey1, ikey2] = d

    # Create ground truth labels (5 instances for each of 24 network types)
    TRUE_LABEL = list(itertools.chain.from_iterable([num] * 5 for num in range(1, 25)))

    # Prepare matrices and titles for visualization
    matrices = []
    matrices.append(NHE_matirx)
    titles = ['NHE']
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()

    for imethod, value in other_dict.items():
        matrices.append(value)
        titles.append(imethod)

    # Visualize each distance matrix and perform clustering
    for i, (matrix1, title, ax) in enumerate(zip(matrices, titles, axes)):
        matrix = matrix1
        mask = np.array(matrix) == 0
        g = sns.heatmap(matrix,
                        cmap='RdYlBu',
                        ax=ax,
                        mask=mask,
                        square=True)
        g.set_facecolor('xkcd:white')
        g.invert_yaxis()
        ax.set_title(title, fontsize=12)
        ax.set_xticks([])
        ax.set_yticks([])
        print(title)

        # Perform hierarchical clustering and evaluate with NMI
        hierarchical = AgglomerativeClustering(n_clusters=24, affinity='precomputed',
                                               linkage='complete')
        hierarchical_labels = hierarchical.fit_predict(matrix)
        nmi_score = normalized_mutual_info_score(TRUE_LABEL, hierarchical_labels)
        print(f'NMI: {nmi_score:.4f}')

    plt.show()


if __name__ == '__main__':
    # Generate network data and similarity matrices
    WS_BA_ER_distance_model_p_station()
    # Run clustering analysis
    draw_model_cluster()
