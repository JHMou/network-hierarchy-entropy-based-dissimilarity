import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import Network_hierarchy as nh
from tqdm import tqdm
import load_data as ldata
import pickle
from collections import defaultdict
from multiprocessing import Pool
from scipy.spatial.distance import pdist, squareform
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import accuracy_score
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import MinMaxScaler
from dotmotif import Motif, GrandIsoExecutor
from collections import Counter


def graph_classification():
    """
    Calculates node and edge similarity features for graphs in the Enzymes dataset.
    Saves the results to a pickle file for later analysis.
    """
    # Define data directory and dataset name
    datadir = './DATA/Enzymes'
    dataname_list = ['DD']
    type_list = []
    node_similarity_list = []
    edge_similarity_list = []
    glabel = []

    # Process each dataset
    for dataname in dataname_list:
        # Load graphs from the dataset
        Graphs = ldata.read_graphfile(datadir, dataname, max_nodes=None)

        # Calculate NHE features for each graph
        for G1 in tqdm(Graphs):
            a1, b1 = nh.NND_GAP_cross3(G1)
            node_similarity_list.append(a1)
            edge_similarity_list.append(b1)
            type_list.append(dataname)
            glabel.append(G1.graph['label'])

    # Create DataFrame with calculated features
    df = pd.DataFrame({
        'node': node_similarity_list,
        'edge': edge_similarity_list,
        'type': type_list,
        'label': glabel
    })

    # Save results to pickle file
    with open('./Fig.6/graph_classification_label.pkl', 'wb') as file:
        pickle.dump(df, file)


def graph_true_label():
    """
    Extract and save the true labels for graphs in the Enzymes dataset.
    Creates a mapping from graph index to graph object.
    """
    datadir = './DATA/Enzymes'
    dataname_list = ['DD']
    true_label = {}

    for dataname in dataname_list:
        Graphs = ldata.read_graphfile(datadir, dataname, max_nodes=None)

        # Store each graph with its index as key
        for G1 in tqdm(Graphs):
            true_label[Graphs.index(G1)] = G1

    # Save graph ID mapping to pickle file
    with open('./Fig.6/graph_id.pkl', 'wb') as file:
        pickle.dump(true_label, file)


def graph_clalssification_per(Graphs, G1):
    """
    Calculate similarity between a target graph G1 and all other graphs in Graphs
    using various network similarity measures.

    Args:
        Graphs: List of graph objects
        G1: Target graph for comparison

    Returns:
        defaultdict: Dictionary containing similarity results for different methods
    """
    result_dict = defaultdict(list)

    # Compare G1 with every other graph in the dataset
    for G2 in tqdm(Graphs):
        other_dict = nh.similarity_2g_various_size(G1, G2)

        # Store results by method type
        for key, value in other_dict.items():
            result_dict[key].append(([Graphs.index(G1), Graphs.index(G2)], value))

    return result_dict


def graph_classification_others():
    """
    Perform graph classification using multiple similarity methods in parallel.
    Calculates pairwise similarities between all graphs using IM, POR, NetSimile, NetLSD, and d-measure.
    Uses multiprocessing for efficient computation.
    """
    datadir = './DATA/Enzymes'
    dataname_list = ['DD']
    results_list = []

    # Set up parallel processing
    cpu_cores = 20
    pool = Pool(cpu_cores)
    results = []

    for dataname in dataname_list:
        Graphs = ldata.read_graphfile(datadir, dataname, max_nodes=None)

        # Process each graph in parallel
        for G1 in (Graphs):
            results.append(pool.apply_async(graph_clalssification_per, args=(Graphs, G1)))

        # Wait for all processes to complete
        pool.close()
        pool.join()
        print('done')

        # Collect results from all processes
        for result in [r.get() for r in results]:
            results_list.append(result)

    # Save results to pickle file
    with open('./Fig.6/graph_classification_others_DD.pkl', 'wb') as file:
        pickle.dump(results_list, file)


def graph_classification_heatmap():
    """
    Perform clustering analysis on graph classification data using NHE method.
    Calculates distance matrix, performs hierarchical clustering, and evaluates clustering quality.

    Returns:
        pandas.DataFrame: DataFrame containing intra-class and inter-class distance metrics
    """
    # Load graph ID mapping
    files = './Fig.6/graph_id.pkl'
    with open(files, 'rb') as file:
        graph_id = pickle.load(file)

    # Load graph classification labels
    files = './Fig.6/graph_classification_label.pkl'
    with open(files, 'rb') as file:
        graph_classification = pickle.load(file)

    type_list = ['DD']

    for i in type_list:
        # Filter data for current graph type
        igraph1 = graph_classification[graph_classification['type'] == i].copy()
        igraph2 = igraph1

        # Extract node and edge features
        combined_data = igraph2[['node', 'edge']]

        # Save data for reference
        igraph2.to_csv('./Fig.6/true_label.csv')
        combined_data.to_csv('./Fig.6/data_df.txt')

        # Calculate Euclidean distance matrix
        distance_matrix = squareform(pdist(combined_data, metric='euclidean'))

        # Perform hierarchical clustering with 2 clusters
        hierarchical = AgglomerativeClustering(n_clusters=2, affinity='precomputed', linkage='complete')
        hierarchical_labels = hierarchical.fit_predict(distance_matrix)

        # Calculate silhouette score for clustering quality
        score = silhouette_score(distance_matrix, hierarchical_labels, metric='precomputed')
        print(f"Silhouette Score: {score:.3f}")

        # Separate intra-class and inter-class distances
        same_class_distances = []
        different_class_distances = []

        for i in range(len(hierarchical_labels)):
            for j in range(len(hierarchical_labels)):
                if i != j:
                    if hierarchical_labels[i] == hierarchical_labels[j]:
                        same_class_distances.append(distance_matrix[i, j])
                    else:
                        different_class_distances.append(distance_matrix[i, j])

        # Create distance metrics DataFrame
        distances_df = pd.DataFrame({
            'Distance': same_class_distances + different_class_distances,
            'Type': ['Same Class'] * len(same_class_distances) + ['Different Class'] * len(different_class_distances),
            'method': ['NHE'] * (len(same_class_distances) + len(different_class_distances))
        })

        # Normalize distances to [0, 1] range
        scaler = MinMaxScaler()
        distances_df['Distance'] = scaler.fit_transform(distances_df[['Distance']])

        # Add metadata to combined data
        combined_data['id'] = list(graph_id.keys())
        combined_data['Hierarchical_Cluster'] = hierarchical_labels
        combined_data['true_label'] = list(igraph2.label)

        # Calculate clustering accuracy
        print('Classification Results')
        hierarchical_accuracy = accuracy_score(list(igraph2.label), hierarchical_labels)
        print(f'Hierarchical Clustering Accuracy: {hierarchical_accuracy:.4f}')

        return distances_df


def graph_classification_heatmap_others():
    """
    Perform clustering analysis using other network similarity methods (IM, POR, NetSimile, NetLSD, d-measure).
    Processes precomputed distance matrices and evaluates clustering performance.

    Returns:
        list: List of DataFrames containing distance metrics for each method
    """
    files = './Fig.6/graph_classification_others_DD.pkl'
    with open(files, 'rb') as file:
        graph_classification1 = pickle.load(file)

    # Reorganize data by method type
    graph_classification = defaultdict(list)
    for inode in graph_classification1:
        for key, value in inode.items():
            for ivalue in value:
                graph_classification[key].append(ivalue)

    # Load true labels
    files = './Fig.6/graph_classification_label.pkl'
    with open(files, 'rb') as file:
        graph_label = pickle.load(file)

    # Methods to process
    method_list = ['IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure']
    matrix_shape = (1178, 1178)  # Assuming 1178 graphs in DD dataset
    network_type = 'DD'
    result_list = []

    for imethod in method_list:
        print(imethod)
        igraph1 = graph_label[graph_label['type'] == network_type].copy()
        result_imethod = graph_classification[imethod]

        matrix = np.zeros(matrix_shape)
        for iarray in result_imethod:
            coordinates, value = iarray
            x, y = coordinates
            matrix[x, y] = value

        # Perform hierarchical clustering
        hierarchical = AgglomerativeClustering(n_clusters=2, affinity='precomputed', linkage='complete')
        hierarchical_labels = hierarchical.fit_predict(matrix)

        # Calculate silhouette score
        score = silhouette_score(matrix, hierarchical_labels, metric='precomputed')
        print(f"Silhouette Score: {score:.3f}")

        # Separate intra-class and inter-class distances
        same_class_distances = []
        different_class_distances = []

        for i in range(len(hierarchical_labels)):
            for j in range(len(hierarchical_labels)):
                if i != j:  # Exclude self-distances
                    if hierarchical_labels[i] == hierarchical_labels[j]:
                        same_class_distances.append(matrix[i, j])
                    else:
                        different_class_distances.append(matrix[i, j])

        # Create distance metrics DataFrame
        distances_df = pd.DataFrame({
            'Distance': same_class_distances + different_class_distances,
            'Type': ['Same Class'] * len(same_class_distances) + ['Different Class'] * len(different_class_distances),
            'method': [imethod] * (len(same_class_distances) + len(different_class_distances))
        })

        # Normalize distances
        scaler = MinMaxScaler()
        distances_df['Distance'] = scaler.fit_transform(distances_df[['Distance']])
        result_list.append(distances_df)

        # Calculate confusion matrix components
        true_label = list(igraph1.label)
        TP_LIST = 0  # True Positives
        FN_LIST = 0  # False Negatives
        FP_LIST = 0  # False Positives
        TN_LIST = 0  # True Negatives

        for i11 in range(len(hierarchical_labels)):
            if (hierarchical_labels[i11] == 1) and (true_label[i11] == 1):
                TP_LIST += 1
            if (hierarchical_labels[i11] == 0) and (true_label[i11] == 0):
                FN_LIST += 1
            if (hierarchical_labels[i11] == 1) and (true_label[i11] == 0):
                FP_LIST += 1
            if (hierarchical_labels[i11] == 0) and (true_label[i11] == 1):
                TN_LIST += 1

        # Calculate clustering accuracy
        print('Classification Results')
        hierarchical_accuracy = accuracy_score(list(igraph1.label), hierarchical_labels)
        print(f'Hierarchical Clustering Accuracy: {hierarchical_accuracy:.4f}')

    return result_list


def motif(G):
    # Create motif search executor
    E = GrandIsoExecutor(graph=G)

    # Define 8 different motif patterns
    motif1 = Motif("""
    A -> B
    B -> C
    """, ignore_direction=True, exclude_automorphisms=True)
    results1 = E.find(motif1)

    motif2 = Motif("""
        A -> B
        B -> C
        C -> A
        """, ignore_direction=True, exclude_automorphisms=True)
    results2 = E.find(motif2)

    motif3 = Motif("""
        A -> B
        B -> C
        B -> D
        """, ignore_direction=True, exclude_automorphisms=True)
    results3 = E.find(motif3)

    motif4 = Motif("""
        A -> B
        B -> C
        C -> D
        """, ignore_direction=True, exclude_automorphisms=True)
    results4 = E.find(motif4)

    motif5 = Motif("""
        A -> B
        A -> C
        B -> C
        C -> D
        """, ignore_direction=True, exclude_automorphisms=True)
    results5 = E.find(motif5)

    motif6 = Motif("""
        A -> B
        B -> C
        C -> D
        D -> A
        """, ignore_direction=True, exclude_automorphisms=True)
    results6 = E.find(motif6)

    motif7 = Motif("""
        A -> B
        A -> C
        B -> C
        C -> D
        D -> A        
        """, ignore_direction=True, exclude_automorphisms=True)
    results7 = E.find(motif7)

    motif8 = Motif("""
        A -> B
        A -> C
        B -> C
        B -> D
        C -> D
        D -> A 
        """, ignore_direction=True, exclude_automorphisms=True)
    results8 = E.find(motif8)

    return [len(results1), len(results2), len(results3), len(results4),
            len(results5), len(results6), len(results7), len(results8)]


def draw_motif_DD():
    """
    Analyze and visualize motif distributions for different classification outcomes in DD dataset.
    Compares motif patterns across True Positive, False Negative, True Negative, and False Positive classifications.
    Creates a boxenplot visualization of motif counts.
    """
    # Load graph classification data
    files = './Fig.6/graph_classification.pkl'
    with open(files, 'rb') as file:
        graph_classification = pickle.load(file)

    # Load graph ID mapping
    files = './Fig.6/graph_id.pkl'
    with open(files, 'rb') as file:
        graph_id = pickle.load(file)

    # Load graph classification labels
    files = './Fig.6/graph_classification_label.pkl'
    with open(files, 'rb') as file:
        graph_label = pickle.load(file)

    graph_classification['label'] = graph_label['label']
    type_list = ['DD']

    for i in type_list:
        # Filter data for DD graphs
        igraph1 = graph_classification[graph_classification['type'] == i].copy()
        igraph2 = igraph1
        combined_data = igraph2[['node', 'edge']]

        # Count label distribution
        label_num = list(igraph2.label)
        counter1 = Counter(label_num)

        # Calculate distance matrix and perform clustering
        distance_matrix = squareform(pdist(combined_data, metric='euclidean'))
        hierarchical = AgglomerativeClustering(n_clusters=2, affinity='precomputed', linkage='complete')
        hierarchical_labels = hierarchical.fit_predict(distance_matrix)

        # Separate intra-class and inter-class distances
        same_class_distances = []
        different_class_distances = []

        for i in range(len(hierarchical_labels)):
            for j in range(len(hierarchical_labels)):
                if i != j:  # Exclude self-distances
                    if hierarchical_labels[i] == hierarchical_labels[j]:
                        same_class_distances.append(distance_matrix[i, j])
                    else:
                        different_class_distances.append(distance_matrix[i, j])

        # Create distance metrics DataFrame
        distances_df = pd.DataFrame({
            'Distance': same_class_distances + different_class_distances,
            'Type': ['Same Class'] * len(same_class_distances) + ['Different Class'] * len(different_class_distances),
            'method': ['NHE'] * (len(same_class_distances) + len(different_class_distances))
        })

        # Normalize distances
        scaler = MinMaxScaler()
        distances_df['Distance'] = scaler.fit_transform(distances_df[['Distance']])

        # Add metadata to combined data
        combined_data['id'] = list(graph_id.keys())
        combined_data['Hierarchical_Cluster'] = hierarchical_labels
        combined_data['true_label'] = list(igraph2.label)

        # Analyze graphs by classification outcome
        combined_data_TP = combined_data[(combined_data.Hierarchical_Cluster == 1) & (combined_data.true_label == 1)]
        print(f"True Positives: {combined_data_TP.shape[0]}")
        id_TP = list(combined_data_TP.id)

        motif_list = []
        label_list = []
        value_list = []

        # Count motifs for True Positive graphs
        for id1 in tqdm(range(len(id_TP))):
            g1 = graph_id[id_TP[id1]]
            motif_g1 = motif(g1)
            label_list.extend(['TP'] * 8)  # 8 motif types
            motif_list.extend(list(range(1, 9)))
            value_list.extend(motif_g1)

        combined_data_FN = combined_data[(combined_data.Hierarchical_Cluster == 0) & (combined_data.true_label == 0)]
        print(f"False Negatives: {combined_data_FN.shape[0]}")
        id_FN = list(combined_data_FN.id)

        for id1 in tqdm(range(len(id_FN))):
            g1 = graph_id[id_FN[id1]]
            motif_g1 = motif(g1)
            label_list.extend(['FN'] * 8)
            motif_list.extend(list(range(1, 9)))
            value_list.extend(motif_g1)

        combined_data_TN = combined_data[(combined_data.Hierarchical_Cluster == 0) & (combined_data.true_label == 1)]
        print(f"True Negatives: {combined_data_TN.shape[0]}")
        id_TN = list(combined_data_TN.id)

        for id1 in tqdm(range(len(id_TN))):
            g1 = graph_id[id_TN[id1]]
            motif_g1 = motif(g1)
            label_list.extend(['TN'] * 8)
            motif_list.extend(list(range(1, 9)))
            value_list.extend(motif_g1)

        combined_data_FP = combined_data[(combined_data.Hierarchical_Cluster == 1) & (combined_data.true_label == 0)]
        print(f"False Positives: {combined_data_FP.shape[0]}")
        id_FP = list(combined_data_FP.id)

        for id1 in tqdm(range(len(id_FP))):
            g1 = graph_id[id_FP[id1]]
            motif_g1 = motif(g1)
            label_list.extend(['FP'] * 8)
            motif_list.extend(list(range(1, 9)))
            value_list.extend(motif_g1)

        # Save motif data
        with open('./Fig.6/DD_motif_TP.pkl', 'wb') as file:
            pickle.dump([label_list, motif_list, value_list], file)

    # Create DataFrame for visualization
    motif_dict = {
        'label': label_list,
        'motif': motif_list,
        'value': list(np.log10(np.array(value_list)))  # Log-transform for better visualization
    }
    motif_df = pd.DataFrame(motif_dict)

    # Filter out zero values
    motif_df_query = motif_df.query('value != 0')

    # Create visualization
    palette = sns.color_palette("husl", n_colors=len(motif_df_query['label'].unique()))

    plt.figure(figsize=(10, 6))
    sns.boxenplot(
        x="motif",
        y="value",
        hue="label",
        data=motif_df_query,
        k_depth='trustworthy',
        showfliers=False,
        palette=palette,
    )
    plt.ylim(1, 6)
    plt.show()


def draw_graph_classification():
    """
    Create combined visualization comparing distance distributions across all methods.
    Generates a boxplot showing intra-class vs inter-class distances for NHE and other methods.
    """
    # Get results from both NHE and other methods
    result1 = graph_classification_heatmap()
    result2 = graph_classification_heatmap_others()

    # Combine all results into single DataFrame
    df_vertical = pd.concat([result1, result2[0], result2[1], result2[2], result2[3], result2[4]],
                            axis=0, ignore_index=True)

    # Create comparative boxplot
    plt.figure(figsize=(12, 6))
    sns.set_theme(style="ticks", palette="pastel")
    sns.boxplot(data=df_vertical, x='method', y='Distance', hue='Type', palette=["m", "g"])
    sns.despine(offset=10, trim=True)
    plt.show()


if __name__ == '__main__':
    """
    Main execution block for graph classification analysis pipeline.
    """
    # Step 1: Extract and save graph true labels
    graph_true_label()

    # Step 2: Perform graph classification using NHE method
    graph_classification()

    # Step 3: Perform graph classification using other methods
    graph_classification_others()

    # Step 4: Analyze and visualize motif distributions
    draw_motif_DD()

    # Step 5: Create comparative visualization of all methods
    draw_graph_classification()