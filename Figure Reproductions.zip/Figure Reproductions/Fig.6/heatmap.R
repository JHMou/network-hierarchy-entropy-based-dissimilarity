# 清空全局环境  
rm(list=ls())  
setwd('E:/博士/研究/BFS网络相似性/热图绘制并添加注释')  # 设置工作路径  

# 加载所需的包  
library(pheatmap)  
library(reshape2)  # 用于数据处理  
library(ggplot2)   # 用于 ggplot 绘图  
library(RColorBrewer)  # 提供调色板  
library(cowplot)   # 用于组合图形  

# 读取数据，假定文件包含id, node, edge三列  
data_df <- read.table(file="data_df.txt", sep=",", header=T, check.names=FALSE)  

# 检查数据结构  
print(head(data_df))  

# 计算每行之间的某种特征的欧氏距离  
coordinates <- as.matrix(data_df[, c("node", "edge")])  # 提取node和edge列作为矩阵  
dist_mat <- dist(coordinates, method = "euclidean")  # 使用欧氏距离计算  

# 聚类分析  
hc <- hclust(dist_mat, method = "complete")  # 使用complete linkage进行层次聚类  
groups <- cutree(hc, k = 2)  # 假设有两个类别，调整k值根据需要  

# 读取真实标签   
annotation_data <- read.csv("true_label.csv")  # 确保文件路径无误  

# 计算准确率  
confusion_matrix <- table(True = annotation_data$Critical_period, Predicted = as.factor(groups))  
accuracy <- sum(diag(confusion_matrix)) / sum(confusion_matrix)  
print(paste("Classification Accuracy:", round(accuracy * 100, 4), "%"))  
print(as.factor(groups))  


# 将列设置为因子并定义因子水平  
annotation_col <- data.frame(  
  Critical_period = factor(annotation_data$Critical_period, levels = c("closed", "open"), labels = c("Closed", "Open"))  
)  

# 确保行名匹配  
rownames(annotation_col) <- data_df$id  # 使用id作为行名  

# 设置颜色  
colors <- list(Critical_period =c(Closed = "#b1e4a0", Open = "#ae8bc5"))  #c(Closed="#A2C0D9", Open="#7FFF7F"))  

# 创建行注释  
annotation_row <- data.frame(Group = factor(groups, levels = c(1, 2), labels = c("Group 1", "Group 2")))  
rownames(annotation_row) <- data_df$id  # 使用id作为行名  
row_colors <- list(Group = c("Group 1" = "#98DAA7", "Group 2" = "#D3C4F7")) # 颜色映射  

pheatmap_obj1 <- pheatmap(  
  as.matrix(dist_mat),  
  angle_col = 45,  
  cellwidth = 0.5,  
  cellheight = 0.5,  
  treeheight_col = 50,  
  clustering_method = "complete",  
  clustering_distance_rows = dist_mat,   
  clustering_distance_cols = dist_mat,  
  color = colorRampPalette(c("#EC5A40", "white", "#2CADD0"))(100),  
  annotation_col = annotation_col,  
  annotation_row = annotation_row,  # 使用行注释  
  annotation_colors = c(colors, row_colors),  # 合并列和行的颜色  
  show_colnames = FALSE,  # 不显示列名  
  show_rownames = FALSE,   # 显示行名（ID）   
  display_numbers = FALSE ,  
  silent = TRUE  # 不直接绘制热图，但获取对象  
)  

# 保存最终图形  
ggsave("triangular_heatmap_rotate1111.pdf", plot = pheatmap_obj1, width = 12, height = 12)  