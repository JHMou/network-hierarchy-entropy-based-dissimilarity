import matplotlib.pyplot as plt
import seaborn as sns
import os
import warnings
from scipy import stats
import networkx as nx
import numpy as np
import pandas as pd
import random
from tqdm import tqdm
import multiprocessing as mp
import Network_hierarchy as nh

warnings.filterwarnings('ignore')
sns.set_style('white')
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
plt.rcParams['font.family'] = 'Times New Roman'

def SIR(G, infected, beta=0.1, miu=1):
    """SIR model
    Input:
        G: original network
        infected: infected nodes
        miu: recovery probability
    return:
        re: average infection scale of the node after N simulations
    """
    N = 1000
    re = 0
    
    while N > 0:
        inf = set(infected)  # initial infected node set
        R = set()  # recovered nodes
        while len(inf) != 0:
            newInf = []
            for i in inf:
                for j in G.neighbors(i):
                    k = random.uniform(0,1)
                    if (k < beta) and (j not in inf) and (j not in R):
                        newInf.append(j)
                k2 = random.uniform(0, 1)
                if k2 > miu:
                    newInf.append(i)
                else:
                    R.add(i)
            inf = set(newInf)
        re += len(R)+len(inf)
        N -= 1
    return re/1000.0

def process_node(args):
    """
    Multiprocessing for SIR simulation of a single node
    
    Parameters:
    - args: tuple containing (G, node, beta, miu)
    
    Returns:
    - node: node ID
    - sir_value: SIR value of the node
    """
    G, node, beta, miu = args
    sir = SIR(G, infected=[node], beta=beta, miu=miu)
    return (node, sir)

def SIR_dict_parallel(G, beta=0.1, miu=1, real_beta=None, a=1.5, n_jobs=None):
    """
    Use multiprocessing to calculate SIR results for all nodes in the entire network
    
    Parameters:
    - G: target network
    - beta: transmission probability
    - miu: recovery probability
    - real_beta: whether to use formula to calculate transmission probability
    - a: transmission probability adjustment coefficient
    - n_jobs: number of processes, default to CPU core count
    
    Returns:
    - SIR_dic: dictionary recording transmission capability of all nodes
    """
    # If needed, calculate beta based on network degree distribution
    if real_beta:
        dc_list = np.array(list(dict(G.degree()).values()))
        beta = a * (float(dc_list.mean()) / (float((dc_list**2).mean()) - float(dc_list.mean())))
    print('beta:', beta)
    # Modify recovery rate to vary from 0 to 1, fix infection rate to 1.2 times
    # if real_beta:
    #     dc_list = np.array(list(dict(G.degree()).values()))
    #     beta = 1.2 * (float(dc_list.mean()) / (float((dc_list**2).mean()) - float(dc_list.mean())))
    # miu=a
    # print('miu:', miu)
    # Set number of processes
    if n_jobs is None:
        n_jobs = mp.cpu_count()
    
    # Prepare node list and parameters
    node_list = list(G.nodes())
    node_args = [(G, node, beta, miu) for node in node_list]
    
    # Use process pool for parallel computation
    with mp.Pool(processes=n_jobs) as pool:
        results = list(tqdm(pool.imap(process_node, node_args), total=len(node_list)))
    
    # Convert results to dictionary
    SIR_dic = dict(results)
    return SIR_dic

def save_sir_dict(dic, path):
    """
    Store SIR results
    
    Parameters:
    - dic: sir results (dict)
    - path: target storage path
    """
    node = list(dic.keys())
    sir = list(dic.values())
    Sir = pd.DataFrame({'Node': node, 'SIR': sir})
    Sir.to_csv(path, index=False)

def SIR_betas(G, a_list, root_path, n_jobs=None):
    """
    Multiprocessing SIR computation under different beta conditions
    
    Parameters:
    - G: target network
    - a_list: list storing how many times the transmission probability is the transmission threshold
    - root_path: result save path
    - n_jobs: number of processes
    
    Returns:
    - sir_list: list of SIR results under different beta values
    """
    sir_list = []
    for inx, a in enumerate(a_list):
        # Can choose fixed beta 
        # sir_dict = SIR_dict_parallel(G, beta=a, n_jobs=n_jobs)
        sir_dict = SIR_dict_parallel(G, real_beta=True, a=a, n_jobs=n_jobs)
        
        sir_list.append(sir_dict)
        path = f"{root_path}{inx}.csv"
        save_sir_dict(sir_dict, path)
    return sir_list


def load_graph(path):
    """Load network based on edge connections
    Parameters:
        path: path where network is stored
    return:
        G: loaded network
    """
    G = nx.read_edgelist(path,create_using=nx.Graph())
    return G


def nodesRank(rank):
    SR = sorted(rank)
    re = []
    for i in SR:
        re.append(rank.index(i))
    return re
def compare_tau(G,sir_list):
    """Use Kendall correlation coefficient to compare different methods
    Parameters:
        G: target network
        dc: degree centrality
        bc: betweenness centrality
        ks: k-shell
        sir_list: SIR simulation results under different beta values
        model: trained model
        p: proportion of nodes selected for comparison
    return:
        tau_list: tau values under different beta conditions
    """
    nnd1, _= nh.node_edge_measure_Cal(G)

    degree = dict(G.degree())
    Pagerank = nx.pagerank(G)
    bc = nx.betweenness_centrality(G)
    cc = nx.closeness_centrality(G)
    EC = nx.eigenvector_centrality(G, max_iter=1000)
    K_core = nx.core_number(G)

    nnd1_rank=np.array(nodesRank([int(i) for i,j in sorted(nnd1.items(),key=lambda x:x[1],reverse=True)]),dtype=float)
    degree_rank=np.array(nodesRank([int(i) for i,j in sorted(degree.items(),key=lambda x:x[1],reverse=True)]),dtype=float)
    Pagerank_rank=np.array(nodesRank([int(i) for i,j in sorted(Pagerank.items(),key=lambda x:x[1],reverse=True)]),dtype=float)
    bc_rank=np.array(nodesRank([int(i) for i,j in sorted(bc.items(),key=lambda x:x[1],reverse=True)]),dtype=float)
    cc_rank=np.array(nodesRank([int(i) for i,j in sorted(cc.items(),key=lambda x:x[1],reverse=True)]),dtype=float)
    EC_rank = np.array(nodesRank([int(i) for i,j in sorted(EC.items(),key=lambda x:x[1],reverse=True)]),dtype=float)
    K_core_rank = np.array(nodesRank([int(i) for i,j in sorted(K_core.items(),key=lambda x:x[1],reverse=True)]),dtype=float)

    nnd1_tau_list = []
    degree_tau_list = []
    Pagerank_tau_list = []
    bc_tau_list = []
    cc_tau_list = []
    EC_tau_list = []
    K_core_tau_list = []

    for i in range(len(sir_list)):
        sir=sir_list[i]
        sir_sort = [int(i) for i,j in sorted(sir.items(),key=lambda x:x[1],reverse=True)]
        sir_rank = np.array(nodesRank(sir_sort),dtype=float)

        tau1,_ = stats.kendalltau(nnd1_rank,sir_rank)
        tau3,_ = stats.kendalltau(degree_rank,sir_rank)
        tau4,_ = stats.kendalltau(Pagerank_rank,sir_rank)
        tau7,_ = stats.kendalltau(bc_rank,sir_rank)
        tau8,_ = stats.kendalltau(cc_rank,sir_rank)
        tau9,_ = stats.kendalltau(EC_rank,sir_rank)
        tau11,_ = stats.kendalltau(K_core_rank,sir_rank)

        nnd1_tau_list.append(tau1)
        degree_tau_list.append(tau3)
        Pagerank_tau_list.append(tau4)
        bc_tau_list.append(tau7)
        cc_tau_list.append(tau8)
        EC_tau_list.append(tau9)
        K_core_tau_list.append(tau11)

    return nnd1_tau_list,degree_tau_list,Pagerank_tau_list,bc_tau_list,cc_tau_list,EC_tau_list,K_core_tau_list

if __name__ == "__main__": 
    Figeys = load_graph('./DATA/Networks/Figeys.txt')
    Faa = load_graph('./DATA/Networks/Faa.txt')
    Faa.remove_edges_from(nx.selfloop_edges(Faa))
    Figeys.remove_edges_from(nx.selfloop_edges(Figeys))
    G = Figeys
    largest_cc = max(nx.connected_components(G), key=len)  # Find the node set of the largest connected subgraph
    Figeys = nx.Graph(G.subgraph(largest_cc))
    Collaboration = load_graph('./DATA/Networks/Collaboration.txt')
    Airlines = load_graph('./DATA/Networks/Airlines.txt')
    Power = load_graph('./DATA/Networks/Power.txt')
    Proximity = load_graph('./DATA/Networks/Proximity.txt')
    Road = load_graph('./DATA/Networks/Road.txt')
    Social = load_graph('./DATA/Networks/Social.txt')
    Chemical = load_graph('./DATA/Networks/Chemical.txt')
    Dynamic = load_graph('./DATA/Networks/Dynamic.txt')
    Economic = load_graph('./DATA/Networks/Economic.txt')
    Facebook = load_graph('./DATA/Networks/Facebook.txt')
    Technology = load_graph('./DATA/Networks/Technology.txt')
    Web = load_graph('./DATA/Networks/Web.txt')

    a_list = np.arange(0.2,2.0,0.2)

    # Generate SIR labels
    Figeys_SIR = SIR_betas(Figeys,a_list,'SIR results/Figeys/Figeys_')
    Faa_SIR = SIR_betas(Faa,a_list,'SIR results/Faa/Faa_')
    Collaboration_SIR = SIR_betas(Collaboration,a_list,'SIR results/Collaboration/Collaboration_')
    Airlines_SIR = SIR_betas(Airlines,a_list,'SIR results/Airlines/Airlines_')
    Power_SIR = SIR_betas(Power,a_list,'SIR results/Power/Power_')
    Proximity_SIR = SIR_betas(Proximity,a_list,'SIR results/Proximity/Proximity_')
    Road_SIR = SIR_betas(Road,a_list,'SIR results/Road/Road_')
    Social_SIR = SIR_betas(Social,a_list,'SIR results/Social/Social_')
    Chemical_SIR = SIR_betas(Chemical,a_list,'SIR results/Chemical/Chemical_')
    Dynamic_SIR = SIR_betas(Dynamic,a_list,'SIR results/Dynamic/Dynamic_')
    Economic_SIR = SIR_betas(Economic,a_list,'SIR results/Economic/Economic_')
    Facebook_SIR = SIR_betas(Facebook,a_list,'SIR results/Facebook/Facebook_')
    Technology_SIR = SIR_betas(Technology,a_list,'SIR results/Technology/Technology_')
    Web_SIR = SIR_betas(Web,a_list,'SIR results/Web/Web_')

    Figeys_nnd1_tau,Figeys_degree_tau,Figeys_Pagerank_tau,Figeys_bc_tau,Figeys_cc_tau,Figeys_EC_tau,Figeys_K_core_tau= compare_tau(Figeys,Figeys_SIR)
    Faa_nnd1_tau,Faa_degree_tau,Faa_Pagerank_tau,Faa_bc_tau,Faa_cc_tau,Faa_EC_tau,Faa_K_core_tau= compare_tau(Faa,Faa_SIR)
    Collaboration_nnd1_tau,Collaboration_degree_tau,Collaboration_Pagerank_tau,Collaboration_bc_tau,Collaboration_cc_tau,Collaboration_EC_tau,Collaboration_K_core_tau= compare_tau(Collaboration,Collaboration_SIR)
    Airlines_nnd1_tau,Airlines_degree_tau,Airlines_Pagerank_tau,Airlines_bc_tau,Airlines_cc_tau,Airlines_EC_tau,Airlines_K_core_tau= compare_tau(Airlines,Airlines_SIR)
    Proximity_nnd1_tau,Proximity_degree_tau,Proximity_Pagerank_tau,Proximity_bc_tau,Proximity_cc_tau,Proximity_EC_tau,Proximity_K_core_tau= compare_tau(Proximity,Proximity_SIR)
    Power_nnd1_tau,Power_degree_tau,Power_Pagerank_tau,Power_bc_tau,Power_cc_tau,Power_EC_tau,Power_K_core_tau= compare_tau(Power,Power_SIR)
    Road_nnd1_tau,Road_degree_tau,Road_Pagerank_tau,Road_bc_tau,Road_cc_tau,Road_EC_tau,Road_K_core_tau= compare_tau(Road,Road_SIR)
    Social_nnd1_tau,Social_degree_tau,Social_Pagerank_tau,Social_bc_tau,Social_cc_tau,Social_EC_tau,Social_K_core_tau= compare_tau(Social,Social_SIR)
    Chemical_nnd1_tau,Chemical_degree_tau,Chemical_Pagerank_tau,Chemical_bc_tau,Chemical_cc_tau,Chemical_EC_tau,Chemical_K_core_tau= compare_tau(Chemical,Chemical_SIR)
    Dynamic_nnd1_tau,Dynamic_degree_tau,Dynamic_Pagerank_tau,Dynamic_bc_tau,Dynamic_cc_tau,Dynamic_EC_tau,Dynamic_K_core_tau= compare_tau(Dynamic,Dynamic_SIR)
    Economic_nnd1_tau,Economic_degree_tau,Economic_Pagerank_tau,Economic_bc_tau,Economic_cc_tau,Economic_EC_tau,Economic_K_core_tau= compare_tau(Economic,Economic_SIR)
    Facebook_nnd1_tau,Facebook_degree_tau,Facebook_Pagerank_tau,Facebook_bc_tau,Facebook_cc_tau,Facebook_EC_tau,Facebook_K_core_tau= compare_tau(Facebook,Facebook_SIR)
    Technology_nnd1_tau,Technology_degree_tau,Technology_Pagerank_tau,Technology_bc_tau,Technology_cc_tau,Technology_EC_tau,Technology_K_core_tau= compare_tau(Technology,Technology_SIR)
    Web_nnd1_tau,Web_degree_tau,Web_Pagerank_tau,Web_bc_tau,Web_cc_tau,Web_EC_tau,Web_K_core_tau= compare_tau(Web,Web_SIR)
    
    tau_list=[['Method','NHC','d','PR','BC','CC','EC','k_core'],
              ['FAA',Faa_nnd1_tau,Faa_degree_tau,Faa_Pagerank_tau,Faa_bc_tau,Faa_cc_tau,Faa_EC_tau,Faa_K_core_tau],
              ['Figeys',Figeys_nnd1_tau,Figeys_degree_tau,Figeys_Pagerank_tau,Figeys_bc_tau,Figeys_cc_tau,Figeys_EC_tau,Figeys_K_core_tau],
              ['Power',Power_nnd1_tau,Power_degree_tau,Power_Pagerank_tau,Power_bc_tau,Power_cc_tau,Power_EC_tau,Power_K_core_tau],
              ['Proximity',Proximity_nnd1_tau,Proximity_degree_tau,Proximity_Pagerank_tau,Proximity_bc_tau,Proximity_cc_tau,Proximity_EC_tau,Proximity_K_core_tau],
              ['Socail',Social_nnd1_tau,Social_degree_tau,Social_Pagerank_tau,Social_bc_tau,Social_cc_tau,Social_EC_tau,Social_K_core_tau],
              ['Road',Road_nnd1_tau,Road_degree_tau,Road_Pagerank_tau,Road_bc_tau,Road_cc_tau,Road_EC_tau,Road_K_core_tau],
              ['Collaboration',Collaboration_nnd1_tau,Collaboration_degree_tau,Collaboration_Pagerank_tau,Collaboration_bc_tau,Collaboration_cc_tau,Collaboration_EC_tau,Collaboration_K_core_tau],
              ['Airlines',Airlines_nnd1_tau,Airlines_degree_tau,Airlines_Pagerank_tau,Airlines_bc_tau,Airlines_cc_tau,Airlines_EC_tau,Airlines_K_core_tau],
              ['Chemical',Chemical_nnd1_tau,Chemical_degree_tau,Chemical_Pagerank_tau,Chemical_bc_tau,Chemical_cc_tau,Chemical_EC_tau,Chemical_K_core_tau],
              ['Dynamic',Dynamic_nnd1_tau,Dynamic_degree_tau,Dynamic_Pagerank_tau,Dynamic_bc_tau,Dynamic_cc_tau,Dynamic_EC_tau,Dynamic_K_core_tau],
              ['Economic',Economic_nnd1_tau,Economic_degree_tau,Economic_Pagerank_tau,Economic_bc_tau,Economic_cc_tau,Economic_EC_tau,Economic_K_core_tau],
              ['Facebook',Facebook_nnd1_tau,Facebook_degree_tau,Facebook_Pagerank_tau,Facebook_bc_tau,Facebook_cc_tau,Facebook_EC_tau,Facebook_K_core_tau],
              ['Technology',Technology_nnd1_tau,Technology_degree_tau,Technology_Pagerank_tau,Technology_bc_tau,Technology_cc_tau,Technology_EC_tau,Technology_K_core_tau],
              ['Web',Web_nnd1_tau,Web_degree_tau,Web_Pagerank_tau,Web_bc_tau,Web_cc_tau,Web_EC_tau,Web_K_core_tau]]
    data_tau=pd.DataFrame(tau_list)
    data_tau.to_csv('NHC_tau.csv',index=False,header=None)


