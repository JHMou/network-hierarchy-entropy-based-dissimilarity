# Load necessary libraries
library('ComplexHeatmap')  
library('circlize')  
library('grid')

# Read data for NHC
data <- read.table(file='./NHC_r.csv', header=TRUE, row.names=1, sep=',')  
madt <- as.matrix(data)  
madt2 <- t(madt)  # Transpose matrix

# Read data for EHC
data <- read.table(file='./EHC_r.csv', header=TRUE, row.names=1, sep=',')  
madt <- as.matrix(data)  
madt3 <- t(madt)  # Transpose matrix

# Clear previous circos layout
circos.clear()  

# Check value distribution for first heatmap
data_min <- min(madt2)  
data_max <- max(madt2)  
data_mid <- mean(madt2)  # Can set midpoint as needed

# Define color scale for first heatmap
mycol <- colorRamp2(c(data_min, 0.5, data_max), c("#3366FF", "white", "#FFFF33"))

# Check value distribution for second heatmap
data_min <- min(madt3)  
data_max <- max(madt3)  
data_mid <- mean(madt3)   
mycol1 <- colorRamp2(c(data_min, data_mid, data_max), c("#0da9ce", "white", "#e74a32"))

# Create row annotations based on grouping factor
ann_row <- data.frame(pathway = c(rep("BC", 9), rep("CC", 9), rep("EC", 9),   
                                  rep("NHC", 9), rep("PR", 9), rep("d", 9),   
                                  rep("k_core", 9)))  
ann_row <- as.matrix(ann_row)  # Convert to matrix

# Define factors for splitting
split2 <- factor(ann_row, levels = c('BC', 'CC', 'EC', 'NHC', 'PR', 'd', 'k_core'))  

# Set circular gap parameters
circos.par(gap.after = c(2, 2, 2, 2, 2, 2, 30))

# Draw first heatmap (outer ring)
circos.heatmap(madt2,   
               col = mycol,  
               split = split2,  # Split heatmap by row annotations
               rownames.col = "black",  
               rownames.side = "outside", 
               show.sector.labels = TRUE,  
               rownames.cex = 1,  # Font size
               rownames.font = 1,  # Font weight
               bg.border = "white",  # Background border color
               dend.side = "inside",  # Direction of dendrogram
               cluster = FALSE,  # Do not show clustering
               dend.track.height = 0.2,  # Adjust dendrogram height
               dend.callback = function(dend, m, si) {  
                 color_branches(dend, k = 9, col = 1:9)  # Modify dendrogram colors
               }
)  

# Add second heatmap (inner ring)
circos.heatmap(madt3,  
               col = mycol1,  
               split = split2,  
               rownames.side = "outside",  
               bg.border = "white",  # Background border color
               rownames.cex = 0.5  # Font size
)  

# Add legends
library(gridBase)  

lg_Exp1 <- Legend(title = "Exp1", col_fun = mycol, direction = "vertical")
lg_Exp2 <- Legend(title = "Exp2", col_fun = mycol1, direction = "vertical")

circle_size <- unit(0.07, "snpc")
h <- dev.size()

lgd_list <- packLegend(lg_Exp1, lg_Exp2, max_height = unit(2 * h, "inch"))
draw(lgd_list, x = circle_size, just = "left")

# Add column names for first heatmap
circos.track(track.index = get.current.track.index(), panel.fun = function(x, y) {
  if(CELL_META$sector.numeric.index == 7) {  # The last sector
    cn <- colnames(madt2)
    n <- length(cn)
    circos.text(rep(CELL_META$cell.xlim[2], n) + convert_x(1, "mm"),  # x coordinate
                (1:n) * 1 + 0,  # Adjust y coordinate: row spacing + distance from center
                cn, cex = 0.6, adj = c(0, 1), facing = "inside")
  }
}, bg.border = NA)

# Add column names for second heatmap
circos.track(track.index = get.current.track.index(), panel.fun = function(x, y) {
  if(CELL_META$sector.numeric.index == 7) {  # The last sector
    cn <- colnames(madt2)
    n <- length(cn)
    circos.text(rep(CELL_META$cell.xlim[2], n) + convert_x(1, "mm"),  # x coordinate
                (1:n) * 2 + 12,  # Adjust y coordinate: row spacing + distance from center
                cn, cex = 0.6, adj = c(0, 1), facing = "inside")
  }
}, bg.border = NA)

# Clear layout
circos.clear()