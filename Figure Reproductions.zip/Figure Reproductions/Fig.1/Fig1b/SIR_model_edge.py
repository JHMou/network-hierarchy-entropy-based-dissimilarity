
from scipy import stats
import networkx as nx
import numpy as np
import pandas as pd
import random
from tqdm import tqdm
import multiprocessing as mp
import Network_hierarchy as nh


def load_graph(path):
    """Read a network based on edge list
    Parameters:
        path: path where the network is stored
    return:
        G: the loaded network
    """
    G = nx.read_edgelist(path, create_using=nx.Graph())
    return G

def SIR(G, infected, beta=0.1, miu=1):
    """SIR model
    Input:
        G: original network
        infected: infected nodes
        miu: recovery probability
    return:
        re: average infection size of the node after N simulations
    """
    N = 1000
    re = 0

    while N > 0:
        inf = set(infected)  # initial set of infected nodes
        R = set()  # recovered nodes
        while len(inf) != 0:
            newInf = []
            for i in inf:
                for j in G.neighbors(i):
                    k = random.uniform(0, 1)
                    if (k < beta) and (j not in inf) and (j not in R):
                        newInf.append(j)
                k2 = random.uniform(0, 1)
                if k2 > miu:
                    newInf.append(i)
                else:
                    R.add(i)
            inf = set(newInf)
        re += len(R) + len(inf)
        N -= 1
    return re / 1000.0


def process_edge(args):
    """
    Multiprocessing SIR simulation for a single edge

    Parameters:
    - args: tuple containing (G, edge, beta, miu)

    Returns:
    - edge: the edge
    - sir_value: the SIR value for this edge
    """
    G, edge, beta, miu = args
    sir = SIR(G, infected=edge, beta=beta, miu=miu)
    return (edge, sir)


def SIR_dict(G, beta=0.1, miu=1, real_beta=None, a=1.5, n_jobs=None):
    """Obtain SIR results for all nodes in the entire network (multiprocessing version)
    Input:
        G: target network
        beta: transmission probability
        miu: recovery probability
        real_beta: compute transmission probability using a formula
        a: adjustment coefficient for transmission probability
        n_jobs: number of processes, defaults to CPU core count
    return:
        SIR_dic: dictionary recording the spreading capability of all nodes
    """
    edge_list = list(G.edges())

    if real_beta:
        dc_list = np.array(list(dict(G.degree()).values()))
        beta = a * (float(dc_list.mean()) / (float((dc_list ** 2).mean()) - float(dc_list.mean())))
    print('beta:', beta)

    # Set the number of processes
    if n_jobs is None:
        n_jobs = mp.cpu_count()

    # Prepare edge list and parameters
    edge_args = [(G, edge, beta, miu) for edge in edge_list]

    # Parallel computation using a process pool
    with mp.Pool(processes=n_jobs) as pool:
        results = list(tqdm(pool.imap(process_edge, edge_args), total=len(edge_list)))

    # Convert results to a dictionary
    SIR_dic = dict(results)
    return SIR_dic


def save_sir_dict(dic, path):
    """Store SIR results
    Parameters:
        dic: sir results (dict)
        path: target save path
    """
    node = list(dic.keys())
    sir = list(dic.values())
    Sir = pd.DataFrame({'Node': node, 'SIR': sir})
    Sir.to_csv(path, index=False)


def SIR_betas(G, a_list, root_path, n_jobs=None):
    """SIR under different beta values (multiprocessing version)
    Parameters:
        G: target network
        a_list: list storing how many times the transmission probability is of the transmission threshold
        root_path: path to save results
        n_jobs: number of processes
    return:
        sir_list: list of SIR results under different beta values
    """
    sir_list = []
    for inx, a in enumerate(a_list):
        sir_dict = SIR_dict(G, real_beta=True, a=a, n_jobs=n_jobs)
        sir_list.append(sir_dict)
        path = root_path + str(inx) + '.csv'
        save_sir_dict(sir_dict, path)
    return sir_list

def nodesRank(rank):
    SR = sorted(rank)
    re = []
    for i in SR:
        re.append(rank.index(i))
    return re


def compare_tau_edge(G, sir_list):
    """Compare different methods using Kendall correlation coefficient
    Parameters:
        G: target network
        dc: degree centrality
        bc: betweenness centrality
        ks: k-shell
        sir_list: SIR simulation results under different beta values
        model: trained model
        p: proportion of nodes selected for comparison
    return:
        tau_list: tau values under different beta conditions
    """
    betweenness = nx.edge_betweenness_centrality(G)
    degree_product = nh.calculate_dp(G)
    overlap = nh.calculate_overlap_edge(G)
    CN = nh.calculate_CN(G)
    bridgeness = nh.calculate_bridgeness(G)
    diffusion_importance = nh.calculate_diffusion_importance(G)
    _, NND_edge = nh.node_edge_measure_Cal(G)

    NND_edge_rank = np.array(nodesRank([i for i, j in sorted(NND_edge.items(), key=lambda x: x[1], reverse=False)]),
                             dtype=float)
    betweenness_rank = np.array(
        nodesRank([i for i, j in sorted(betweenness.items(), key=lambda x: x[1], reverse=True)]), dtype=float)
    degree_product_rank = np.array(
        nodesRank([i for i, j in sorted(degree_product.items(), key=lambda x: x[1], reverse=True)]), dtype=float)
    overlap_rank = np.array(nodesRank([i for i, j in sorted(overlap.items(), key=lambda x: x[1], reverse=True)]),
                            dtype=float)
    CN_rank = np.array(nodesRank([i for i, j in sorted(CN.items(), key=lambda x: x[1], reverse=True)]), dtype=float)
    bridgeness_rank = np.array(
        nodesRank([i for i, j in sorted(bridgeness.items(), key=lambda x: x[1], reverse=True)]), dtype=float)
    diffusion_importance_rank = np.array(
        nodesRank([i for i, j in sorted(diffusion_importance.items(), key=lambda x: x[1], reverse=True)]),
        dtype=float)

    NND_edge_tau_list = []
    betweenness_tau_list = []
    degree_product_tau_list = []
    overlap_tau_list = []
    CN_tau_list = []
    bridgeness_tau_list = []
    diffusion_importance_tau_list = []

    for i in range(len(sir_list)):
        sir = sir_list[i]
        sir_sort = [i for i, j in sorted(sir.items(), key=lambda x: x[1], reverse=True)]
        sir_rank = np.array(nodesRank(sir_sort), dtype=float)
        tau1, _ = stats.kendalltau(NND_edge_rank, sir_rank)
        tau2, _ = stats.kendalltau(betweenness_rank, sir_rank)
        tau3, _ = stats.kendalltau(degree_product_rank, sir_rank)
        tau4, _ = stats.kendalltau(overlap_rank, sir_rank)
        tau5, _ = stats.kendalltau(CN_rank, sir_rank)
        tau6, _ = stats.kendalltau(bridgeness_rank, sir_rank)
        tau7, _ = stats.kendalltau(diffusion_importance_rank, sir_rank)

        NND_edge_tau_list.append(tau1)
        betweenness_tau_list.append(tau2)
        degree_product_tau_list.append(tau3)
        overlap_tau_list.append(tau4)
        CN_tau_list.append(tau5)
        bridgeness_tau_list.append(tau6)
        diffusion_importance_tau_list.append(tau7)

    return NND_edge_tau_list, betweenness_tau_list, degree_product_tau_list, overlap_tau_list, CN_tau_list, bridgeness_tau_list, diffusion_importance_tau_list

if __name__ == "__main__":
    # load data
    Figeys = load_graph('./DATA/Networks/Figeys.txt')
    Faa = load_graph('./DATA/Networks/Faa.txt')
    Faa.remove_edges_from(nx.selfloop_edges(Faa))
    Figeys.remove_edges_from(nx.selfloop_edges(Figeys))
    G = Figeys
    largest_cc = max(nx.connected_components(G), key=len)  # Find the node set of the largest connected subgraph
    Figeys = nx.Graph(G.subgraph(largest_cc))
    Collaboration = load_graph('./DATA/Networks/Collaboration.txt')
    Airlines = load_graph('./DATA/Networks/Airlines.txt')
    Power = load_graph('./DATA/Networks/Power.txt')
    Proximity = load_graph('./DATA/Networks/Proximity.txt')
    Road = load_graph('./DATA/Networks/Road.txt')
    Social = load_graph('./DATA/Networks/Social.txt')
    Chemical = load_graph('./DATA/Networks/Chemical.txt')
    Dynamic = load_graph('./DATA/Networks/Dynamic.txt')
    Economic = load_graph('./DATA/Networks/Economic.txt')
    Facebook = load_graph('./DATA/Networks/Facebook.txt')
    Technology = load_graph('./DATA/Networks/Technology.txt')
    Web = load_graph('./DATA/Networks/Web.txt')



    a_list = np.arange(1.2, 2.0, 0.2)
    # # regenerate SIR labels
    Faa_SIR = SIR_betas(Faa, a_list, 'SIR results-edge/Faa/Faa_')
    Figeys_SIR = SIR_betas(Figeys, a_list, 'SIR results-edge/Figeys/Figeys_')
    Power_SIR = SIR_betas(Power, a_list, 'SIR results-edge/Power/Power_')
    Collaboration_SIR = SIR_betas(Collaboration, a_list, 'SIR results-edge/Collaboration/Collaboration_')
    Airlines_SIR = SIR_betas(Airlines, a_list, 'SIR results-edge/Airlines/Airlines_')
    Proximity_SIR = SIR_betas(Proximity, a_list, 'SIR results-edge/Proximity/Proximity_')
    Road_SIR = SIR_betas(Road, a_list, 'SIR results-edge/Road/Road_')
    Social_SIR = SIR_betas(Social, a_list, 'SIR results-edge/Social/Social_')
    Chemical_SIR = SIR_betas(Chemical, a_list, 'SIR results-edge/Chemical/Chemical_')
    Dynamic_SIR = SIR_betas(Dynamic, a_list, 'SIR results-edge/Dynamic/Dynamic_')
    Economic_SIR = SIR_betas(Economic, a_list, 'SIR results-edge/Economic/Economic_')
    Facebook_SIR = SIR_betas(Facebook, a_list, 'SIR results-edge/Facebook/Facebook_')
    Technology_SIR = SIR_betas(Technology, a_list, 'SIR results-edge/Technology/Technology_')
    Web_SIR = SIR_betas(Web, a_list, 'SIR results-edge/Web/Web_')



    Faa_NND_edge_tau, Faa_betweenness_tau, Faa_degree_product_tau, Faa_overlap_tau, Faa_CN_tau, Faa_bridgeness_tau, Faa_diffusion_importance_tau = compare_tau_edge(Faa, Faa_SIR)
    Figeys_NND_edge_tau, Figeys_betweenness_tau, Figeys_degree_product_tau, Figeys_overlap_tau, Figeys_CN_tau, Figeys_bridgeness_tau, Figeys_diffusion_importance_tau = compare_tau_edge(Figeys, Figeys_SIR)
    Power_NND_edge_tau, Power_betweenness_tau, Power_degree_product_tau, Power_overlap_tau, Power_CN_tau, Power_bridgeness_tau, Power_diffusion_importance_tau = compare_tau_edge(Power, Power_SIR)
    Proximity_NND_edge_tau, Proximity_betweenness_tau, Proximity_degree_product_tau, Proximity_overlap_tau, Proximity_CN_tau, Proximity_bridgeness_tau, Proximity_diffusion_importance_tau = compare_tau_edge(Proximity, Proximity_SIR)
    Social_NND_edge_tau, Social_betweenness_tau, Social_degree_product_tau, Social_overlap_tau, Social_CN_tau, Social_bridgeness_tau, Social_diffusion_importance_tau = compare_tau_edge(Social, Social_SIR)
    Road_NND_edge_tau, Road_betweenness_tau, Road_degree_product_tau, Road_overlap_tau, Road_CN_tau, Road_bridgeness_tau, Road_diffusion_importance_tau = compare_tau_edge(Road, Road_SIR)
    Collaboration_NND_edge_tau, Collaboration_betweenness_tau, Collaboration_degree_product_tau, Collaboration_overlap_tau, Collaboration_CN_tau, Collaboration_bridgeness_tau, Collaboration_diffusion_importance_tau = compare_tau_edge(Collaboration, Collaboration_SIR)
    Airlines_NND_edge_tau, Airlines_betweenness_tau, Airlines_degree_product_tau, Airlines_overlap_tau, Airlines_CN_tau, Airlines_bridgeness_tau, Airlines_diffusion_importance_tau = compare_tau_edge(Airlines, Airlines_SIR)
    Chemical_NND_edge_tau, Chemical_betweenness_tau, Chemical_degree_product_tau,Chemical_overlap_tau, Chemical_CN_tau, Chemical_bridgeness_tau, Chemical_diffusion_importance_tau= compare_tau_edge(Chemical, Chemical_SIR)
    Dynamic_NND_edge_tau, Dynamic_betweenness_tau, Dynamic_degree_product_tau,Dynamic_overlap_tau, Dynamic_CN_tau, Dynamic_bridgeness_tau, Dynamic_diffusion_importance_tau= compare_tau_edge(Dynamic, Dynamic_SIR)
    Economic_NND_edge_tau, Economic_betweenness_tau, Economic_degree_product_tau,Economic_overlap_tau, Economic_CN_tau, Economic_bridgeness_tau, Economic_diffusion_importance_tau= compare_tau_edge(Economic, Economic_SIR)
    Facebook_NND_edge_tau, Facebook_betweenness_tau, Facebook_degree_product_tau, Facebook_overlap_tau, Facebook_CN_tau, Facebook_bridgeness_tau, Facebook_diffusion_importance_tau= compare_tau_edge(Facebook, Facebook_SIR)
    Technology_NND_edge_tau, Technology_betweenness_tau, Technology_degree_product_tau, Technology_overlap_tau, Technology_CN_tau, Technology_bridgeness_tau, Technology_diffusion_importance_tau= compare_tau_edge(Technology, Technology_SIR)
    Web_NND_edge_tau, Web_betweenness_tau, Web_degree_product_tau, Web_overlap_tau, Web_CN_tau, Web_bridgeness_tau, Web_diffusion_importance_tau= compare_tau_edge(Web, Web_SIR)

    edge_tau = [['Method', 'EHC', 'BC', 'DP', 'TO', 'CN', 'BRI', 'DI'],

                ['Faa', Faa_NND_edge_tau, Faa_betweenness_tau, Faa_degree_product_tau, Faa_overlap_tau, Faa_CN_tau, Faa_bridgeness_tau, Faa_diffusion_importance_tau],
                ['Figeys', Figeys_NND_edge_tau, Figeys_betweenness_tau, Figeys_degree_product_tau, Figeys_overlap_tau, Figeys_CN_tau, Figeys_bridgeness_tau, Figeys_diffusion_importance_tau],
                ['Power', Power_NND_edge_tau, Power_betweenness_tau, Power_degree_product_tau, Power_overlap_tau, Power_CN_tau, Power_bridgeness_tau, Power_diffusion_importance_tau],
                ['Proximity', Proximity_NND_edge_tau, Proximity_betweenness_tau, Proximity_degree_product_tau, Proximity_overlap_tau, Proximity_CN_tau, Proximity_bridgeness_tau, Proximity_diffusion_importance_tau],
                ['Social', Social_NND_edge_tau, Social_betweenness_tau, Social_degree_product_tau, Social_overlap_tau, Social_CN_tau, Social_bridgeness_tau, Social_diffusion_importance_tau],
                ['Road', Road_NND_edge_tau, Road_betweenness_tau, Road_degree_product_tau, Road_overlap_tau, Road_CN_tau, Road_bridgeness_tau, Road_diffusion_importance_tau],
                ['Collaboraton', Collaboration_NND_edge_tau, Collaboration_betweenness_tau, Collaboration_degree_product_tau, Collaboration_overlap_tau, Collaboration_CN_tau, Collaboration_bridgeness_tau, Collaboration_diffusion_importance_tau],
                ['Airlines', Airlines_NND_edge_tau, Airlines_betweenness_tau, Airlines_degree_product_tau, Airlines_overlap_tau, Airlines_CN_tau, Airlines_bridgeness_tau, Airlines_diffusion_importance_tau],
                ['Chemical', Chemical_NND_edge_tau, Chemical_betweenness_tau, Chemical_degree_product_tau,
                 Chemical_overlap_tau, Chemical_CN_tau, Chemical_bridgeness_tau, Chemical_diffusion_importance_tau],
                ['Dynamic', Dynamic_NND_edge_tau, Dynamic_betweenness_tau, Dynamic_degree_product_tau,
                 Dynamic_overlap_tau, Dynamic_CN_tau, Dynamic_bridgeness_tau, Dynamic_diffusion_importance_tau],
                ['Economic', Economic_NND_edge_tau, Economic_betweenness_tau, Economic_degree_product_tau,
                 Economic_overlap_tau, Economic_CN_tau, Economic_bridgeness_tau, Economic_diffusion_importance_tau],
                ['Facebook', Facebook_NND_edge_tau, Facebook_betweenness_tau, Facebook_degree_product_tau,
                 Facebook_overlap_tau, Facebook_CN_tau, Facebook_bridgeness_tau, Facebook_diffusion_importance_tau],
                ['Technology', Technology_NND_edge_tau, Technology_betweenness_tau, Technology_degree_product_tau,
                 Technology_overlap_tau, Technology_CN_tau, Technology_bridgeness_tau,
                 Technology_diffusion_importance_tau],
                ['Web', Web_NND_edge_tau, Web_betweenness_tau, Web_degree_product_tau, Web_overlap_tau, Web_CN_tau,
                 Web_bridgeness_tau, Web_diffusion_importance_tau]]

    data_edge_tau = pd.DataFrame(edge_tau)
    data_edge_tau.to_csv('EHC_new.csv', index=False, header=None)