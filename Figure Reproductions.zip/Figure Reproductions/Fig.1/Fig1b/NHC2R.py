import pandas as pd

def draw_bubble_plot():
    file='./EHC_tau.csv'
    data=pd.read_csv(file)
    print(data.head(5))
    method_list=[]
    beta_list=[]
    value_list=[]
    # type1=['NHC','d','PR','BC','CC','EC','k_core']#for node
    type1=['EHC','BC','DP','TO','CN','BRI','DI']#for edge
    type_list=[]
    import ast
    for i in range(data.shape[0]):
        for j in range(1,data.shape[1]):
            if type1[j-1]=='EHC' or type1[j-1]=='CN':
                float_list1 = ast.literal_eval(data.iloc[i, j])
                float_list=[-x for x in float_list1]
            else:
                float_list = ast.literal_eval(data.iloc[i, j])
            type_list.extend([type1[j-1]]*9)
            method_list.extend([data.loc[i, 'Method']]*9)
            value_list.extend(float_list)
            beta_list.extend(['1','2','3','4','5','6','7','8','9'])

    data1={'Network':method_list,
           'method': [a + b for a, b in zip(type_list, beta_list)],
           'value':value_list
    }
    df = pd.DataFrame(data1)
    df1=df.pivot(index='Network', columns='method', values='value')
    df1.to_csv('./EHC_r.csv')



if __name__ == '__main__':
    #for Fig1(b)
    draw_bubble_plot()
























