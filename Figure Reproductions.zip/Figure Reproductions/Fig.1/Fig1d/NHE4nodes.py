
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import Network_hierarchy as nh

def cross_entropy_analysis():
    file='./Networks/Faa.txt'
    G1=nh.real_networks(file)
    node_measure1, edge_measure1= nh.NND_GAP_node_edge(G1)#Tk for node and Tij for edge
    print(node_measure1)
    print(edge_measure1)
    for node, value in node_measure1.items():
        G1.nodes[node]['measure'] = value
    for edge, value in edge_measure1.items():
        G1.edges[edge]['measure'] = value
    node_colors = [G1.nodes[node]['measure'] for node in G1.nodes()]
    edge_colors = [G1.edges[edge]['measure'] for edge in G1.edges()]
    node_colors = (node_colors - np.min(node_colors)) / (np.max(node_colors) - np.min(node_colors))
    edge_colors = (edge_colors - np.min(edge_colors)) / (np.max(edge_colors) - np.min(edge_colors))
    plt.figure(figsize=(20, 10))
    pos = nx.kamada_kawai_layout(G1)  
    nx.draw_networkx_edges(G1, pos, edge_color=edge_colors, width=2, edge_cmap=plt.cm.Reds)
    nx.draw_networkx_nodes(G1, pos, node_color=node_colors, node_size=20, cmap=plt.cm.Blues)
    plt.title('Tree Visualization with Node and Edge Attributes')
    plt.colorbar(plt.cm.ScalarMappable(cmap=plt.cm.Blues), label='Node Measure')
    plt.colorbar(plt.cm.ScalarMappable(cmap=plt.cm.Reds), label='Edge Measure')
    plt.axis('off')  
    plt.show()

    with open('./Faa_node_measures.csv', 'w', encoding='utf-8') as f:
        f.write("Node,Measure\n")
        for node, measure in node_measure1.items():
            f.write(f"{node},{measure:.6f}\n")

    with open('./Faa_edge_measures.csv', 'w', encoding='utf-8') as f:
        f.write("Source,Target,Measure\n")
        for edge, measure in edge_measure1.items():
            f.write(f"{edge[0]},{edge[1]},{measure:.6f}\n")

if __name__ == '__main__':
    cross_entropy_analysis()













