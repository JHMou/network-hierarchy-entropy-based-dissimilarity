
import os
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import Network_hierarchy as nh
import pandas as pd
from multiprocessing import Pool
from tqdm import tqdm
import random
from matplotlib import rcParams
import pickle
import seaborn as sns
rcParams['font.sans-serif'] = ['Arial'] 
rcParams['axes.unicode_minus'] = False  


def SIR(G,sir_length, infected, beta, miu=1):
    N =100
    R_N_Sequence=[]
    while N > 0:
        inf = set(infected)  
        R = set() 
        icount=0
        R_sequence=[]
        while icount<sir_length:
            newInf = []
            for i in inf:
                for j in G.neighbors(i):
                    k = random.uniform(0, 1)
                    if (k < beta) and (j not in inf) and (j not in R):
                        newInf.append(j)
                k2 = random.uniform(0, 1)
                if k2 > miu:
                    newInf.append(i)
                else:
                    R.add(i)
            inf = set(newInf)
            R_sequence.append(len(inf)+len(R))
            icount+=1
        R_N_Sequence.append(R_sequence)
        N -= 1
    R_means = np.mean(np.array(R_N_Sequence), axis=0)

    return R_means

def cross_entropy_analysis_single():

    netname='Faa'
    file1 = f'./Networks/{netname}.txt'
    g=nh.real_networks(file1)
    R_dict={}
    sir_length=200
    ibeta=0.1
    for iedge in tqdm(list(g.edges())):
        inode=iedge[0]
        jnode=iedge[1]
        sir_double = list(SIR(g, sir_length, infected=[inode,jnode], beta=ibeta))
        R_dict[iedge]=[sir_double]
    R_node_dict={}
    for node1 in tqdm(list(g.nodes())):
        sir_node = list(SIR(g, sir_length, infected=[node1], beta=ibeta))
        R_node_dict[node1]=[sir_node]
    with open(f'./cross_entropy_analysis_{netname}_sir.pkl', 'wb') as file: 
        pickle.dump([R_dict,R_node_dict], file)
import math
from scipy.special import kl_div


def draw_cross_entropy():
    netname = 'Faa'
    file1 = f'./Networks/{netname}.txt'
    g = nh.real_networks(file1)
    file_path=f'./cross_entropy_analysis_{netname}_sir.pkl'
    with open(file_path, 'rb') as file:
        edge1 = pickle.load(file)
    R_edge_dict=edge1[0]
    R_node_dict=edge1[1]
    sir_edge_dict={}
    sir_node_dict={}
    for iedge in list(g.edges()):
        inode=iedge[0]
        jnode=iedge[1]
        narray=np.array([R_node_dict[inode][0],R_node_dict[jnode][0]])
        sir_node_avg = np.mean(np.array(narray), axis=0)
        edge_cross1=R_edge_dict[iedge][0]
        edge_cross1=[edge_cross1[i9] for i9 in range(len(edge_cross1))]
        sir_node_avg=[sir_node_avg[i9] for i9 in range(len(sir_node_avg))]

        sir_edge_gap=abs(edge_cross1[-1]-sir_node_avg[-1])
        sir_edge_dict[iedge]=sir_edge_gap
    for inode in list(g.nodes()):
        ineighbor=g[inode]
        narray=[]
        for neig1 in ineighbor:
            if (inode,neig1) in list(g.edges()):
                narray.append(R_edge_dict[(inode,neig1)][0])
            else:
                narray.append(R_edge_dict[(neig1,inode)][0])
        narray1 = np.array(narray)
        sir_edge_avg = np.mean(np.array(narray1), axis=0)
        node_cross1 = [R_node_dict[inode][0][i9]  for i9 in range(len(R_node_dict[inode][0]))]
        sir_edge_avg = [sir_edge_avg[i9]  for i9 in range(len(sir_edge_avg))]

        sir_node_gap =abs(node_cross1[-1]- sir_edge_avg[-1])
        sir_node_dict[inode] = sir_node_gap

    file = f'./Networks/{netname}.txt'
    G1 = nh.real_networks(file)
    node_measure1, edge_measure1 = nh.NND_GAP_node_edge(G1)
    node_measure_list=[]
    edge_measure_list=[]
    sir_node_gap_list=[]
    sir_edge_gap_list=[]
    for node, value in node_measure1.items():
        G1.nodes[node]['measure'] = value
        node_measure_list.append(value)
        sir_node_gap_list.append(sir_node_dict[node])
    for edge, value in edge_measure1.items():
        G1.edges[edge]['measure'] = value
        edge_measure_list.append(value)
        sir_edge_gap_list.append(sir_edge_dict[edge])
    print(max(node_measure_list))
    print(min(node_measure_list))
    print(max(edge_measure_list))
    print(min(edge_measure_list))


    node_colors = [G1.nodes[node]['measure'] for node in G1.nodes()]
    edge_colors = [G1.edges[edge]['measure'] for edge in G1.edges()]
    node_colors = (node_colors - np.min(node_colors)) / (np.max(node_colors) - np.min(node_colors))
    edge_colors = (edge_colors - np.min(edge_colors)) / (np.max(edge_colors) - np.min(edge_colors))
    plt.figure(figsize=(20,10))
    pos = nx.spring_layout(G1)  
    nx.draw_networkx_edges(G1, pos, edge_color=edge_colors, width=2, edge_cmap=plt.cm.Reds)
    nx.draw_networkx_nodes(G1, pos, node_color=node_colors, node_size=20, cmap=plt.cm.Blues)
    nodes_data = []
    for node in G1.nodes(data=True):
        node_id = node[0]
        attributes = node[1]
        attributes['node_id'] = node_id
        nodes_data.append(attributes)
    nodes_df = pd.DataFrame(nodes_data)
    nodes_df = nodes_df[['node_id'] + [col for col in nodes_df.columns if col != 'node_id']]

    edges_data = []
    for edge in G1.edges(data=True):
        edge_data = {
            'source': edge[0], 
            'target': edge[1], 
            **edge[2] 
        }
        edges_data.append(edge_data)
    edges_df = pd.DataFrame(edges_data)
    edges_df = edges_df[['source', 'target'] + [col for col in edges_df.columns if col not in ['source', 'target']]]


    plt.title('Tree Visualization with Node and Edge Attributes')
    plt.colorbar(plt.cm.ScalarMappable(cmap=plt.cm.Blues), label='Node Measure')
    plt.colorbar(plt.cm.ScalarMappable(cmap=plt.cm.Reds), label='Edge Measure')
    plt.axis('off')  
    plt.savefig(f'./{netname}_cross_entropy.pdf',dpi=700)
    plt.show()
    
	
    plt.figure()
    dict_node={'node_measure':node_measure_list,
               'node_gap':sir_node_gap_list}
    df_node=pd.DataFrame(dict_node)
    sns.kdeplot(
        data=df_node, x="node_measure", y="node_gap", fill=True,color='red',
    )
    #plt.scatter(node_measure_list, sir_node_gap_list,color='green')
    plt.title('node')
    plt.savefig(f'./{netname}_node_cross_entropy.pdf', dpi=700)
    plt.show()
    plt.figure()
    dict_edge = {'edge_measure': edge_measure_list,
                 'edge_gap': sir_edge_gap_list}
    df_edge= pd.DataFrame(dict_edge)
    sns.kdeplot(
        data=df_edge, x="edge_measure", y="edge_gap", fill=True,
    )
    #plt.scatter(edge_measure_list,sir_edge_gap_list,color='yellow')
    plt.title('edge')
    plt.savefig(f'./{netname}_edge_cross_entropy.pdf', dpi=700)
    plt.show()


    iedge1=list(g.edges())[700]
    inode = iedge1[0]
    jnode = iedge1[1]
    narray = np.array([R_node_dict[inode][0], R_node_dict[jnode][0]])
    sir_node_avg = np.mean(np.array(narray), axis=0)
    edge_cross1 = R_edge_dict[iedge1][0]
    plt.figure()
    plt.plot(list(range(20)),sir_node_avg[0:20],label='avg',color='blue')
    plt.plot(list(range(20)), edge_cross1[0:20],label='edge',color='red')
    plt.plot(list(range(20)), R_node_dict[inode][0][0:20],label='inode',color='gray', alpha=0.7)
    plt.plot(list(range(20)), R_node_dict[jnode][0][0:20],label='jnode',color='gray', alpha=0.7)
    plt.legend()
    plt.savefig(f'./{netname}_edge_cross_entropy_example.pdf', dpi=700)
    plt.show()
    
	
    inode1 = list(g.nodes())[50]
    inei1=g[inode1]
    print(len(inei1))
    narray11=[]
    plt.figure()
    for i11 in inei1:
        if (inode1, i11) in list(g.edges()):
            narray11.append(R_edge_dict[(inode1,i11)][0])
            plt.plot(list(range(20)), R_edge_dict[(inode1,i11)][0][0:20], label=i11,color='gray', alpha=0.7)
        else:
            narray11.append(R_edge_dict[(i11,inode1)][0])
            plt.plot(list(range(20)), R_edge_dict[(i11,inode1)][0][0:20], label=i11,color='gray', alpha=0.7)
    sir_edge_avg = np.mean(np.array(narray11), axis=0)
    node_cross1 = R_node_dict[inode1][0]
    plt.plot(list(range(20)), sir_edge_avg[0:20], label='avg',color='blue')
    plt.plot(list(range(20)), node_cross1[0:20], label='node',color='red')
    plt.legend()
    plt.savefig(f'./{netname}_node_cross_entropy_example.pdf', dpi=700)
    plt.show()





if __name__ == "__main__":
    cross_entropy_analysis_single()
    draw_cross_entropy()






