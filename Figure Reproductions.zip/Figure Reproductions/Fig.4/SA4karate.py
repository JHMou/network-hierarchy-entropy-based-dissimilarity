import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import Network_hierarchy as nh
import pandas as pd
from matplotlib import rcParams
import tqdm
import math
rcParams['font.sans-serif'] = ['Arial']
rcParams['axes.unicode_minus'] = False
from collections import Counter
from dotmotif import Motif, GrandIsoExecutor
import os
from networkx import isomorphism
from collections import defaultdict
import pickle
import seaborn as sns

def motif(G):
    """
    Counts various network motifs in the given graph.

    Input: G - networkx graph
    Output: List containing counts of 8 different network motifs
    Function: Uses dotmotif to find and count specific subgraph patterns
    """
    E = GrandIsoExecutor(graph=G)  # Create search engine
    motif1 = Motif("""
    A -> B
    B -> C
    """, ignore_direction=True, exclude_automorphisms=True)
    results1 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        B -> C
        C -> A
        """, ignore_direction=True, exclude_automorphisms=True)
    results2 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        B -> C
        B -> D
        """, ignore_direction=True, exclude_automorphisms=True)
    results3 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        B -> C
        C -> D
        """, ignore_direction=True, exclude_automorphisms=True)
    results4 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        A -> C
        B -> C
        C -> D
        """, ignore_direction=True, exclude_automorphisms=True)
    results5 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        B -> C
        C -> D
        D -> A
        """, ignore_direction=True, exclude_automorphisms=True)
    results6 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        A -> C
        B -> C
        C -> D
        D -> A        
        """, ignore_direction=True, exclude_automorphisms=True)
    results7 = E.find(motif1)

    motif1 = Motif("""
        A -> B
        A -> C
        B -> C
        B -> D
        C -> D
        D -> A 
        """, ignore_direction=True, exclude_automorphisms=True)
    results8 = E.find(motif1)

    return [len(results1), len(results2), len(results3), len(results4), len(results5), len(results6), len(results7),
            len(results8)]
def number_shortest_path(G2):
    """
    Analyzes shortest path diversity by counting multiple shortest paths between node pairs.

    Input: G2 - networkx graph
    Output: Dictionary with path count distribution
    Function: For each node pair, counts number of shortest paths and aggregates distribution
    """
    if nx.is_connected(G2):
        path_count_distribution2 = Counter()
        for source in G2.nodes:
            for target in G2.nodes:
                if source != target:
                    # Get all shortest paths
                    paths = list(nx.all_shortest_paths(G2, source=source, target=target))
                    # Count number of shortest paths
                    path_count_distribution2[len(paths)] += 1
        sorted_by_key2 = dict(sorted(path_count_distribution2.items()))
        return sorted_by_key2
    else:
        connected_components = list(nx.connected_components(G2))
        path_count_distribution2 = Counter()
        for iconnected in connected_components:  # Calculate values for each connected component
            component_graph = G2.subgraph(iconnected).copy()
            for source in component_graph.nodes:
                for target in component_graph.nodes:
                    if source != target:
                        paths = list(nx.all_shortest_paths(component_graph, source=source, target=target))
                        path_count_distribution2[len(paths)] += 1
        sorted_by_key2 = dict(sorted(path_count_distribution2.items()))
        return sorted_by_key2
def filiter_networks_k():
    """
    Filters random networks by k-value classification and removes isomorphic networks.

    Input: None (reads network files from specified directories)
    Output: Returns motif counts and shortest path distributions for original and filtered networks
    Function: 
        - Loads original karate club network
        - Filters random networks by BFS layer similarity
        - Removes isomorphic networks
        - Classifies networks by maximum matching k-value
    """
    network_name = 'karate'
    file = f'./DATA/{network_name}.txt'
    G = nh.real_networks(file)
    matrix = nh.BFS_distribution_G(G)
    sorted_indices = np.lexsort(np.rot90(np.array(matrix)))
    BFS_num_sorted_original = np.array(matrix)[sorted_indices]
    k = 6
    ##motif
    motif_G_original = motif(G)
    multi_paths_original = number_shortest_path(G)
    folder_path = f'./Fig.4/{network_name}'
    total_file_list = os.listdir(folder_path)

    G_list = []
    for i in range(2, k, 1):

        filtered_list = [item for item in total_file_list if f'L{i}' in item]
        for filename in filtered_list:
            if filename.endswith('.txt'):
                file_path = os.path.join(folder_path, filename)
                g = nh.real_networks(file_path)
                if (not nx.is_isomorphic(G, g)):
                    G_list.append(g)
    ###Remove isomorphic networks from randomized networks
    unique_graphs = []  # Store graphs without isomorphic relationships
    for g1 in G_list:
        if not any(isomorphism.GraphMatcher(g1, U).is_isomorphic() for U in unique_graphs):
            unique_graphs.append(g1)
    ###Classify by k-value, only layers before k can be same, layers after k+1 must be different
    G_k_dict = defaultdict(list)  # Networks corresponding to different k values

    for g2 in unique_graphs:
        matrix1 = nh.BFS_distribution_G(g2)
        sorted_indices = np.lexsort(np.rot90(np.array(matrix1)))
        BFS_num_sorted1 = np.array(matrix1)[sorted_indices]
        k1 = BFS_num_sorted1.shape[1]
        k_original = BFS_num_sorted_original.shape[1]
        iflag1 = 0
        for ik in range(min(k1, k_original)):
            bfs1 = BFS_num_sorted1[:, ik]
            bfs_original = BFS_num_sorted_original[:, ik]
            js1 = nh.JS_divergence(bfs1, bfs_original)
            if js1 != 0:
                G_k_dict[ik - 1].append(g2)
                iflag1 = 1
                break
        if iflag1 == 0:
            G_k_dict[min(k1, k_original)].append(g2)  ###########Indicates entire matrix is identical
    # Sort G_k_dict by key
    sorted_dict = {key: G_k_dict[key] for key in sorted(G_k_dict)}
    G_k_dict = sorted_dict.copy()
    #the network assemble for karate
    with open(f'./Fig.4/{network_name}_10.pkl','wb') as file:
        pickle.dump(G_k_dict, file)

    result_dict = defaultdict(list)
    k_list=list(G_k_dict.keys())
    G_list11=[]
    for i1 in k_list:
        G_list11.extend(G_k_dict[i1])
    for i1 in tqdm(range(len(G_list11))):
        ig1=G_list11[i1]
        for i2 in range(len(G_list11)):
            ig2 = G_list11[i2]
            other_dict = nh.similarity_2g_various_size(ig1, ig2)
            a1, b1 = nh.NND_GAP_cross3(ig1)
            a2, b2 = nh.NND_GAP_cross3(ig2)
            other_dict['our'] = math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2)
            for key, value in other_dict.items():
                result_dict[key].append((i1,i2,value))
    with open(f'./Fig.4/{network_name}_class_10.pkl','wb') as file: #the distance matric for all methods
        pickle.dump(result_dict, file)
    #the statistics of networks preserving the node hierarchy structure
    result_dict1 = G_k_dict[6]
    motif_G_list = []
    multi_path_list = []
    for inetwork in result_dict1:
        motif_G = motif(inetwork)
        motif_G_list.append(motif_G)
        sorted_by_key1 = number_shortest_path(inetwork)
        multi_path_list.append(sorted_by_key1)
    return motif_G_original, multi_paths_original, motif_G_list, multi_path_list


def draw_k_class():
    """
    Visualizes similarity matrices for different network classification methods.

    Input: Reads precomputed similarity data from pickle files
    Output: Displays a 2x3 grid of heatmaps showing similarity matrices
    Function:
        - Loads classification results and network dictionary
        - Creates similarity matrices for each method
        - Displays heatmaps with proper masking and coloring
    """
    # Load classification results from pickle file
    file_path = './Fig.4/karate_class_10.pkl'
    with open(file_path, 'rb') as file:
        result_dict = pickle.load(file)

    # Load network dictionary containing k-classified networks
    file_path = './Fig.4/karate_10.pkl'
    with open(file_path, 'rb') as file:
        G_k_dict = pickle.load(file)

    # Print the number of networks in each k-classification category
    print([len(val1) for key, val1 in G_k_dict.items()])
    rcParams['font.family'] = 'Arial'

    # Create 2x3 subplot grid for the 6 methods
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))

    # Get list of method names from the result dictionary keys
    method_name = list(result_dict.keys())
    print(method_name)

    # Define matrix size (48x48 based on the data structure)
    n = 48

    # Iterate through each method and create corresponding heatmap
    for ikey, value in result_dict.items():
        # Initialize empty similarity matrix
        heatmap_matirx = np.zeros((n, n), dtype=np.float64)

        # Fill the similarity matrix with values from the result data
        for ivalue in value:
            heatmap_matirx[ivalue[0], ivalue[1]] = ivalue[2]

        # Create mask for zero or negative values (to hide them in heatmap)
        mask = heatmap_matirx <= 0

        # Calculate subplot position based on method index
        ax = axes[int(list(set(method_name)).index(ikey) / 3), int(list(set(method_name)).index(ikey) % 3)]

        # Create heatmap with red-yellow-blue reversed color scheme
        g = sns.heatmap(heatmap_matirx, ax=ax, mask=mask, cmap='RdYlBu_r', cbar=True)

        # Set background color to white
        g.set_facecolor('xkcd:white')

        # Set title to method name
        ax.set_title(ikey)

        # Invert y-axis to match typical matrix display convention
        g.invert_yaxis()

    # Adjust layout to prevent overlapping
    plt.tight_layout()

    # Display the complete visualization
    plt.show()

def draw_karate():
    """
    Creates visualizations comparing original karate club network with filtered random networks.

    Input: None (calls filiter_networks_k() to get data)
    Output: Displays two comparison plots
    Function:
        - Creates bar plot with swarm plot for motif counts comparison
        - Creates grouped bar plot with swarm plot for shortest path distribution comparison
    """
    original_motif, original_num, motif, shortest_num = filiter_networks_k()

    origianl_dict = {'id': list(range(len(original_motif))),
                     'value': original_motif}
    original_df = pd.DataFrame(origianl_dict)
    motif_nomarl = np.array(motif)
    id_list = []
    value_list = []
    for i in range(motif_nomarl.shape[1]):
        id_list.extend([i] * motif_nomarl.shape[0])
        value_list.extend(motif_nomarl[:, i])
    motif_dict = {"id": id_list,
                  "value": value_list}
    motif_df = pd.DataFrame(motif_dict)
    plt.figure(figsize=(8, 6))
    sns.barplot(x='id', y='value', data=original_df)
    sns.swarmplot(x="id", y="value", data=motif_df)

    plt.show()
    original_num1 = {key: np.log10(iva) for key, iva in original_num.items()}
    original_df = pd.DataFrame(list(original_num1.items()), columns=['Key', 'Value'])
    original_df['Class'] = 'Original'

    # Prepare DataFrame for shortest_num and add class attribute
    shortest_data = []
    for group_idx, sn in enumerate(shortest_num):
        for key, value in sn.items():
            shortest_data.append({'Key': key, 'Value': np.log10(value), 'Class': f'Shortest'})

    shortest_df = pd.DataFrame(shortest_data)

    combined_df = pd.concat([original_df, shortest_df], ignore_index=True)
    plt.figure(figsize=(12, 6))
    sns.barplot(x='Key', y='Value', hue='Class', data=combined_df)
    sns.swarmplot(data=shortest_df, x='Key', y='Value', color='k', alpha=0.5)
    plt.xlabel('Keys')
    plt.ylabel('Values')
    plt.xticks(rotation=0)
    plt.legend(title='Class')
    plt.tight_layout()
    plt.show()
def color_map(data, cmap):
    """Maps numerical values to colors"""
    dmin, dmax = np.nanmin(data), np.nanmax(data)
    cmo = plt.cm.get_cmap(cmap)
    cs, k = list(), 256 / cmo.N

    for i in range(cmo.N):
        c = cmo(i)
        for j in range(int(i * k), int((i + 1) * k)):
            cs.append(c)
    cs = np.array(cs)
    data = np.uint8(255 * (data - dmin) / (dmax - dmin))

    return cs[data]
def draw_historty_3d():
    """
    Creates 3D visualization of network evolution history in the NHE-EHE space.

    Input: Reads history data from text files
    Output: Displays 3D line plot with color-coded segments
    Function:
        - Reads optimization history and network hierarchy coordinates
        - Creates 3D plot showing evolution trajectory
        - Uses color coding to represent progression through optimization steps
    """
    import matplotlib.cm as cm
    file_path = './Fig.4/karate_result/H_history.txt'
    with open(file_path, 'r') as file:
        line = file.readline().strip()

    numbers = [int(num) for num in line.split(',')]
    file_ini = './Fig.4/karate_result/Initial_karate.txt'
    file_final = './karate_result/L5_5_1_0_karate.txt'
    g_ini = nh.real_networks(file_ini)
    g_final = nh.real_networks(file_final)
    a_ini, b_ini = nh.NND_GAP_cross3(g_ini)
    a_fin, b_fin = nh.NND_GAP_cross3(g_final)
    file1 = './Fig.4/karate_space_history.pkl'
    with open(file1, 'rb') as file:
        karate_nnd = pickle.load(file)
    g_history = karate_nnd[0]
    g_k = karate_nnd[1]
    history_nnd = {}
    whole_node = []
    whole_edge = []
    final_node = []
    final_edge = []
    for key, ivalue in g_history.items():
        history_nnd[key[1]] = ivalue
        whole_node.append(ivalue[0][0])
        whole_edge.append(ivalue[0][1])
    for ikey, jvalue in g_k.items():
        if ikey == 6:
            for k1 in jvalue:
                final_node.append(k1[0])
                final_edge.append(k1[1])
        for k1 in jvalue:
            whole_node.append(k1[0])
            whole_edge.append(k1[1])
    # Sort history by time
    history_nnd1 = dict(sorted(history_nnd.items()))
    history_node = [a_ini]
    history_edge = [b_ini]

    for ikey, kvalue in history_nnd1.items():
        history_node.append(kvalue[0][0])
        history_edge.append(kvalue[0][1])
    history_node.append(a_fin)
    history_edge.append(b_fin)
    final_node.append(a_fin)
    final_edge.append(b_fin)
    scatter_x = history_node
    scatter_y = history_edge
    scatter_z = numbers

    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')
    # Create color mapping based on number of segments
    num_segments = len(scatter_z) - 1  # Calculate number of segments
    colors = cm.coolwarm(np.linspace(0, 1, num_segments))  # Generate colors using Viridis colormap

    # Draw colored 3D line plot
    for i in range(num_segments):
        ax.plot(scatter_x[i:i + 2], scatter_y[i:i + 2], scatter_z[i:i + 2], color=colors[i], linewidth=2, marker='o')

    # Draw projection onto the bottom plane (XY plane at z = -500)
    for i in range(num_segments):
        ax.plot(scatter_x[i:i + 2], scatter_y[i:i + 2], ([-500] * len(scatter_x))[i:i + 2], color=colors[i],
                linewidth=2, marker='o')

    # # Draw vertical projection lines from 3D points to bottom plane
    # for i in range(len(scatter_z)):
    #     ax.plot([scatter_x[i], scatter_x[i]], [scatter_y[i], scatter_y[i]], [scatter_z[i], -500], color='gray')
    #
    # # Draw projection points on XZ plane (fix scatter_y values to 1)
    # for i in range(num_segments):
    #     ax.plot(scatter_x[i:i + 2], ([1] * len(scatter_x))[i:i + 2], scatter_z[i:i + 2], color=colors[i], linewidth=2,
    #             marker='o')
    #
    # # Draw main projection line on XZ plane (fix scatter_y values to 0.5)
    # ax.plot(scatter_x, [0.5] * len(scatter_x), scatter_z, color='b', alpha=0.5, label='Projected Points on XZ Plane',
    #         marker='o')
    #
    # # Draw dotted projection lines from 3D scatter points to XZ plane
    # for i in range(len(scatter_z)):
    #     ax.plot([scatter_x[i], scatter_x[i]], [0.5, scatter_y[i]], [scatter_z[i], scatter_z[i]], color='gray',
    #             linestyle='dotted')
    #
    # # Draw original 3D scatter points
    # ax.scatter(scatter_x, scatter_y, scatter_z, color='r', label='Scatter Points', s=50)
    #
    # # Set axis limits for better visualization
    # ax.set_xlim(0.22, 0.23)
    # ax.set_ylim(0.4, 0.405)

    ax.set_zlim(-1, 500)
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_zlabel('Z axis')
    ax.set_title('3D Line Plot with Color-coded Segments and Scatter Points')

    plt.show()


if __name__ == "__main__":
    """
    Main execution for network analysis visualizations:
    1. draw_historty_3d() - Creates 3D visualization of network evolution (for Fig.4(b))
    2. draw_karate() - Creates motif and the number of shortest paths for karate club network analysis (for Fig.4(c))
    """
    draw_historty_3d()  # for Fig.4(b)
    draw_karate()  ##for Fig.4(c)

    filiter_networks_k()#filter networks preserving the distance distribution of distance k
    draw_k_class()##for Fig.4(d)