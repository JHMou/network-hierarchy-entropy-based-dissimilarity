import matplotlib.pyplot as plt
import numpy as np
import random
import pandas as pd
import seaborn as sns
import Network_hierarchy as nh
from tqdm import tqdm
from multiprocessing import Pool
import pickle
import math
import itertools
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import normalized_mutual_info_score

def dk_model_similarity_distance_10_total(G_list, G_random_id):
    """
    Computes similarity measures between a target network and all networks in the list.

    Input:
        G_list: List of network graphs
        G_random_id: Index of target network in G_list

    Output:
        List containing NHE features and similarity dictionaries
    Function:
        - Computes NHE features for target network
        - Calculates various similarity measures between target and all other networks
    """
    NHE_dict = {}
    G_random = G_list[G_random_id]
    a1, b1 = nh.NND_GAP_cross3(G_random)
    NHE_dict[G_random_id] = (a1, b1)
    similarity_dict = {}
    for ig1 in tqdm(range(len(G_list))):
        G_initial = G_list[ig1]
        G_random = G_list[G_random_id]
        other_dict = nh.similarity_2g_various_size(G_random, G_initial)
        similarity_dict[(G_random_id, ig1)] = other_dict
    return [NHE_dict, similarity_dict]


def dk_model_similarity_distance_10_per_station():
    """
    Samples 10 networks from each DK model type and computes pairwise similarities.

    Input: None (reads network files from directories)
    Output: Saves results to multiple pickle files
    Function:
        - Randomly samples 10 networks from each DK model variant (50 total per type)
        - Uses multiprocessing to compute pairwise similarities efficiently
        - Saves results for each network type separately
    """
    import os
    file_base = './DATA/empirical-DK-50'
    folder1_list = ['Chemical', 'Collaboration', 'Dynamic', 'Economic', 'Facebook', 'Power', 'Proximity', 'Social',
                    'Technology', 'Web', 'Faa', 'Airlines', 'Road', 'Figeys']
    networks_list = ["dk2.0", "dk2.1", "dk2.5"]
    prefixes = ["dk2.0_", 'dk2.1_', 'dk2.5_']
    G_empirical_10 = []
    for i1 in folder1_list:
        for j1 in networks_list:
            folder1 = file_base + '/' + i1 + '/' + j1
            files1 = os.listdir(folder1)
            files1_no_prefix = {}
            for file in files1:
                for prefix in prefixes:
                    if file.startswith(prefix):
                        # File name after removing prefix
                        stripped_name = file[len(prefix):]
                        new_file = stripped_name.rsplit('.', 1)[0]
                        stripped_name1 = new_file[len(i1):]
                        files1_no_prefix[stripped_name1] = file
                        break
            # Randomly select 10 networks from 50
            iindex = 0
            for _ in range(50):
                icount = random.randint(0, 49)
                if (iindex < 10) and (str(icount) in list(files1_no_prefix.keys())):
                    file2_path1 = os.path.join(folder1, files1_no_prefix[str(icount)])
                    file2_path = file2_path1
                    G_random = nh.read_txt_new(file2_path)
                    G_empirical_10.append(G_random)
                    iindex += 1
        cpu_cores = 5
        pool = Pool(cpu_cores)
        results = []
        mobility_list = []
        for g_id in (range(len(G_empirical_10))):
            results.append(pool.apply_async(dk_model_similarity_distance_10_total, args=(G_empirical_10, g_id)))
        pool.close()
        pool.join()
        for result in [r.get() for r in results]:
            mobility_list.append(result)
        with open(f'./dk_model_10_per_{i1}.pkl', 'wb') as file:
            pickle.dump(mobility_list, file)

def draw_dk_similarity_10_per():
    """
    Creates a comprehensive visualization of network similarity comparisons across 6 methods and 14 networks.

    Input: Reads precomputed similarity data from pickle files
    Output: Displays 6x14 heatmap matrix and saves NMI results to CSV
    Function:
        - Creates 6x14 grid of heatmaps (6 methods × 14 networks)
        - Performs hierarchical clustering and calculates NMI scores for evaluation
        - Visualizes similarity matrices with consistent color scaling
        - Saves Normalized Mutual Information (NMI) results to CSV file
    """
    folder1_list = ['Chemical', 'Collaboration', 'Dynamic', 'Economic', 'Facebook', 'Power', 'Proximity', 'Social',
                    'Technology', 'Web', 'Faa', 'Airlines', 'Road', 'Figeys']

    # Create large figure: 6 rows × 14 columns
    from matplotlib import rcParams
    # Set global font to Arial
    rcParams['font.family'] = 'Arial'
    fig, axes = plt.subplots(6, 14, figsize=(42, 18))  # 6 rows, 14 columns
    fig.suptitle('Network Similarity Comparison (6 Methods × 14 Networks)', fontsize=20, y=0.98)
    min_val, max_val = float('inf'), float('-inf')

    # Create DataFrame to store NMI results
    nmi_results = pd.DataFrame(columns=folder1_list,
                               index=['NHE', 'IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure'])

    for col_idx, ifile in enumerate(folder1_list):
        try:
            files = f'./dk_model_10_per_{ifile}.pkl'
            with open(files, 'rb') as file:
                ws_distance = pickle.load(file)
            print(ifile)
            # Initialize matrices
            n = 30
            Total_NHE = np.zeros((n, n), dtype=np.float64)
            Total_IM = np.zeros((n, n), dtype=np.float64)
            Total_POR = np.zeros((n, n), dtype=np.float64)
            Total_D = np.zeros((n, n), dtype=np.float64)
            Total_LSD = np.zeros((n, n), dtype=np.float64)
            Total_NET = np.zeros((n, n), dtype=np.float64)

            # Calculate NHE distances
            for ilist in range(len(ws_distance)):
                for jlist in range(ilist + 1, len(ws_distance)):
                    nhe_dict1 = ws_distance[ilist][0]
                    nhe_dict2 = ws_distance[jlist][0]
                    a1, b1 = nhe_dict1[ilist]
                    a2, b2 = nhe_dict2[jlist]
                    d = math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2)
                    Total_NHE[ilist, jlist] = d
                    Total_NHE[jlist, ilist] = d

                # Process other methods
                other_id = ws_distance[ilist][1]
                for ikey1, ivalue1 in other_id.items():
                    for imethod, value111 in ivalue1.items():
                        if imethod == 'IM':
                            Total_IM[ikey1[0], ikey1[1]] = value111
                            Total_IM[ikey1[1], ikey1[0]] = value111
                        elif imethod == 'POR':
                            Total_POR[ikey1[0], ikey1[1]] = value111
                            Total_POR[ikey1[1], ikey1[0]] = value111
                        elif imethod == 'NetSimile':
                            Total_NET[ikey1[0], ikey1[1]] = value111
                            Total_NET[ikey1[1], ikey1[0]] = value111
                        elif imethod == 'NetLSD':
                            Total_LSD[ikey1[0], ikey1[1]] = value111
                            Total_LSD[ikey1[1], ikey1[0]] = value111
                        elif imethod == 'd-measure':
                            Total_D[ikey1[0], ikey1[1]] = value111
                            Total_D[ikey1[1], ikey1[0]] = value111

            # Prepare data for 6 methods
            matrices = [
                Total_NHE, Total_IM, Total_POR,
                Total_NET, Total_LSD, Total_D
            ]
            method_names = ['NHE', 'IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure']

            # Plot each method in current column's 6 rows
            for row_idx, (matrix, method_name) in enumerate(zip(matrices, method_names)):
                ax = axes[row_idx, col_idx]

                # Create mask to make zero values transparent
                zero_mask = (matrix == 0)
                min_val = min(min_val, np.min(matrix))
                max_val = max(max_val, np.max(matrix))

                # Draw heatmap
                g = sns.heatmap(
                    matrix,
                    cmap='RdYlBu',
                    ax=ax,
                    mask=zero_mask,
                    square=True,
                    cbar=False
                )
                g.set_facecolor('white')

                # Calculate clustering evaluation metrics
                TRUE_LABEL = list(itertools.chain.from_iterable([[num] * 10 for num in range(1, 4)]))
                hierarchical = AgglomerativeClustering(n_clusters=3, affinity='precomputed',
                                                       linkage='average')
                hierarchical_labels = hierarchical.fit_predict(matrix)

                nmi_score = normalized_mutual_info_score(TRUE_LABEL, hierarchical_labels)

                print(f'{ifile} - {method_name}:')
                print(f'  Normalized Mutual Information (NMI): {nmi_score:.4f}')

                # Store NMI results in DataFrame
                nmi_results.loc[method_name, ifile] = nmi_score

                # Set titles and labels
                if col_idx == 0:  # First column shows method names
                    ax.set_ylabel(method_name, fontsize=16, rotation=0, ha='right', va='center')
                if row_idx == 0:  # First row shows network names
                    ax.set_title(ifile, fontsize=16, pad=5)

                ax.invert_yaxis()
                ax.set_xticks([])
                ax.set_yticks([])

        except FileNotFoundError:
            print(f"File not found: {files}")
            # If file doesn't exist, create blank subplot and fill NaN values
            for row_idx, method_name in enumerate(['NHE', 'IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure']):
                ax = axes[row_idx, col_idx]
                ax.text(0.5, 0.5, 'File Not Found', ha='center', va='center',
                        transform=ax.transAxes, fontsize=12)
                ax.set_facecolor('lightgray')
                if row_idx == 0:
                    ax.set_title(ifile, fontsize=16, pad=5)
                # Fill NaN for missing files
                nmi_results.loc[method_name, ifile] = np.nan

    # Adjust layout, reduce spacing
    plt.tight_layout()
    plt.subplots_adjust(top=0.94, bottom=0.12, hspace=0.1, wspace=0.05)

    # Add unified colorbar below row 6
    cbar_ax = fig.add_axes([0.15, 0.06, 0.7, 0.02])
    sm = plt.cm.ScalarMappable(cmap='RdYlBu')

    sm.set_array(np.array([min_val, max_val]))
    cbar = fig.colorbar(sm, cax=cbar_ax, orientation='horizontal', label='Similarity Value')
    cbar.set_label('Similarity Value', fontsize=16)
    cbar.ax.tick_params(labelsize=14)
    plt.show()
    nmi_results.to_csv('./nmi_results_6methods_14networks.csv',
                       float_format='%.4f')


if __name__ == '__main__':

    dk_model_similarity_distance_10_per_station()  #  Sample and compute pairwise similarities
    draw_dk_similarity_10_per()  #  Create pairwise visualization