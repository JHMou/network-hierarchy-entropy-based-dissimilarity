import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import Network_hierarchy as nh
from tqdm import tqdm
from scipy import stats
import pickle
import math



def dk_model_similarity_distance_50():
    """
    Computes similarity distances between original networks and their DK2.0, DK2.1, DK2.5 model variants.

    Input: None (reads network files from specified directories)
    Output: Saves results to pickle file
    Function:
        - Processes 14 real-world networks and their DK model variants
        - Computes NHE features and various similarity measures for each network pair
        - Saves similarity dictionaries and NHE features to file
    """
    import os
    # Define folder paths
    file_base = './DATA/empirical-DK-50'
    folder1_list = ['Chemical', 'Collaboration', 'Dynamic', 'Economic', 'Facebook', 'Power', 'Proximity', 'Social',
                    'Technology', 'Web', 'Faa', 'Airlines', 'Road', 'Figeys']
    networks_list = ['dk2.0', 'dk2.1', 'dk2.5']
    folder2 = "./DATA/Networks"
    # Define prefix list
    prefixes = ['dk2.0_', 'dk2.1_', 'dk2.5_']
    # Get file list
    similarity_dict = {}
    network_NHE_dict = {}
    for i1 in folder1_list:
        file2 = i1 + '.txt'
        file1_path = os.path.join(folder2, file2)
        G_initial = nh.read_txt_new(file1_path)
        a, b = nh.NND_GAP_cross3(G_initial)
        network_NHE_dict[(i1, 'original', 0)] = [a, b]
        print(network_NHE_dict)
        for j1 in networks_list:
            folder1 = file_base + '/' + i1 + '/' + j1
            files1 = os.listdir(folder1)
            # File name mapping after removing prefixes
            files1_no_prefix = {}
            for file in files1:
                for prefix in prefixes:
                    if file.startswith(prefix):
                        # File name after removing prefix
                        stripped_name = file[len(prefix):]
                        new_file = stripped_name.rsplit('.', 1)[0]
                        stripped_name1 = new_file[len(i1) + 1:]  ###stripped_name1 is random network id
                        files1_no_prefix[stripped_name1] = file
                        break

            # Calculate average of 50 distances between dk and original network
            for icount in tqdm(range(50)):
                file2_path1 = os.path.join(folder1, files1_no_prefix[str(icount)])
                file2_path = file2_path1
                G_random = nh.read_txt_new(file2_path)
                other_dict = nh.similarity_2g_various_size(G_random, G_initial)
                a1, b1 = nh.NND_GAP_cross3(G_random)
                similarity_dict[(i1, j1, icount)] = other_dict  # network-dk-id
                network_NHE_dict[(i1, j1, icount)] = [a1, b1]

        with open(f'./real_networks_dk_distance_50-{i1}.pkl', 'wb') as file:
            pickle.dump([similarity_dict, network_NHE_dict], file)


def draw_dk_50_average():
    """
    Analyzes and visualizes average similarity distances with confidence intervals.

    Input: Reads multiple pickle files containing network distance data
    Output: Generates CSV file, heatmap visualizations, and Excel spreadsheet
    Function:
        - Computes average distances and 95% confidence intervals for 6 similarity methods
        - Creates boxplot data for visualization
        - Generates heatmaps showing method performance across networks
        - Exports statistical results to CSV and Excel formats
    """
    folder1_list = ['Chemical', 'Collaboration', 'Dynamic', 'Economic', 'Facebook', 'Power', 'Proximity', 'Social',
                    'Technology', 'Web', 'Faa', 'Airlines', 'Road', 'Figeys']
    # Initialize dk1 by loading and merging data from all network files
    files = f'./real_networks_dk_distance_50-Chemical.pkl'
    with open(files, 'rb') as file:
        dk1 = pickle.load(file)

    for inetwork in folder1_list[1:]:
        files = f'./real_networks_dk_distance_50-{inetwork}.pkl'
        with open(files, 'rb') as file:
            merged_list1 = pickle.load(file)
            dk1 = [{**dict1, **dict2} for
                   dict1, dict2 in
                   zip(dk1, merged_list1)]
    networks_list = ["dk2.0", "dk2.1", "dk2.5"]
    dk_average_dict = {}
    Network_list = []
    method_list = []
    dk_list = []
    value_list = []

    for inetwork in folder1_list:
        for idk in networks_list:
            Total_NHE = []
            # Calculate NHE data
            a1, b1 = dk1[1][(inetwork, 'original', 0)]
            for j11 in range(50):
                a2, b2 = dk1[1][inetwork, idk, j11]
                d = math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2)
                Total_NHE.append(d)
                Network_list.append(inetwork)
                dk_list.append(idk)
                value_list.append(d)
                method_list.append('NHE')
            std_err = stats.sem(Total_NHE)
            confidence = 0.95
            mean = np.average(Total_NHE)
            ci = std_err * stats.t.ppf((1 + confidence) / 2., len(Total_NHE) - 1)
            dk_average_dict[(inetwork, idk, 'NHE')] = [mean - ci, mean, mean + ci]

            Total_IM = []
            Total_POR = []
            Total_NET = []
            Total_LSD = []
            Total_D = []
            for icount in range(50):
                other_dict = dk1[0][(inetwork, idk, icount)]
                for keyy, valuee in other_dict.items():
                    print(valuee)
                    Network_list.append(inetwork)
                    dk_list.append(idk)
                    value_list.append(valuee)
                    if keyy == 'IM':
                        Total_IM.append(valuee)
                        method_list.append('IM')
                    if keyy == 'POR':
                        Total_POR.append(valuee)
                        method_list.append('POR')
                    if keyy == 'NetSimile':
                        Total_NET.append(valuee)
                        method_list.append('NetSimile')
                    if keyy == 'NetLSD':
                        Total_LSD.append(valuee)
                        method_list.append('NetLSD')
                    if keyy == 'd-measure':
                        Total_D.append(valuee)
                        method_list.append('d-measure')

            std_err = stats.sem(Total_POR)
            confidence = 0.95
            mean = np.average(Total_POR)
            ci = std_err * stats.t.ppf((1 + confidence) / 2., len(Total_POR) - 1)
            dk_average_dict[(inetwork, idk, 'POR')] = [mean - ci, mean, mean + ci]

            std_err = stats.sem(Total_IM)
            confidence = 0.95
            mean = np.average(Total_IM)
            ci = std_err * stats.t.ppf((1 + confidence) / 2., len(Total_IM) - 1)
            dk_average_dict[(inetwork, idk, 'IM')] = [mean - ci, mean, mean + ci]

            std_err = stats.sem(Total_NET)
            confidence = 0.95
            mean = np.average(Total_NET)
            ci = std_err * stats.t.ppf((1 + confidence) / 2., len(Total_NET) - 1)
            dk_average_dict[(inetwork, idk, 'NetSimile')] = [mean - ci, mean, mean + ci]

            std_err = stats.sem(Total_LSD)
            confidence = 0.95
            mean = np.average(Total_LSD)
            ci = std_err * stats.t.ppf((1 + confidence) / 2., len(Total_LSD) - 1)
            dk_average_dict[(inetwork, idk, 'NetLSD')] = [mean - ci, mean, mean + ci]

            std_err = stats.sem(Total_D)
            confidence = 0.95
            mean = np.average(Total_D)
            ci = std_err * stats.t.ppf((1 + confidence) / 2., len(Total_D) - 1)
            dk_average_dict[(inetwork, idk, 'd-measure')] = [mean - ci, mean, mean + ci]

    # Create DataFrame for boxplot data and save to CSV
    df = pd.DataFrame({
        'Network': Network_list,
        'method': method_list,
        'dk': dk_list,
        'value': value_list
    })
    titles = ['NHE', 'IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure']
    df.to_csv('./R_dk_boxplot_data.csv', index=False)

    # Create heatmap visualizations for each method
    from matplotlib import rcParams
    # Set global font to Times New Roman
    rcParams['font.family'] = 'Times New Roman'
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    method_name = ['NHE', 'POR', 'IM', 'NetSimile', 'NetLSD', 'd-measure']
    for imethod in titles:
        # Create one matrix per method
        heatmap_matirx_POR = np.zeros((len(folder1_list), len(networks_list)), dtype=np.float64)
        for key1, value2 in dk_average_dict.items():
            heatmap_matirx_POR[folder1_list.index(key1[0]), networks_list.index(key1[1])] = \
                dk_average_dict[key1[0], key1[1], imethod][1]
        ax = axes[int(list(set(method_name)).index(imethod) / 3), int(list(set(method_name)).index(imethod) % 3)]
        g = sns.heatmap(heatmap_matirx_POR, ax=ax, cmap='RdYlBu_r', cbar=True)
        g.set_facecolor('xkcd:white')
        ax.set_title(imethod)
    plt.show()

    # Create Excel file with separate sheets for each DK type
    dfs = []
    for idk in ['dk2.0', 'dk2.1', 'dk2.5']:
        # Filter data for current dk type
        idk_data = {key: value for key, value in dk_average_dict.items() if key[1] == idk}

        # Create horizontal table directly
        networks = sorted(set(key[0] for key in idk_data.keys()))
        methods = sorted(set(key[2] for key in idk_data.keys()))

        # Create horizontal DataFrame
        result_data = []
        for network in networks:
            row = {'Network': network}
            for method in methods:
                key = (network, idk, method)
                if key in idk_data:
                    values = idk_data[key]
                    # Format three values as a string in one cell
                    row[method] = f"[{values[0]:.5f}, {values[1]:.5f}, {values[2]:.5f}]"
                else:
                    row[method] = None
            result_data.append(row)

        result_df = pd.DataFrame(result_data)
        dfs.append((idk, result_df))

    # Write to Excel file
    output_file = '.\DK-average.xlsx'
    with pd.ExcelWriter(output_file) as writer:
        for idk, df in dfs:
            # Each dk type gets its own sheet
            df.to_excel(writer, sheet_name=idk, index=False)




if __name__ == '__main__':
    
    dk_model_similarity_distance_50()  # Compute similarity distances
    draw_dk_50_average()  #  Analyze and visualize average distances