import math
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import Network_hierarchy as nh
from tqdm import tqdm
import os
import pickle
from multiprocessing import Pool
from collections import defaultdict
from sklearn.cluster import AgglomerativeClustering

plt.rcParams['font.sans-serif'] = ['Arial']
plt.rcParams['axes.unicode_minus'] = False


def China_mobility(folder1, ifile):
    """
    Calculate NHE values for each network corresponding to ifile.

    Args:
        folder1 (str): Directory containing network files
        ifile (str): Specific network file to process

    Returns:
        dict: Dictionary containing NHE values (a1, b1) for the network
    """
    OD_matrix_dict = {}
    G_dict = {}
    file1 = folder1 + '/' + ifile
    matrix = pd.read_csv(file1, index_col=0)
    matrix_numpy = matrix.to_numpy()
    OD_matrix_dict[ifile] = matrix
    directed_graph = nx.from_numpy_array(matrix_numpy, create_using=nx.DiGraph)
    undirected_graph = nx.Graph(directed_graph)
    # Remove weight attributes from edges
    for u, v, data in undirected_graph.edges(data=True):
        data.pop('weight', None)
    # Calculate NHE values using Network_hierarchy module
    G1 = undirected_graph
    a1, b1 = nh.NND_GAP_cross3(G1)
    G_dict[ifile] = [a1, b1]
    return G_dict


def China_mobility_others(folder1, ifile):
    """
    Calculate distance between ifile network and all other networks in folder1 using various methods.

    Args:
        folder1 (str): Directory containing network files
        ifile (str): Specific network file to compare against others

    Returns:
        defaultdict: Dictionary containing distance results for different methods
    """
    result_dict = defaultdict(list)

    # Load and process the target network
    file1 = folder1 + '/' + ifile
    matrix = pd.read_csv(file1, index_col=0)
    matrix_numpy = matrix.to_numpy()
    directed_graph = nx.from_numpy_array(matrix_numpy, create_using=nx.DiGraph)
    undirected_graph = nx.Graph(directed_graph)
    for u, v, data in undirected_graph.edges(data=True):
        data.pop('weight', None)
    G1 = undirected_graph
    files1 = os.listdir(folder1)
    # Calculate distances to all other networks
    for file_per in files1:
        file1 = folder1 + '/' + file_per
        matrix = pd.read_csv(file1, index_col=0)
        matrix_numpy = matrix.to_numpy()
        directed_graph = nx.from_numpy_array(matrix_numpy, create_using=nx.DiGraph)
        undirected_graph = nx.Graph(directed_graph)
        for u, v, data in undirected_graph.edges(data=True):
            data.pop('weight', None)
        G2 = undirected_graph
        # Calculate various similarity measures between the two networks
        other_dict = nh.similarity_2g_various_size(G1, G2)
        # Store results by method type
        for key, value in other_dict.items():
            result_dict[key].append((ifile, file_per, value))

    return result_dict


def China_mobility_nonconsective_others(folder1, ifile):
    """
    Calculate distance between ifile network and the initial network (1st January).

    Args:
        folder1 (str): Directory containing network files
        ifile (str): Specific network file to compare with initial network

    Returns:
        defaultdict: Dictionary containing distance results for different methods
    """
    result_dict = defaultdict(list)
    file1 = folder1 + '/' + ifile
    matrix = pd.read_csv(file1, index_col=0)
    matrix_numpy = matrix.to_numpy()
    directed_graph = nx.from_numpy_array(matrix_numpy, create_using=nx.DiGraph)
    undirected_graph = nx.Graph(directed_graph)
    for u, v, data in undirected_graph.edges(data=True):
        data.pop('weight', None)
    G1 = undirected_graph

    files1 = ['matrix_0.csv']#network for 1st January
    merged_graph = nx.Graph()

    for file_per in files1:
        file1 = folder1 + '/' + file_per
        matrix = pd.read_csv(file1, index_col=0)
        matrix_numpy = matrix.to_numpy()
        directed_graph = nx.from_numpy_array(matrix_numpy, create_using=nx.DiGraph)
        undirected_graph = nx.Graph(directed_graph)
        for u, v, data in undirected_graph.edges(data=True):
            data.pop('weight', None)
        # Merge network (though only one network is processed here)
        merged_graph = nx.compose(merged_graph, undirected_graph)

    G2 = merged_graph
    # Calculate various similarity measures
    other_dict = nh.similarity_2g_various_size(G1, G2)
    # Store results by method type
    for key, value in other_dict.items():
        result_dict[key].append((ifile, value))
    return result_dict


def china_mobility_parallel():
    """
    Parallel processing function to calculate network distances using multiple CPU cores.
    Saves results to a pickle file.
    """
    # Define data directory
    folder1 = './DATA/Temporal mobility networks'
    files1 = os.listdir(folder1)
    print(files1)

    # Set up parallel processing with 20 CPU cores
    cpu_cores = 20
    pool = Pool(cpu_cores)
    results = []
    mobility_list = []

    # Process each file in parallel
    for ifile in tqdm(files1[1]):
        # Note: files1[1] might be a specific subset
        # Use China_mobility_nonconsective_others() to calculate distance to Jan 1st network
        # Can be replaced with China_mobility() to calculate NHE values for all networks
        # Can be replaced with China_mobility_others() to calculate pairwise distances between all networks
        results.append(pool.apply_async(China_mobility_nonconsective_others, args=(folder1, ifile)))

    pool.close()
    pool.join()
    print('done')

    for result in [r.get() for r in results]:
        mobility_list.append(result)

    with open('./Fig.5/mobility_networks_nonconsective_other.pkl', 'wb') as file:
        pickle.dump(mobility_list, file)



def draw_scatter_line_combined():
    """
    Combines both scatter plot functions and creates a 2x3 subplot layout.
    Displays mobility network distance comparisons across 6 different methods.

    Input: Reads mobility network data from pickle files
    Output: 2x3 grid of scatter plots showing temporal distance patterns
    """
    # Import font configuration
    from matplotlib import rcParams
    rcParams['font.family'] = 'Times New Roman'

    # Create 2x3 subplot figure
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()  # Flatten for easy indexing

    # Process first dataset (our method - NHE)
    files = './Fig.5/mobility_networks.pkl'
    with open(files, 'rb') as file:
        data = pickle.load(file)

    # Extract NHE coordinates (a1, b1 values)
    x_list = []
    y_list = []
    for idata in data:
        x_list.append(list(idata.values())[0][0])
        y_list.append(list(idata.values())[0][1])

    # Calculate distances between consecutive time points
    distance_list = []
    key_list = []
    for i in range(60):
        key_list.append(f'matrix_{i}.csv')

    # Create dictionary mapping file names to NHE values
    data_dict = {}
    for item in data:
        data_dict.update(item)

    # Calculate Euclidean distances between consecutive networks
    for i in range(len(key_list) - 1):
        data_before = data_dict[key_list[i]]
        data_after = data_dict[key_list[i + 1]]
        a1 = data_before[0]
        b1 = data_before[1]
        a2 = data_after[0]
        b2 = data_after[1]
        distance_list.append(math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2))

    # Plot our method in the first subplot
    ax = axes[0]
    ax.scatter(list(range(len(distance_list))), distance_list, label='Our Method', color='red', s=50)
    ax.set_ylabel('Distance', color='red')
    ax.tick_params(axis='y', labelcolor='red')
    ax.set_title('Our Method (NHE)')
    ax.legend(loc='upper left')
    ax.grid(True, alpha=0.3)

    # Process second dataset (other methods)
    files = './Fig.5/mobility_networks_other_0119.pkl'
    with open(files, 'rb') as file:
        data = pickle.load(file)

    result_dict = defaultdict(list)
    key_list = []
    for i in range(60):
        key_list.append(f'matrix_{i}.csv')

    # Process data for other methods
    for idata in data:
        for key, value in idata.items():
            mid_dict = {}
            for ivalue in value:
                # Only keep consecutive time segments by checking index order
                if key_list.index(ivalue[0]) + 1 == key_list.index(ivalue[1]):
                    mid_dict[key_list.index(ivalue[0])] = ivalue[2]  # Use previous index as key
                    break
            result_dict[key].append(mid_dict)

    # Plot the other 5 methods in remaining subplots
    plot_index = 1  # Start from second subplot

    for ikey, value1 in result_dict.items():
        if plot_index >= 6:
            break
        # Combine dictionaries for the current method
        ikey_dict = {}
        for item in value1:
            ikey_dict.update(item)

        # Sort by time order
        distance_dict = dict(sorted(ikey_dict.items()))
        distance_list = list(distance_dict.values())

        # Plot in corresponding subplot
        ax = axes[plot_index]
        ax.scatter(list(range(len(distance_list))), distance_list, label=ikey, color='red', s=50)
        ax.set_ylabel('Distance', color='red')
        ax.tick_params(axis='y', labelcolor='red')
        ax.set_title(ikey)
        ax.legend(loc='upper left')
        ax.grid(True, alpha=0.3)

        plot_index += 1

    for i in range(6):
        axes[i].set_xlabel('Time Interval')
    plt.tight_layout()
    plt.show()


def draw_scatter_line_nonconsective():
    """
    Plot scatter plot showing distance of each network from the initial network (matrix_0.csv) using NHE method.
    """
    # Load NHE data
    files = './Fig.5/mobility_networks.pkl'
    with open(files, 'rb') as file:
        data = pickle.load(file)

    x_list = []
    y_list = []
    for idata in data:
        x_list.append(list(idata.values())[0][0])
        y_list.append(list(idata.values())[0][1])

    distance_list = []
    key_list = []
    for i in range(60):
        key_list.append(f'matrix_{i}.csv')

    data_dict = {}
    print(key_list)
    for item in data:
        data_dict.update(item)

    # Calculate Euclidean distance from each network to the initial network
    for i in range(len(key_list)):
        data_after = data_dict[key_list[i]]
        a1 = data_dict['matrix_0.csv'][0]
        b1 = data_dict['matrix_0.csv'][1]
        a2 = data_after[0]
        b2 = data_after[1]
        distance_list.append(math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2))

    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    method_name = ['IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure', 'NHE']

    # Find position for NHE plot in the 2x3 grid
    ax2 = axes[int(list(set(method_name)).index('NHE') / 3), int(list(set(method_name)).index('NHE') % 3)]


    ax2.scatter(list(range(len(distance_list))), distance_list, label='Scatter Points', color='red', s=50)
    ax2.set_ylabel('Y-axis', color='red')
    ax2.tick_params(axis='y', labelcolor='red')

    plt.title('Line and Scatter Plot')
    ax2.legend(loc='upper right')

    plt.tight_layout()
    plt.show()


def extract_number(key):
    """
    Extract numeric value from filename like 'matrix_X.csv'

    Args:
        key (str): Filename string

    Returns:
        int: Extracted number X
    """
    return int(key.split('_')[1].split('.')[0])


def draw_scatter_line_nonconsective_others():
    """
    Plot scatter plots showing distance of each network from the initial network using other methods.
    Creates a 2x3 grid of plots for different network similarity measures.
    """
    # Load non-consecutive comparison data
    files = './Fig.5/mobility_networks_nonconsective_others.pkl'
    with open(files, 'rb') as file:
        data = pickle.load(file)

    result_dict = defaultdict(list)
    key_list = []
    for i in range(60):
        key_list.append(f'matrix_{i}.csv')

    for idata in data:
        for key, value in idata.items():
            mid_dict = {}
            mid_dict[value[0][0]] = value[0][1]
            result_dict[key].append(mid_dict)


    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    method_name = ['IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure']
    color_list = ['#A50026', '#F46E43', '#FEE293', '#BFE3EF', '#5F94C3']

    for ikey, value1 in result_dict.items():

        ikey_dict = {}
        for item in value1:
            ikey_dict.update(item)
        distance_dict = {k: v for k, v in sorted(ikey_dict.items(), key=lambda x: extract_number(x[0]))}

        distance_list1 = list(distance_dict.values())
        distance_list = distance_list1[1:]

        icol = int(list(set(method_name)).index(ikey) / 3)
        irow = int(list(set(method_name)).index(ikey) % 3)
        ax2 = axes[icol, irow]

        ax2.scatter(list(range(len(distance_list))), distance_list, label='Scatter Points',
                    color=color_list[icol * 3 + irow], s=50)
        ax2.set_ylabel('Y-axis', color='red')
        ax2.tick_params(axis='y', labelcolor='red')
        ax2.set_title(ikey)  # Method name as title
        ax2.legend(loc='upper left')

    plt.tight_layout()
    plt.show()


def SLouvain_networks():
    """
    Perform Spatial Louvain community detection on mobility networks and save node/edge information.
    Processes specific days: Jan 1, Jan 10, Jan 23, Feb 10, Feb 29.
    """

    import community as community_louvain

    file1 = r'./Fig.5/mobillity_id.csv'
    result1 = pd.read_csv(file1)

    # Process specific days
    file = r'./DATA/Temporal mobility networks'
    id_list = [0, 9, 22, 40, 59]  # Jan 1, Jan 10, Jan 23, Feb 10, Feb 29

    for id in id_list:
        file1 = file + f'\matrix_{id}.csv'
        matrix = pd.read_csv(file1, index_col=0)
        matrix_numpy = matrix.to_numpy()
        directed_graph = nx.from_numpy_array(matrix_numpy, create_using=nx.DiGraph)
        undirected_graph = nx.Graph(directed_graph)
        # Perform Louvain community detection with edge weights
        partition = community_louvain.best_partition(undirected_graph, weight='weight')
        # Create node data with community assignments
        node_data = pd.DataFrame({'id': list(partition.keys()),
                                  'community_id': list(partition.values())})
        # Merge with geographical information
        node_data = pd.merge(node_data, result1, on='id', how='left')
        node_data.to_csv(f'./Fig.5/day{id}_nodes.csv', index=False)

        # Process edge information
        source_list = []
        target_list = []
        weight_list = []
        edge_community = []  # Community ID or indicator for inter-community edges

        for u, v, data in undirected_graph.edges(data=True):
            source_list.append(u)
            target_list.append(v)
            weight_list.append(data.get('weight', 1))

            # Determine if edge is within community or between communities
            if partition[u] == partition[v]:
                edge_community.append(partition[u])  # Intra-community edge, mark with community ID
            else:
                edge_community.append(-1)  # Inter-community edge, mark with -1

        # Create edge DataFrame
        df_edge = pd.DataFrame({
            'source': source_list,
            'target': target_list,
            'weight': weight_list,
            'edge_community': edge_community
        })

        # Merge with source node geographical information
        df_edge1 = pd.merge(df_edge, result1, left_on='source', right_on='id', how='left')
        df_edge1 = df_edge1.rename(columns={'lat': 'source_lat', 'lng': 'source_lng'})
        df_edge1 = df_edge1.drop(columns=['id'])

        # Merge with target node geographical information
        df_edge2 = pd.merge(df_edge1, result1, left_on='target', right_on='id', how='left')
        df_edge2 = df_edge2.rename(columns={'lat': 'target_lat', 'lng': 'target_lng'})
        df_edge2 = df_edge2.drop(columns=['id'])
        df_edge2 = df_edge2.drop(columns=['weight'])

        # Save edge information to CSV
        df_edge2.to_csv(f'./Fig.5/day{id}_edges.csv', index=False)


def network_centralities_china():
    """
    Plot various network centrality measures over time in a 2x2 subplot layout.
    Shows clustering coefficient, betweenness centrality, closeness centrality, and density.
    """
    file1 = './Fig.5/topology.csv'
    matrix = pd.read_csv(file1, header=0)

    marker_list = ['<', 'o', 'd', 'p']
    column_list = ['clustering', 'betweenness', 'closness', 'density']
    color_list = ['#A50026', '#F46E43', '#FEE293', '#BFE3EF', '#5F94C3']

    fig, axes = plt.subplots(2, 2, figsize=(10, 6))

    for icol1 in column_list:
        mid = list(matrix[icol1])
        icol = int(column_list.index(icol1) / 2)
        irow = int(column_list.index(icol1) % 2)
        ax1 = axes[icol, irow]

        # Plot time series with specific marker and color
        ax1.plot(list(range(len(mid))), mid, markersize=5,
                 marker=marker_list[column_list.index(icol1)],
                 color=color_list[column_list.index(icol1)])
        ax1.set_title(icol1)
    plt.tight_layout()
    plt.show()


def draw_distance_mobility_combined():
    """
    Create combined visualization of distance matrices and clustering results for 6 network similarity methods.
    Generates two figures: heatmaps of distance matrices and clustering result time series.
    """
    import pickle
    import numpy as np
    import matplotlib.pyplot as plt
    import seaborn as sns
    import math
    from matplotlib import rcParams
    # Load NHE data
    files_nhe = './Fig.5/mobility_networks.pkl'
    with open(files_nhe, 'rb') as file:
        data_nhe = pickle.load(file)

    # Create list of network filenames
    key_list = []
    for i in range(60):
        key_list.append(f'matrix_{i}.csv')

    # Create dictionary mapping filenames to NHE values
    data_dict = {}
    for item in data_nhe:
        data_dict.update(item)

    n = len(key_list)

    # Sort networks by their numeric index
    distance_dict = {k: v for k, v in sorted(data_dict.items(), key=lambda x: extract_number(x[0]))}

    # Calculate NHE distance matrix (Euclidean distance in NHE space)
    heatmap_matrix_nhe = np.zeros((n, n), dtype=np.float64)
    for i in range(len(key_list)):
        for j in range(i + 1, len(key_list)):
            data_before = distance_dict[key_list[i]]
            data_after = distance_dict[key_list[j]]
            a1 = data_before[0]
            b1 = data_before[1]
            a2 = data_after[0]
            b2 = data_after[1]
            d = math.sqrt((a1 - a2) ** 2 + (b1 - b2) ** 2)
            heatmap_matrix_nhe[i, j] = d
            heatmap_matrix_nhe[j, i] = d

    # Load other methods' data
    files_others = './Fig.5/mobility_networks_other_0119.pkl'
    with open(files_others, 'rb') as file:
        data_others = pickle.load(file)

    # Initialize distance matrices for other methods
    IM_matrix = np.zeros((n, n), dtype=np.float64)
    POR_matrix = np.zeros((n, n), dtype=np.float64)
    NetSimile_matrix = np.zeros((n, n), dtype=np.float64)
    NetLSD_matrix = np.zeros((n, n), dtype=np.float64)
    D_matrix = np.zeros((n, n), dtype=np.float64)

    # Populate distance matrices for each method
    for idata in data_others:
        for key, value in idata.items():
            if key == 'IM':
                for ivalue in value:
                    IM_matrix[key_list.index(ivalue[0]), key_list.index(ivalue[1])] = ivalue[2]
            elif key == 'POR':
                for ivalue in value:
                    POR_matrix[key_list.index(ivalue[0]), key_list.index(ivalue[1])] = ivalue[2]
            elif key == 'NetSimile':
                for ivalue in value:
                    NetSimile_matrix[key_list.index(ivalue[0]), key_list.index(ivalue[1])] = ivalue[2]
            elif key == 'NetLSD':
                for ivalue in value:
                    NetLSD_matrix[key_list.index(ivalue[0]), key_list.index(ivalue[1])] = ivalue[2]
            elif key == 'd-measure':
                for ivalue in value:
                    D_matrix[key_list.index(ivalue[0]), key_list.index(ivalue[1])] = ivalue[2]

    # Define method names and corresponding matrices
    method_names = ['NHE', 'IM', 'POR', 'NetSimile', 'NetLSD', 'd-measure']
    method_matrices = {
        'NHE': heatmap_matrix_nhe,
        'IM': IM_matrix,
        'POR': POR_matrix,
        'NetSimile': NetSimile_matrix,
        'NetLSD': NetLSD_matrix,
        'd-measure': D_matrix
    }

    # Create heatmap figure
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()

    for i, method in enumerate(method_names):
        ax = axes[i]
        matrix = method_matrices[method]

        sns.heatmap(matrix[::-1, :],
                    cmap='RdYlBu',
                    ax=ax,
                    square=True,
                    cbar_kws={'shrink': 0.8})

        ax.set_title(method)
        ax.set_xlabel('Network Index')
        ax.set_ylabel('Network Index')

    plt.tight_layout()
    plt.show()

    # Create clustering results figure
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()

    # Plot clustering results for each method
    for i, method in enumerate(method_names):
        ax = axes[i]
        matrix = method_matrices[method]

        # Perform hierarchical clustering and get remapped labels
        remapped_labels = return_clustering_label(matrix)
        ax.plot(list(range(len(remapped_labels))), remapped_labels, marker='o', linewidth=2, markersize=4)

        ax.set_title(f'{method} Clustering')
        ax.set_xlabel('Network Index')
        ax.set_ylabel('Cluster Label')
        ax.set_yticks(range(5))  # Assuming 5 clusters
        ax.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()


def return_clustering_label(IM_matirx):
    """
    Perform hierarchical clustering on a distance matrix and return remapped cluster labels.

    Args:
        IM_matirx (numpy.ndarray): Distance matrix for clustering

    Returns:
        numpy.ndarray: Remapped cluster labels in order of appearance
    """
    # Perform hierarchical clustering with complete linkage
    hierarchical = AgglomerativeClustering(n_clusters=5, affinity='precomputed', linkage='complete')
    hierarchical_labels = hierarchical.fit_predict(IM_matirx)

    # Remap labels to appear in order of first occurrence
    unique_labels, indices = np.unique(hierarchical_labels, return_inverse=True)
    unique_labels_in_order = []
    seen = set()
    for label in hierarchical_labels:
        if label not in seen:
            unique_labels_in_order.append(label)
            seen.add(label)

    # Create mapping from original labels to sequential labels
    label_mapping = {old_label: new_label for new_label, old_label in enumerate(unique_labels_in_order)}

    # Apply mapping to get remapped labels
    remapped_labels = np.array([label_mapping[label] for label in hierarchical_labels])
    return remapped_labels


if __name__ == '__main__':

    china_mobility_parallel()  # Parallel network distance calculation
    network_centralities_china()  # Network centrality analysis
    SLouvain_networks()  # Community detection analysis
    draw_scatter_line_combined()  # Combined scatter plots
    draw_scatter_line_nonconsective()  # Non-consecutive time analysis
    draw_scatter_line_nonconsective_others()  # Other methods analysis
    draw_distance_mobility_combined()  # Combined distance matrix visualization